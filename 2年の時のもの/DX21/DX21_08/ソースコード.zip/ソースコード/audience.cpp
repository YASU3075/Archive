//-----------------------------------------------
// audience.cpp
// ������F2024/07/17
// ����ҁF���c���l
//-----------------------------------------------
#include "audience.h"
#include "sound.h"


//-----------------------------------------------
// �}�N����`
//-----------------------------------------------
#define AUDIENCE_WIDTH (300.0f)
#define AUDIENCE_HEIGHT (300.0f)


//-----------------------------------------------
// �\���̐錾
//-----------------------------------------------
struct AUDIENCE
{
	bool Enable;
	XMFLOAT2 Position;
	int FrameCount;
};


//-----------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------
static AUDIENCE g_Audience[10];
static ID3D11ShaderResourceView* g_Texture = {};		//�e�N�X�`�����
int g_audience_sound;

//-----------------------------------------------
// ����������
//-----------------------------------------------
void InitAudience(void)
{
	//�e�N�X�`���ǂݍ���
	TexMetadata metadata;
	ScratchImage image;

	LoadFromWICFile(L"asset\\texture\\audience.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &g_Texture);
	assert(g_Texture);

	for (int i = 0; i < 10; i++)
	{
		g_Audience[i].Enable = false;
		g_Audience[i].Position = XMFLOAT2(0.0f, 0.0f);
		g_Audience[i].FrameCount = 0;
	}

	g_audience_sound = LoadSound((char*)"asset/sound/audience.wav");
}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void UninitAudience(void)
{
	if (g_Texture)
	{
		//�e�N�X�`���[�̉��
		g_Texture->Release();
		g_Texture = NULL;
	}
}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void UpdateAudience(void)
{
	for (int i = 0; i < 10; i++)
	{
		if (g_Audience[i].Enable)
		{
			g_Audience[i].FrameCount++;
			float radian = g_Audience[i].FrameCount * 6 * XM_PI / 180;
			g_Audience[i].Position.y = 200.0f * cosf(radian) + SCREEN_HEIGHT + AUDIENCE_HEIGHT * 0.5;
			if (g_Audience[i].FrameCount >= 120)
			{
				g_Audience[i].Enable = false;
			}
		}
	}
}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void DrawAudience(void)
{
	GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture);
	for (int i = 0; i < 10; i++)
	{
		if (g_Audience[i].Enable)
		{
			DrawSprite(g_Audience[i].Position, 0.0f, XMFLOAT2(AUDIENCE_WIDTH, AUDIENCE_HEIGHT));
		}
	}
}

//-----------------------------------------------
// �ϋq�쐬
//-----------------------------------------------
void SetAudience(void)
{
	for (int i = 0; i < 10; i++)
	{
		if (!g_Audience[i].Enable)
		{
			g_Audience[i].Enable = true;
			g_Audience[i].Position.x = (rand() % 10 + 1) * 100.0f;
			g_Audience[i].Position.y = SCREEN_HEIGHT + AUDIENCE_HEIGHT * 0.5f;
			g_Audience[i].FrameCount = 0;
			SetVolume(g_audience_sound, 10);
			PlaySound(g_audience_sound, 0);
			break;
		}
	}
}
