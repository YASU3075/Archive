//-----------------------------------------------
// block.cpp
// ������F2024/07/03
// ����ҁF���c���l
//-----------------------------------------------
#include "block.h"
#include "sprite.h"
#include <time.h>
#include "piece.h"
#include "effect.h"
#include "firework.h"
#include "combo.h"

//-----------------------------------------------
// �񋓑̐錾
//-----------------------------------------------
enum BLOCK_STATE
{
	BLOCK_STATE_IDLE,
	BLOCK_STATE_ERASE_IDLE,
	BLOCK_STATE_STACK_IDLE,
};

//-----------------------------------------------
// �\���̐錾
//-----------------------------------------------

//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------
void StackBLock();



//-----------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------
static ID3D11ShaderResourceView* g_Texture[4] = { NULL };		//�e�N�X�`�����
static BLOCK_STATE g_BlockState;
static BLOCK g_Block[BLOCK_ROWS][BLOCK_COLS];
static int g_BlockStateCount;
static int g_BlockCheckCount;

//-----------------------------------------------
// ����������
//-----------------------------------------------
void InitBlock(void)
{
	//�e�N�X�`���ǂݍ���
	TexMetadata metadata[4];
	ScratchImage image[4];

	//��񂲈�
	LoadFromWICFile(L"asset\\texture\\apple.png", WIC_FLAGS_NONE, &metadata[0], image[0]);
	CreateShaderResourceView(GetDevice(), image[0].GetImages(), image[0].GetImageCount(), metadata[0], &g_Texture[0]);
	assert(g_Texture[0]);

	//�킽����
	LoadFromWICFile(L"asset\\texture\\cotton.png", WIC_FLAGS_NONE, &metadata[1], image[1]);
	CreateShaderResourceView(GetDevice(), image[1].GetImages(), image[1].GetImageCount(), metadata[1], &g_Texture[1]);
	assert(g_Texture[1]);

	//�����X
	LoadFromWICFile(L"asset\\texture\\ice.png", WIC_FLAGS_NONE, &metadata[2], image[2]);
	CreateShaderResourceView(GetDevice(), image[2].GetImages(), image[2].GetImageCount(), metadata[2], &g_Texture[2]);
	assert(g_Texture[2]);

	//�Ă�����
	LoadFromWICFile(L"asset\\texture\\yakisoba.png", WIC_FLAGS_NONE, &metadata[3], image[3]);
	CreateShaderResourceView(GetDevice(), image[3].GetImages(), image[3].GetImageCount(), metadata[3], &g_Texture[3]);
	assert(g_Texture[3]);

	//time��seed�l���Z�b�g���Ȃ���
	srand((unsigned int)time(0));

	//�u���b�N�z�񏉊���
	for (int i = 0; i < BLOCK_ROWS; i++)
	{
		for (int j = 0; j < BLOCK_COLS; j++)
		{
			g_Block[i][j].Enable = false;
			g_Block[i][j].Erase = false;
			g_Block[i][j].Type = rand() % 4;
			g_Block[i][j].check = false;
		}
	}

	g_BlockState = BLOCK_STATE_IDLE;
	g_BlockStateCount = 0;
	g_BlockCheckCount = 0;

	srand((unsigned int)time(0));

}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void UninitBlock(void)
{
	//�e�N�X�`���[�̉��
	for (int i = 0; i < 4; i++)
	{
		if (g_Texture[i])
		{
			g_Texture[i]->Release();
			g_Texture[i] = NULL;
		}
	}
}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void UpdateBlock(void)
{
	switch (g_BlockState)
	{
	case BLOCK_STATE_IDLE:
		break;

	case BLOCK_STATE_ERASE_IDLE:
		g_BlockStateCount++;
		if (g_BlockStateCount > 60)
		{
			StackBLock();
		}
		break;

	case BLOCK_STATE_STACK_IDLE:
		g_BlockStateCount++;
		if (g_BlockStateCount > 60)
		{
			EraseBlock();
		}
		break;

	default:break;
	}
}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void DrawBlock(void)
{
	for (int i = 0; i < BLOCK_ROWS; i++)
	{
		for (int j = 0; j < BLOCK_COLS; j++)
		{
			if (g_Block[i][j].Enable)
			{
				//�e�N�X�`���ݒ�
				GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture[g_Block[i][j].Type]);

				//�X�v���C�g�`��
				XMFLOAT2 position;
				position.x = j * PIECE_WIDTH + SCREEN_WIDTH * 0.5f - (BLOCK_COLS * 0.5f - 0.5f) * PIECE_WIDTH;
				position.y = i * PIECE_HEIGHT + SCREEN_HEIGHT * 0.5f - (BLOCK_ROWS * 0.5f - 0.5f) * PIECE_HEIGHT;

				DrawSprite(position, 0.0f, XMFLOAT2(PIECE_WIDTH, PIECE_HEIGHT));
			}
		}
	}
}

//-----------------------------------------------
// �Z�b�^�[
//-----------------------------------------------
void SetBlock(int x, int y, int type)
{
	g_Block[y][x].Enable = true;
	g_Block[y][x].Erase = false;
	g_Block[y][x].Type = type;

}

//-----------------------------------------------
// �Q�b�^�[
//-----------------------------------------------
BLOCK GetBlock(int x, int y)
{
	return g_Block[y][x];
}

//-----------------------------------------------
// �u���b�N�폜
//-----------------------------------------------
void EraseBlock()
{
	bool erase = false;
	
	//�Ղ�Ղ����
	for (int y = 0; y < BLOCK_ROWS; y++)
	{
		for (int x = 0; x < BLOCK_COLS; x++)
		{
			if (g_Block[y][x].Enable && !g_Block[y][x].check && !g_Block[y][x].Erase)
			{
				g_Block[y][x].check = true;
				SearchBlock(x, y, g_Block[y][x].Type);
				if (g_BlockCheckCount >= 4)
				{//4�ȏ�Ȃ����Ă������
					for (int yc = 0; yc < BLOCK_ROWS; yc++)
					{
						for (int xc = 0; xc < BLOCK_COLS; xc++)
						{
							if (g_Block[yc][xc].check)
							{
								g_Block[yc][xc].Erase = true;
							}
						}
					}

					erase = true;
				}

				//�`�F�b�N�O��
				for (int yc = 0; yc < BLOCK_ROWS; yc++)
				{
					for (int xc = 0; xc < BLOCK_COLS; xc++)
					{
						if (g_Block[yc][xc].check)
						{
							g_Block[yc][xc].check = false;
						}
					}
				}
			}
			//�J�E���g���Z�b�g
			g_BlockCheckCount = 1;
		}
	}


	//�u���b�N�폜
	for (int y = 0; y < BLOCK_ROWS; y++)
	{
		for (int x = 0; x < BLOCK_COLS; x++)
		{
			if (g_Block[y][x].Erase)
			{
				g_Block[y][x].Erase = false;
				g_Block[y][x].Enable = false;

				XMFLOAT2 position;
				position.x = x * PIECE_WIDTH + SCREEN_WIDTH * 0.5f - (BLOCK_COLS * 0.5f - 0.5f) * PIECE_WIDTH;
				position.y = y * PIECE_HEIGHT + SCREEN_HEIGHT * 0.5f - (BLOCK_ROWS * 0.5f - 0.5f) * PIECE_HEIGHT;

				//�G�t�F�N�g����
				CreateEffect(position);

				//�ԉΑł��グ
				int x = rand() % (SCREEN_WIDTH - 200) + 200;
				float c[3];
				int frame = rand() % 51;
				for (int i = 0; i < 3; i++)
				{
					c[i] = (float)(rand() % 11) / 10.0f;
				}
				SetFirework(XMFLOAT2(x, SCREEN_HEIGHT), XMFLOAT4(c[0], c[1], c[2], 0.3f), frame);
			}
		}
	}

	if (erase)
	{
		AddCombo();
		g_BlockState = BLOCK_STATE_ERASE_IDLE;
		g_BlockStateCount = 0;
	}
	else
	{
		SwitchCombo(false);
		CreatePiece();
		g_BlockState = BLOCK_STATE_IDLE;
		g_BlockStateCount = 0;
	}

}

//-----------------------------------------------
// �u���b�N�ς�
//-----------------------------------------------
void StackBLock()
{
	bool stack = false;

	for (int y = BLOCK_ROWS - 1; y > 0; y--)
	{
		for (int x = 0; x < BLOCK_COLS; x++)
		{
			if (g_Block[y][x].Enable == false)
			{
				for (int ys = y - 1; ys >= 0; ys--)
				{
					if (g_Block[ys][x].Enable)
					{
						g_Block[y][x] = g_Block[ys][x];
						g_Block[ys][x].Enable = false;

						stack = true;

						break;
					}
				}
			}
		}
	}

	if (stack)
	{
		g_BlockState = BLOCK_STATE_STACK_IDLE;
		g_BlockStateCount = 0;
	}

	else
	{
		SwitchCombo(false);
		CreatePiece();
		g_BlockState = BLOCK_STATE_IDLE;
		g_BlockStateCount = 0;
	}

}

//-----------------------------------------------
// �u���b�N���l�߂�
//-----------------------------------------------
void FillBlock()
{
	for (int y = BLOCK_ROWS - 1; y > 0; y--)
	{
		for (int x = 0; x < BLOCK_COLS; x++)
		{
			if (g_Block[y][x].Enable == false)
			{
				for (int ys = y - 1; ys >= 0; ys--)
				{
					if (g_Block[ys][x].Enable)
					{
						g_Block[y][x] = g_Block[ys][x];
						g_Block[ys][x].Enable = false;

						break;
					}
				}
			}
		}
	}
}

//-----------------------------------------------
// �u���b�N��T��
//-----------------------------------------------
void SearchBlock(int x, int y, int type)
{
	if (g_Block[y - 1][x].Enable && !g_Block[y - 1][x].check && g_Block[y - 1][x].Type == type && y - 1 >= 0)
	{
		g_BlockCheckCount++;
		g_Block[y - 1][x].check = true;
		SearchBlock(x, y - 1, type);
	}

	if (g_Block[y + 1][x].Enable &&!g_Block[y + 1][x].check && g_Block[y + 1][x].Type == type && y + 1 < BLOCK_ROWS)
	{
		g_BlockCheckCount++;
		g_Block[y + 1][x].check = true;
		SearchBlock(x, y + 1, type);
	}

	if (g_Block[y][x - 1].Enable && !g_Block[y][x - 1].check && g_Block[y][x - 1].Type == type && x - 1 >= 0)
	{
		g_BlockCheckCount++;
		g_Block[y][x - 1].check = true;
		SearchBlock(x - 1, y, type);
	}

	if (g_Block[y][x + 1].Enable && !g_Block[y][x + 1].check && g_Block[y][x + 1].Type == type && x + 1 < BLOCK_COLS)
	{
		g_BlockCheckCount++;
		g_Block[y][x + 1].check = true;
		SearchBlock(x + 1, y, type);
	}

}
