// -----------------------------------------------
// combo.cpp
// ������F2024/06/19
//-----------------------------------------------
#include "combo.h"
#include "sprite.h"

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------


//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------

//-----------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------
static ID3D11ShaderResourceView * g_Texture = NULL;
static ID3D11ShaderResourceView * g_Texture_combo = NULL;
static int g_combo;
static bool g_isUse;

//-----------------------------------------------
// ����������
//-----------------------------------------------
void InitCombo(void)
{
	//ID3D11Device* pDevice = GetDevice();

	//�e�N�X�`���ǂݍ���
	TexMetadata metadata[2];
	ScratchImage image[2];

	LoadFromWICFile(L"asset\\texture\\number.png", WIC_FLAGS_NONE, &metadata[0], image[0]);
	CreateShaderResourceView(GetDevice(), image[0].GetImages(), image[0].GetImageCount(), metadata[0], &g_Texture);
	assert(g_Texture);

	LoadFromWICFile(L"asset\\texture\\combo.png", WIC_FLAGS_NONE, &metadata[1], image[1]);
	CreateShaderResourceView(GetDevice(), image[1].GetImages(), image[1].GetImageCount(), metadata[1], &g_Texture_combo);
	assert(g_Texture_combo);

	g_combo = 0;
	g_isUse = false;
}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void UninitCombo(void)
{
	//�e�N�X�`���[�̉��
	if (g_Texture)
	{
		g_Texture->Release();
		g_Texture = NULL;
	}

}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void UpdateCombo(void)
{
	
}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void DrawCombo(void)
{
	if (g_isUse)
	{
		//�e�N�X�`���ݒ�
		GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture);

		int combo = g_combo;

		if (combo > 9)
		{
			combo = 9;
		}

		DrawSpriteAnim(XMFLOAT2(COMBO_X, COMBO_Y), 0, XMFLOAT2(COMBO_WIDTH, COMBO_HEIGHT), 5, 5, combo);

		//�e�N�X�`���ݒ�
		GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture_combo);
		DrawSprite(XMFLOAT2(COMBO_X + 350.0f * 0.5f, COMBO_Y), 0, XMFLOAT2(300.0f, COMBO_HEIGHT));
	}
}

//-----------------------------------------------
// �R���{���Z
//-----------------------------------------------
void AddCombo(void)
{
	g_combo++;
}

//-----------------------------------------------
// �R���{�I���I�t
//-----------------------------------------------
void SwitchCombo(bool use)
{
	g_isUse = use;
	if (!use)
	{
		g_combo = 0;
	}
}