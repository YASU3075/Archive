//-----------------------------------------------
// combo.h
//-----------------------------------------------

#pragma once

#include "renderer.h"

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------
#define COMBO_WIDTH	(100.0f)
#define COMBO_HEIGHT	(100.0f)
#define COMBO_X		(900.0f)
#define COMBO_Y		(400.0f)

//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------
void InitCombo(void);
void UninitCombo(void);
void UpdateCombo(void);
void DrawCombo(void);
void AddCombo(void);
void SwitchCombo(bool use);
