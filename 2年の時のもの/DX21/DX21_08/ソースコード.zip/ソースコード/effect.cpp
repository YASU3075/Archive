//-----------------------------------------------
// effect.cpp
// ������F2024/07/17
// ����ҁF���c���l
//-----------------------------------------------

#include "effect.h"


//-----------------------------------------------
// �}�N����`
//-----------------------------------------------
#define EFFECT_MAX		(100)

//-----------------------------------------------
// �\���̐錾
//-----------------------------------------------
struct EFFECT
{
	bool Enable;
	XMFLOAT2 Position;
	int FrameCount;
};


//-----------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------
static EFFECT g_Effect[EFFECT_MAX];
static ID3D11ShaderResourceView* g_Texture = {};		//�e�N�X�`�����

//-----------------------------------------------
// ����������
//-----------------------------------------------
void InitEffect(void)
{
	//�e�N�X�`���ǂݍ���
	TexMetadata metadata;
	ScratchImage image;

	LoadFromWICFile(L"asset\\texture\\Explosion.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &g_Texture);
	assert(g_Texture);

	//�G�t�F�N�g�z�񏉊���
	for (int i = 0; i < EFFECT_MAX; i++)
	{
		g_Effect[i].Enable = false;
	}

}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void UninitEffect(void)
{
	//�e�N�X�`���[�̉��
	g_Texture->Release();
}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void UpdateEffect(void)
{
	for (int i = 0; i < EFFECT_MAX; i++)
	{
		if (g_Effect[i].Enable)
		{
			g_Effect[i].FrameCount++;

			if (g_Effect[i].FrameCount > 30)
			{
				g_Effect[i].Enable = false;
			}

		}
	}
}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void DrawEffect(void)
{
	GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture);

	for (int i = 0; i < EFFECT_MAX; i++)
	{
		if (g_Effect[i].Enable)
		{
			DrawSpriteAnim(g_Effect[i].Position, 0.0f, XMFLOAT2(PIECE_WIDTH, PIECE_HEIGHT), 4, 4, g_Effect[i].FrameCount / 2);

		}
	}

}

//-----------------------------------------------
// �G�t�F�N�g�쐬
//-----------------------------------------------
void CreateEffect(XMFLOAT2 Position)
{
	for (int i = 0; i < EFFECT_MAX; i++)
	{
		if (g_Effect[i].Enable == false)
		{
			g_Effect[i].Enable = true;
			g_Effect[i].Position = Position;
			g_Effect[i].FrameCount = 0;

			break;
		}
	}
}
