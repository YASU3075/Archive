//-----------------------------------------------
// fade.cpp
// ������F2024/09/18
//-----------------------------------------------
#include "fade.h"
#include "sprite.h"
#include "keyboard.h"

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------

//-----------------------------------------------
// �񋓑̐錾
//-----------------------------------------------
enum FADE
{
	FADE_NONE = 0,
	FADE_OUT,
	FADE_IN,
};

//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------

//-----------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------
static ID3D11ShaderResourceView* g_Texture = NULL;
static FADE g_Fade;
static float g_FadaAlpha;
static bool g_FadeOutFinish;

//-----------------------------------------------
// ����������
//-----------------------------------------------
void InitFade(void)
{
	//ID3D11Device* pDevice = GetDevice();

	//�e�N�X�`���ǂݍ���
	TexMetadata metadata;
	ScratchImage image;
	
	LoadFromWICFile(L"asset\\texture\\BG.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &g_Texture);
	assert(g_Texture);

	g_Fade = FADE_IN;
	g_FadaAlpha = 1.0f;
	g_FadeOutFinish = false;
}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void UninitFade(void)
{
	//�e�N�X�`���[�̉��
	if (g_Texture)
	{
		g_Texture->Release();
		g_Texture = NULL;
	}

}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void UpdateFade(void)
{
	if (g_Fade == FADE_OUT)
	{
		g_FadaAlpha += 0.05f;
		if (g_FadaAlpha > 1.0f)
		{
			g_FadaAlpha = 1.0f;
			g_Fade = FADE_IN;
			g_FadeOutFinish = true;
		}
	}

	else if (g_Fade == FADE_IN)
	{
		g_FadeOutFinish = false;

		g_FadaAlpha -= 0.05f;
		if (g_FadaAlpha < 0.0f)
		{
			g_FadaAlpha = 0.0f;
			g_Fade = FADE_NONE;
		}
	}

}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void DrawFade(void)
{
	//�e�N�X�`���ݒ�
	GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture);
	//�X�v���C�g�`��
	DrawSpriteColor(XMFLOAT2(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(0.0f, 0.0f, 0.0f, g_FadaAlpha));

}


void FadeOut(void)
{
	if (g_Fade == FADE_NONE)
	{
		g_Fade = FADE_OUT;
		g_FadeOutFinish = false;
	}
}

bool IsFadeOutFinish(void)
{
	return g_FadeOutFinish;
}
