//-----------------------------------------------
// fade.h
//-----------------------------------------------

#pragma once

#include "renderer.h"

//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------
void InitFade(void);
void UninitFade(void);
void UpdateFade(void);
void DrawFade(void);
void FadeOut(void);
bool IsFadeOutFinish(void);
