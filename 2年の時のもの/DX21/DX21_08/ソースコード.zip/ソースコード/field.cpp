//-----------------------------------------------
// field.cpp
// ������F2024/06/19
//-----------------------------------------------
#include "field.h"
#include "sprite.h"

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------


//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------

//-----------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------
static ID3D11ShaderResourceView* g_Texture_Frame = NULL;
static ID3D11ShaderResourceView* g_Texture_Bg = NULL;
static ID3D11ShaderResourceView* g_Texture_asd = NULL;
static ID3D11ShaderResourceView* g_Texture_space = NULL;
static ID3D11ShaderResourceView* g_Texture_r= NULL;

//-----------------------------------------------
// ����������
//-----------------------------------------------
void InitField(void)
{
	//ID3D11Device* pDevice = GetDevice();

	//�e�N�X�`���ǂݍ���
	TexMetadata metadata[5];
	ScratchImage image[5];
	
	LoadFromWICFile(L"asset\\texture\\Frame.png" ,WIC_FLAGS_NONE, &metadata[0], image[0]);
	CreateShaderResourceView(GetDevice(), image[0].GetImages(), image[0].GetImageCount(), metadata[0], &g_Texture_Frame);
	assert(g_Texture_Frame);

	LoadFromWICFile(L"asset\\texture\\BG.png", WIC_FLAGS_NONE, &metadata[1], image[1]);
	CreateShaderResourceView(GetDevice(), image[1].GetImages(), image[1].GetImageCount(), metadata[1], &g_Texture_Bg);
	assert(g_Texture_Bg);

	LoadFromWICFile(L"asset\\texture\\asd.png", WIC_FLAGS_NONE, &metadata[2], image[2]);
	CreateShaderResourceView(GetDevice(), image[2].GetImages(), image[2].GetImageCount(), metadata[2], &g_Texture_asd);
	assert(g_Texture_asd);

	LoadFromWICFile(L"asset\\texture\\space.png", WIC_FLAGS_NONE, &metadata[3], image[3]);
	CreateShaderResourceView(GetDevice(), image[3].GetImages(), image[3].GetImageCount(), metadata[3], &g_Texture_space);
	assert(g_Texture_space);

	LoadFromWICFile(L"asset\\texture\\r.png", WIC_FLAGS_NONE, &metadata[4], image[4]);
	CreateShaderResourceView(GetDevice(), image[4].GetImages(), image[4].GetImageCount(), metadata[4], &g_Texture_r);
	assert(g_Texture_r);

}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void UninitField(void)
{
	//�e�N�X�`���[�̉��
	if (g_Texture_Frame)
	{
		g_Texture_Frame->Release();
		g_Texture_Frame = NULL;
	}

	if (g_Texture_Bg)
	{
		g_Texture_Bg->Release();
		g_Texture_Bg = NULL;
	}

	if (g_Texture_asd)
	{
		g_Texture_asd->Release();
		g_Texture_asd = NULL;
	}

	if (g_Texture_space)
	{
		g_Texture_space->Release();
		g_Texture_space = NULL;
	}

	if (g_Texture_r)
	{
		g_Texture_r->Release();
		g_Texture_r = NULL;
	}
}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void UpdateField(void)
{
	
}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void DrawField(void)
{
	//�e�N�X�`���ݒ�
	GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture_Bg);
	//�X�v���C�g�`��
	DrawSpriteColor(XMFLOAT2(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 0.3f));

	//�e�N�X�`���ݒ�
	GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture_Frame);
	//�X�v���C�g�`��
	DrawSprite(XMFLOAT2(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2), 0.0f, XMFLOAT2(320.0f, 700.0f));

	//�e�N�X�`���ݒ�
	GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture_asd);
	//�X�v���C�g�`��
	DrawSprite(XMFLOAT2(150.0f, 300.0f), 0.0f, XMFLOAT2(200.0f, 80.0f));

	//�e�N�X�`���ݒ�
	GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture_r);
	//�X�v���C�g�`��
	DrawSprite(XMFLOAT2(400.0f, 300.0f), 0.0f, XMFLOAT2(100.0f, 100.0f));

	//�e�N�X�`���ݒ�
	GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture_space);
	//�X�v���C�g�`��
	DrawSprite(XMFLOAT2(250.0f, 450.0f), 0.0f, XMFLOAT2(350.0f, 150.0f));

}
