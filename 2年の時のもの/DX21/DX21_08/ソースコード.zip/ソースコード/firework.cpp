//-----------------------------------------------
// firework.cpp
// ������F2024/09/04
// ����ҁF���c���l
//-----------------------------------------------
#include "firework.h"
#include "sprite.h"
#include "sound.h"
#include "audience.h"
#include "score.h"

//-----------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------
static ID3D11ShaderResourceView* g_Texture_Line = NULL;
static ID3D11ShaderResourceView* g_Texture_Dot = NULL;
FIREWORK g_firework[MAX_FIREWORK];
int g_up_sound;
int g_explosion_sound;

//-----------------------------------------------
// ����������
//-----------------------------------------------
void InitFirework(void)
{
	//�ԉΏ�����
	for (int i = 0; i < MAX_FIREWORK; i++)
	{
		g_firework[i].use = false;
		g_firework[i].pos = XMFLOAT2(0.0f, 0.0f);
		g_firework[i].speed = XMFLOAT2(0.0f, 0.0f);
		g_firework[i].frame_count = 0;
		g_firework[i].state = FIREWORK_UP;
		g_firework[i].size = 0.0f;
		g_firework[i].color = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
		g_firework[i].random_frame = 0;
	}

	//�e�N�X�`���ǂݍ���
	TexMetadata metadata[2];
	ScratchImage image[2];

	LoadFromWICFile(L"asset\\texture\\dot.png", WIC_FLAGS_NONE, &metadata[0], image[0]);
	CreateShaderResourceView(GetDevice(), image[0].GetImages(), image[0].GetImageCount(), metadata[0], &g_Texture_Dot);
	assert(g_Texture_Dot);

	LoadFromWICFile(L"asset\\texture\\line.png", WIC_FLAGS_NONE, &metadata[1], image[1]);
	CreateShaderResourceView(GetDevice(), image[1].GetImages(), image[1].GetImageCount(), metadata[1], &g_Texture_Line);
	assert(g_Texture_Line);

	//���t�@�C���ǂݍ���
	g_up_sound = LoadSound((char*)"asset/sound/up_sound.wav");
	g_explosion_sound = LoadSound((char*)"asset/sound/explosion_sound.wav");

}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void UninitFirework(void)
{
	//�e�N�X�`���[�̉��
	if (g_Texture_Line)
	{
		g_Texture_Line->Release();
		g_Texture_Line = NULL;
	}

	if (g_Texture_Dot)
	{
		g_Texture_Dot->Release();
		g_Texture_Dot = NULL;
	}

}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void UpdateFirework(void)
{
	for (int i = 0; i < MAX_FIREWORK; i++)
	{
		if (g_firework[i].use)
		{//�g�p���Ă�����

			switch (g_firework[i].state)
			{
			case FIREWORK_UP:			//�㏸��
				g_firework[i].frame_count++;
				g_firework[i].pos.y -= 5;
				if (g_firework[i].frame_count >= UP_FRAMECOUNT + g_firework[i].random_frame)
				{//�X�e�[�g�J��
					g_firework[i].state = FIREWORK_EXPLOSION;
					g_firework[i].frame_count = 0;
					SetVolume(g_explosion_sound, 20);
					PlaySound(g_explosion_sound, 0);
					SetAudience();
					AddScore();
				}
				break;

			case FIREWORK_EXPLOSION:	//������
				g_firework[i].frame_count++;
				if (g_firework[i].frame_count >= EXPLOSION_FRAMECOUNT)
				{
					g_firework[i].use = false;
				}
				break;

			default:break;
			}

		}
	}
}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void DrawFirework(void)
{
	for (int i = 0; i < MAX_FIREWORK; i++)
	{
		if (g_firework[i].use)
		{//�g�p���Ă�����

			switch (g_firework[i].state)
			{
			case FIREWORK_UP:			//�㏸��
				//�e�N�X�`���ݒ�
				GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture_Line);
				DrawSpriteAnim(g_firework[i].pos, 0.0f, XMFLOAT2(20.0f, 100.0f), 1, 5, g_firework[i].frame_count);
				break;

			case FIREWORK_EXPLOSION:	//������
			{
				//�e�N�X�`���ݒ�
				GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture_Dot);
				//�T�C�Y����
				g_firework[i].size += 0.3f;

				//�����̓_
				XMINT2 pos = XMINT2((int)g_firework[i].pos.x, (int)g_firework[i].pos.y);
				DrawLine(pos, pos, g_firework[i].color);

				float radian = 0.0f;

				for (int j = 0; j < 8; j++)
				{
					radian = 45.0f * j * XM_PI / 180.0f;

					int x = DOT_SIZE * cosf(radian) + pos.x;
					int y = DOT_SIZE * sinf(radian) + pos.y;

					int fx = DOT_SIZE * cosf(radian) * (int)g_firework[i].size + pos.x;
					int fy = DOT_SIZE * sinf(radian) * (int)g_firework[i].size + pos.y;
					
					DrawLine(XMINT2(x, y), XMINT2(fx, fy), g_firework[i].color);
				}
			}
				break;

			default:break;
			}
		}
	}
}

//-----------------------------------------------
// �ԉ΂̃Z�b�^�[
//-----------------------------------------------
void SetFirework(XMFLOAT2 pos, XMFLOAT4 c, int frame)
{
	for (int i = 0; i < MAX_FIREWORK; i++)
	{
		if (!g_firework[i].use)
		{//�z��̐擪����T���čŏ��Ɍ��������g���ĂȂ��\����
			g_firework[i].use = true;
			g_firework[i].pos = pos;
			g_firework[i].size = 0.0f;
			g_firework[i].speed = XMFLOAT2(0.0f, -1.0f);
			g_firework[i].frame_count = 0;
			g_firework[i].state = FIREWORK_UP;
			g_firework[i].color = c;
			g_firework[i].random_frame = frame;

			PlaySound(g_up_sound, 0);
			break;
		}
	}
}
