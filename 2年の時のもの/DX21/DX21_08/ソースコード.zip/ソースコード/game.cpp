//-----------------------------------------------
// game.cpp
// ������F2024/05/13
//-----------------------------------------------
#include "game.h"
#include "sprite.h"
#include "field.h"
#include "piece.h"
#include "block.h"
#include "effect.h"
#include "score.h"
#include "firework.h"
#include "audience.h"
#include "sound.h"
#include "combo.h"

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------


//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------

//-----------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------
static ID3D11ShaderResourceView* g_Texture = NULL;
int g_bgm;

//-----------------------------------------------
// ����������
//-----------------------------------------------
void InitGame(void)
{
	InitField();
	InitBlock();
	InitPiece();
	InitEffect();
	InitScore();
	InitFirework();
	InitAudience();
	InitCombo();

	g_bgm = LoadSound((char*)"asset/sound/bgm.wav");
	SetVolume(g_bgm, 0.5f);
	PlaySound(g_bgm, -1);
}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void UninitGame(void)
{
	UninitField();
	UninitPiece();
	UninitBlock();
	UninitEffect();
	UninitScore();
	UninitFirework();
	UninitAudience();
	UninitCombo();

	StopSound(g_bgm);
}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void UpdateGame(void)
{
	UpdateField();
	UpdatePiece();
	UpdateBlock();
	UpdateEffect();
	UpdateScore();
	UpdateFirework();
	UpdateAudience();
	UpdateCombo();
}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void DrawGame(void)
{
	DrawField();
	DrawFirework();
	DrawPiece();
	DrawBlock();
	DrawEffect();
	DrawScore();
	DrawCombo();
	DrawAudience();
}
