//-----------------------------------------------
// game.h
//-----------------------------------------------

#pragma once

#include "renderer.h"

//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------
void InitGame(void);
void UninitGame(void);
void UpdateGame(void);
void DrawGame(void);
