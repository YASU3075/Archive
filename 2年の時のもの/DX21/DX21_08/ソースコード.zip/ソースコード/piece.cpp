//-----------------------------------------------
// piece.cpp
// ������F2024/06/19
//-----------------------------------------------
#include "piece.h"
#include "sprite.h"
#include "keyboard.h"
#include "block.h"
#include "combo.h"

#include <time.h>

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------

//-----------------------------------------------
// �񋓑̐錾
//-----------------------------------------------
enum PIECE_STATE
{
	PIECE_STATE_IDLE,
	PIECE_STATE_MOVE,
	PIECE_STATE_GROUND_IDLE,
	PIECE_STATE_MISS_IDLE,
};

//-----------------------------------------------
// �\���̐錾
//-----------------------------------------------
struct PIECE
{
	XMFLOAT2 Position;		//�`��ʒu
	int Type[2];			//�}�[�N�̔ԍ�
	int next_type[2];		//���̃}�[�N�̔ԍ�
};

//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------
void MovePiece(void);


//-----------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------
static ID3D11ShaderResourceView* g_Texture[4] = { NULL };		//�e�N�X�`�����
static ID3D11ShaderResourceView* g_Texture_next = NULL;		//�e�N�X�`�����
static PIECE g_Piece;							//�s�[�X
static PIECE_STATE g_PieceState;								//�s�[�X�̏��
static int g_PieceStateCount;
bool g_OldKeyStateSpace;										//�L�[�g���K�[
bool g_OldKeyStateA;											//�L�[�g���K�[
bool g_OldKeyStateD;											//�L�[�g���K�[
bool g_OldKeyStateR;											//�L�[�g���K�[
bool g_rotate;

//-----------------------------------------------
// ����������
//-----------------------------------------------
void InitPiece(void)
{
	//ID3D11Device* pDevice = GetDevice();

	//�e�N�X�`���ǂݍ���
	TexMetadata metadata[4];
	ScratchImage image[4];
	
	//��񂲈�
	LoadFromWICFile(L"asset\\texture\\apple.png" ,WIC_FLAGS_NONE, &metadata[0], image[0]);
	CreateShaderResourceView(GetDevice(), image[0].GetImages(), image[0].GetImageCount(), metadata[0], &g_Texture[0]);
	assert(g_Texture[0]);

	//�킽����
	LoadFromWICFile(L"asset\\texture\\cotton.png", WIC_FLAGS_NONE, &metadata[1], image[1]);
	CreateShaderResourceView(GetDevice(), image[1].GetImages(), image[1].GetImageCount(), metadata[1], &g_Texture[1]);
	assert(g_Texture[1]);

	//�����X
	LoadFromWICFile(L"asset\\texture\\ice.png", WIC_FLAGS_NONE, &metadata[2], image[2]);
	CreateShaderResourceView(GetDevice(), image[2].GetImages(), image[2].GetImageCount(), metadata[2], &g_Texture[2]);
	assert(g_Texture[2]);

	//�Ă�����
	LoadFromWICFile(L"asset\\texture\\yakisoba.png", WIC_FLAGS_NONE, &metadata[3], image[3]);
	CreateShaderResourceView(GetDevice(), image[3].GetImages(), image[3].GetImageCount(), metadata[3], &g_Texture[3]);
	assert(g_Texture[3]);

	//�e�N�X�`���ǂݍ���
	TexMetadata metadata_next;
	ScratchImage image_next;

	//next
	LoadFromWICFile(L"asset\\texture\\next.png", WIC_FLAGS_NONE, &metadata_next, image_next);
	CreateShaderResourceView(GetDevice(), image_next.GetImages(), image_next.GetImageCount(), metadata_next, &g_Texture_next);
	assert(g_Texture_next);

	//�������W�ݒ�
	g_Piece.Position.x = PIECE_INITIAL_X;
	g_Piece.Position.y = PIECE_INITIAL_Y;

	//time��seed�l���Z�b�g���Ȃ���
	srand((unsigned int)time(0));

	//�}�[�N�ݒ�
	for (int i = 0; i < 2; i++)
	{
		g_Piece.Type[i] = rand() % 4;
		g_Piece.next_type[i] = rand() % 4;
	}
	
	g_PieceState = PIECE_STATE_MOVE;
	g_PieceStateCount = 0;
	g_rotate = false;
}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void UninitPiece(void)
{
	//�e�N�X�`���[�̉��
	for (int i = 0; i < 4; i++)
	{
		if (g_Texture[i])
		{
			g_Texture[i]->Release();
			g_Texture[i] = NULL;
		}
	}

	if (g_Texture_next)
	{
		g_Texture_next->Release();
		g_Texture_next = NULL;
	}

}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void UpdatePiece(void)
{
	switch (g_PieceState)
	{
	case PIECE_STATE_IDLE:
		break;
	case PIECE_STATE_MOVE:
		MovePiece();
		break;
	case PIECE_STATE_GROUND_IDLE:
		g_PieceStateCount++;
		if (g_PieceStateCount > 60)
		{
			SwitchCombo(true);
			g_PieceState = PIECE_STATE_IDLE;
			g_PieceStateCount = 0;

			EraseBlock();
		}
		break;
	case PIECE_STATE_MISS_IDLE:
		g_PieceStateCount++;
		if (g_PieceStateCount > 60)
		{
			SetScene(RESULT_SCENE);
		}
		break;

	default:break;
	}
}

//-----------------------------------------------
// �s�[�X����
//-----------------------------------------------
void CreatePiece()
{
	//�������W�ݒ�
	g_Piece.Position.x = PIECE_INITIAL_X;
	g_Piece.Position.y = PIECE_INITIAL_Y;

	//time��seed�l���Z�b�g���Ȃ���
	srand((unsigned int)time(0));

	//�}�[�N�ݒ�
	for (int i = 0; i < 2; i++)
	{
		g_Piece.Type[i] = g_Piece.next_type[i];
	}

	for (int i = 0; i < 2; i++)
	{
		g_Piece.next_type[i] = rand() % 4;
	}

	g_PieceState = PIECE_STATE_MOVE;
	g_PieceStateCount = 0;
	
	//�u���b�N�Ƃ̏Փ˔���
	int x = 0;
	int y = 0;

	if (!g_rotate)
	{//��]���ĂȂ��Ƃ�
		x = (int)((g_Piece.Position.x - SCREEN_WIDTH * 0.5f + (BLOCK_COLS * 0.5f - 0.5f) * PIECE_WIDTH) / PIECE_WIDTH);
		y = (int)((g_Piece.Position.y + PIECE_HEIGHT * 2 - SCREEN_HEIGHT * 0.5f + (BLOCK_ROWS * 0.5f - 0.5f) * PIECE_HEIGHT) / PIECE_HEIGHT);

		BLOCK block = GetBlock(x, y);

		if (block.Enable)
		{
			g_PieceState = PIECE_STATE_MISS_IDLE;
			g_PieceStateCount = 0;
		}
	}
}

//-----------------------------------------------
// �s�[�X�̈ړ�
//-----------------------------------------------
void MovePiece(void)
{
	int x, y;
	BLOCK block;

	//��������
	g_Piece.Position.y += 2.0f;

	//�s�[�X����ւ�����
	{
		bool keystateSpace = Keyboard_IsKeyDown(KK_SPACE);
		if (!g_OldKeyStateSpace && keystateSpace)
		{//�L�[�g���K�[�i�L�[���������u�Ԃ��������j
			int work = 0;

			work = g_Piece.Type[0];
			g_Piece.Type[0] = g_Piece.Type[1];
			g_Piece.Type[1] = work;
		}
		g_OldKeyStateSpace = keystateSpace;
	}

	//��]����
	bool keystateR = Keyboard_IsKeyDown(KK_R);
	if (!g_OldKeyStateR && keystateR)
	{
		if (!g_rotate)
		{
			for (int i = 0; i < 2; i++)
			{
				//�u���b�N�Ƃ̏Փ˔���
				x = (int)((g_Piece.Position.x + PIECE_WIDTH - SCREEN_WIDTH * 0.5f + (BLOCK_COLS * 0.5f - 0.5f) * PIECE_WIDTH) / PIECE_WIDTH);
				y = (int)((g_Piece.Position.y + PIECE_HEIGHT * i - SCREEN_HEIGHT * 0.5f + (BLOCK_ROWS * 0.5f - 0.5f) * PIECE_HEIGHT) / PIECE_HEIGHT + 0.5f);

				BLOCK pBlock = GetBlock(x, y);

				if (pBlock.Enable)
				{
					g_rotate = false;
					break;
				}
				g_rotate = true;
			}
		}

		else
		{
			g_rotate = false;
		}

		if (g_rotate && g_Piece.Position.x > PIECE_MAX_X - PIECE_WIDTH)
		{
			g_Piece.Position.x = PIECE_INITIAL_X;
		}

		if (!g_rotate)
		{
			for (int i = 0; i < 2; i++)
			{
				//�u���b�N�Ƃ̏Փ˔���
				x = (int)((g_Piece.Position.x - SCREEN_WIDTH * 0.5f + (BLOCK_COLS * 0.5f - 0.5f) * PIECE_WIDTH) / PIECE_WIDTH);
				y = (int)((g_Piece.Position.y + PIECE_HEIGHT * i - SCREEN_HEIGHT * 0.5f + (BLOCK_ROWS * 0.5f - 0.5f) * PIECE_HEIGHT) / PIECE_HEIGHT + 0.5f);

				BLOCK pBlock = GetBlock(x, y);
				if (pBlock.Enable)
				{
					g_Piece.Position.y -= PIECE_HEIGHT;
				}
			}
		}
	}
	g_OldKeyStateR = keystateR;

	//���ړ�
	{
		if (Keyboard_IsKeyDown(KK_S))
		{
			g_Piece.Position.y += 2.0f;
		}
	}

	//���E�ړ�����
	{
		bool keystateA = Keyboard_IsKeyDown(KK_A);
		if (!g_OldKeyStateA && keystateA)
		{
			g_Piece.Position.x -= PIECE_WIDTH;

			if (!g_rotate)
			{
				//�u���b�N�Ƃ̏Փ˔���
				x = (int)((g_Piece.Position.x - SCREEN_WIDTH * 0.5f + (BLOCK_COLS * 0.5f - 0.5f) * PIECE_WIDTH) / PIECE_WIDTH);
				y = (int)((g_Piece.Position.y + PIECE_HEIGHT * 2 - SCREEN_HEIGHT * 0.5f + (BLOCK_ROWS * 0.5f - 0.5f) * PIECE_HEIGHT) / PIECE_HEIGHT);
			}

			else
			{
				//�u���b�N�Ƃ̏Փ˔���
				x = (int)((g_Piece.Position.x - SCREEN_WIDTH * 0.5f + (BLOCK_COLS * 0.5f - 0.5f) * PIECE_WIDTH) / PIECE_WIDTH);
				y = (int)((g_Piece.Position.y - SCREEN_HEIGHT * 0.5f + (BLOCK_ROWS * 0.5f - 0.5f) * PIECE_HEIGHT) / PIECE_HEIGHT + 0.5f);
			}

			block = GetBlock(x, y);

			if (block.Enable)
			{
				g_Piece.Position.x += PIECE_WIDTH;
			}

			if (g_Piece.Position.x < PIECE_MIN_X)
			{
				g_Piece.Position.x += PIECE_WIDTH;
			}
		}
		g_OldKeyStateA = keystateA;

		bool keystateD = Keyboard_IsKeyDown(KK_D);
		if (!g_OldKeyStateD && keystateD)
		{
			g_Piece.Position.x += PIECE_WIDTH;

			if (!g_rotate)
			{
				//�u���b�N�Ƃ̏Փ˔���
				x = (int)((g_Piece.Position.x - SCREEN_WIDTH * 0.5f + (BLOCK_COLS * 0.5f - 0.5f) * PIECE_WIDTH) / PIECE_WIDTH);
				y = (int)((g_Piece.Position.y + PIECE_HEIGHT * 2 - SCREEN_HEIGHT * 0.5f + (BLOCK_ROWS * 0.5f - 0.5f) * PIECE_HEIGHT) / PIECE_HEIGHT);
			}

			else
			{
				//�u���b�N�Ƃ̏Փ˔���
				x = (int)((g_Piece.Position.x + PIECE_WIDTH - SCREEN_WIDTH * 0.5f + (BLOCK_COLS * 0.5f - 0.5f) * PIECE_WIDTH) / PIECE_WIDTH);
				y = (int)((g_Piece.Position.y - SCREEN_HEIGHT * 0.5f + (BLOCK_ROWS * 0.5f - 0.5f) * PIECE_HEIGHT) / PIECE_HEIGHT + 0.5f);
			}

			block = GetBlock(x, y);

			if (block.Enable)
			{
				g_Piece.Position.x -= PIECE_WIDTH;
			}

			if (g_Piece.Position.x > PIECE_MAX_X && !g_rotate)
			{
				g_Piece.Position.x -= PIECE_WIDTH;
			}

			if (g_Piece.Position.x + PIECE_WIDTH > PIECE_MAX_X && g_rotate)
			{
				g_Piece.Position.x -= PIECE_WIDTH;
			}

		}
		g_OldKeyStateD = keystateD;
	}

	//�n�ʂƂ̏Փ˔���
	bool ground = false;
	if (g_Piece.Position.y + PIECE_HEIGHT > SCREEN_HEIGHT * 0.5f + (BLOCK_ROWS * 0.5f - 0.5f) * PIECE_HEIGHT && !g_rotate)
	{
		ground = true;
	}

	if (g_Piece.Position.y > SCREEN_HEIGHT * 0.5f + (BLOCK_ROWS * 0.5f - 0.5f) * PIECE_HEIGHT && g_rotate)
	{
		ground = true;
	}

	//�u���b�N�Ƃ̏Փ˔���

	if (!g_rotate)
	{//�c
		x = (int)((g_Piece.Position.x - SCREEN_WIDTH * 0.5f + (BLOCK_COLS * 0.5f - 0.5f) * PIECE_WIDTH) / PIECE_WIDTH);
		y = (int)((g_Piece.Position.y + PIECE_HEIGHT * 2 - SCREEN_HEIGHT * 0.5f + (BLOCK_ROWS * 0.5f - 0.5f) * PIECE_HEIGHT) / PIECE_HEIGHT);

		block = GetBlock(x, y);

		if (block.Enable)
		{
			ground = true;
		}
	}

	else
	{//��
		for (int i = 0; i < 2; i++)
		{
			x = (int)((g_Piece.Position.x + PIECE_WIDTH * i - SCREEN_WIDTH * 0.5f + (BLOCK_COLS * 0.5f - 0.5f) * PIECE_WIDTH) / PIECE_WIDTH);
			y = (int)((g_Piece.Position.y + PIECE_HEIGHT - SCREEN_HEIGHT * 0.5f + (BLOCK_ROWS * 0.5f - 0.5f) * PIECE_HEIGHT) / PIECE_HEIGHT);

			block = GetBlock(x, y);

			if (block.Enable)
			{
				ground = true;
				break;
			}
		}
	}


	//�u���b�N�ݒu
	if (ground)
	{
		for (int i = 0; i < 2; i++)
		{
			if (!g_rotate)
			{//�c
				x = (int)((g_Piece.Position.x - SCREEN_WIDTH * 0.5f + (BLOCK_COLS * 0.5f - 0.5f) * PIECE_WIDTH) / PIECE_WIDTH);
				y = (int)((g_Piece.Position.y + PIECE_HEIGHT * i - SCREEN_HEIGHT * 0.5f + (BLOCK_ROWS * 0.5f - 0.5f) * PIECE_HEIGHT) / PIECE_HEIGHT);
			}

			else
			{//��
				x = (int)((g_Piece.Position.x + PIECE_WIDTH * i - SCREEN_WIDTH * 0.5f + (BLOCK_COLS * 0.5f - 0.5f) * PIECE_WIDTH) / PIECE_WIDTH);
				y = (int)((g_Piece.Position.y - SCREEN_HEIGHT * 0.5f + (BLOCK_ROWS * 0.5f - 0.5f) * PIECE_HEIGHT) / PIECE_HEIGHT);
			}

			SetBlock(x, y, g_Piece.Type[i]);
		}

		FillBlock();
		//�X�e�[�g�ύX
		g_PieceState = PIECE_STATE_GROUND_IDLE;
	}


	

}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void DrawPiece(void)
{
	//�e�N�X�`���ݒ�
	GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture_next);
	//�X�v���C�g�`��
	DrawSpriteColor(XMFLOAT2(900.0f, 125.0f), 0.0f, XMFLOAT2(400.0f, 100.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));

	if (g_PieceState != PIECE_STATE_MOVE && g_PieceState != PIECE_STATE_MISS_IDLE)
		return;

	for (int i = 0; i < 2; i++)
	{
		//�e�N�X�`���ݒ�
		GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture[g_Piece.Type[i]]);
		if (!g_rotate)
		{
			//�X�v���C�g�`��
			DrawSprite(XMFLOAT2(g_Piece.Position.x, g_Piece.Position.y + (PIECE_HEIGHT * i)), 0.0f, XMFLOAT2(PIECE_WIDTH, PIECE_HEIGHT));
		}

		else
		{
			//�X�v���C�g�`��
			DrawSprite(XMFLOAT2(g_Piece.Position.x + (PIECE_WIDTH * i), g_Piece.Position.y), 0.0f, XMFLOAT2(PIECE_WIDTH, PIECE_HEIGHT));
		}

	}
	
	for (int i = 0; i < 2; i++)
	{
		//�e�N�X�`���ݒ�
		GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture[g_Piece.next_type[i]]);
		//�X�v���C�g�`��
		DrawSprite(XMFLOAT2(900.0f, 185.0f + (PIECE_HEIGHT * i)), 0.0f, XMFLOAT2(PIECE_WIDTH , PIECE_HEIGHT));
	}

}
