//-----------------------------------------------
// piece.h
//-----------------------------------------------

#pragma once

#include "renderer.h"
//-----------------------------------------------
// �}�N����`
//-----------------------------------------------
#define FIELD_BOTTOM		(SCREEN_HEIGHT - 60.0f)
#define PIECE_INITIAL_X		(SCREEN_WIDTH / 2 + 25.0f)
#define PIECE_INITIAL_Y		(60.0f)
#define PIECE_MAX_X			(765.0f)
#define PIECE_MIN_X			(515.0f)
#define MAX_PIECE_NUM		(10)

//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------
void InitPiece(void);
void UninitPiece(void);
void UpdatePiece(void);
void DrawPiece(void);
void CreatePiece(void);
