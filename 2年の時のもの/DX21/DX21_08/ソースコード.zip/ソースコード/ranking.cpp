// -----------------------------------------------
// ranking.cpp
// ������F2024/09/25
//-----------------------------------------------
#include "ranking.h"
#include "sprite.h"
#include "score.h"

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------


//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------

//-----------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------
static ID3D11ShaderResourceView* g_Texture = NULL;
static int g_score[4];

//-----------------------------------------------
// ����������
//-----------------------------------------------
void InitRanking(void)
{
	//ID3D11Device* pDevice = GetDevice();

	//�e�N�X�`���ǂݍ���
	TexMetadata metadata;
	ScratchImage image;

	LoadFromWICFile(L"asset\\texture\\number.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &g_Texture);
	assert(g_Texture);

	g_score[0] = 30;
	g_score[1] = 20;
	g_score[2] = 10;
	g_score[3] = GetScore();
	
	for (int i = 0; i < 3; i++)
	{
		if (g_score[3 - i] >= g_score[3 - (i + 1)])
		{
			int work = g_score[3 - (i + 1)];
			g_score[3 - (i + 1)] = g_score[3 - i];
			g_score[3 - i] = work;
		}
	}

}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void UninitRanking(void)
{
	//�e�N�X�`���[�̉��
	if (g_Texture)
	{
		g_Texture->Release();
		g_Texture = NULL;
	}

}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void UpdateRanking(void)
{
	
}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void DrawRanking(void)
{
	//�e�N�X�`���ݒ�
	GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture);

	for (int j = 0; j < 3; j++)
	{
		int score = g_score[j];

		for (int i = 0; i < MAX_DIGIT; i++)
		{
			//�X�v���C�g�`��
			DrawSpriteAnim(XMFLOAT2(NUMBER_X + NUMBER_WIDTH * 0.5f * (i + 1), NUMBER_Y + NUMBER_HEIGHT * j), 0.0f, XMFLOAT2(NUMBER_WIDTH, NUMBER_HEIGHT), 5, 5, score / (int)pow(10, MAX_DIGIT - 1 - i));
			score %= (int)pow(10, MAX_DIGIT - 1 - i);
		}
	}
}

