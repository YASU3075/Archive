//-----------------------------------------------
// ranking.h
//-----------------------------------------------

#pragma once

#include "renderer.h"

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------
#define NUMBER_WIDTH	(100.0f)
#define NUMBER_HEIGHT	(100.0f)
#define NUMBER_X		(765.0f)
#define NUMBER_Y		(300.0f)
#define MAX_DIGIT		(4)

//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------
void InitRanking(void);
void UninitRanking(void);
void UpdateRanking(void);
void DrawRanking(void);

