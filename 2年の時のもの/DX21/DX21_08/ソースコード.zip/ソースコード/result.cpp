//-----------------------------------------------
// result.cpp
// ������F2024/05/13
//-----------------------------------------------
#include "main.h"
#include "result.h"
#include "keyboard.h"
#include "sprite.h"
#include "score.h"
#include "ranking.h"

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------


//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------

//-----------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------
static ID3D11ShaderResourceView* g_Texture = NULL;
static ID3D11ShaderResourceView* g_Texture_result = NULL;
static ID3D11ShaderResourceView* g_Texture_audience = NULL;
static ID3D11ShaderResourceView* g_Texture_space = NULL;
int g_score;


//-----------------------------------------------
// ����������
//-----------------------------------------------
void InitResult(void)
{
	//ID3D11Device* pDevice = GetDevice();

	//�e�N�X�`���ǂݍ���
	TexMetadata metadata[4];
	ScratchImage image[4];
	
	LoadFromWICFile(L"asset\\texture\\BG.png" ,WIC_FLAGS_NONE, &metadata[0], image[0]);
	CreateShaderResourceView(GetDevice(), image[0].GetImages(), image[0].GetImageCount(), metadata[0], &g_Texture);
	assert(g_Texture);

	LoadFromWICFile(L"asset\\texture\\number.png", WIC_FLAGS_NONE, &metadata[1], image[1]);
	CreateShaderResourceView(GetDevice(), image[1].GetImages(), image[1].GetImageCount(), metadata[1], &g_Texture_result);
	assert(g_Texture_result);

	LoadFromWICFile(L"asset\\texture\\audience_num.png", WIC_FLAGS_NONE, &metadata[2], image[2]);
	CreateShaderResourceView(GetDevice(), image[2].GetImages(), image[2].GetImageCount(), metadata[2], &g_Texture_audience);
	assert(g_Texture_audience);

	LoadFromWICFile(L"asset\\texture\\press_space.png", WIC_FLAGS_NONE, &metadata[3], image[3]);
	CreateShaderResourceView(GetDevice(), image[3].GetImages(), image[3].GetImageCount(), metadata[3], &g_Texture_space);
	assert(g_Texture_space);

	g_score = GetScore();

	InitRanking();
}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void UninitResult(void)
{
	//�e�N�X�`���[�̉��
	if (g_Texture)
	{
		g_Texture->Release();
		g_Texture = NULL;
	}

	if (g_Texture_result)
	{
		g_Texture_result->Release();
		g_Texture_result = NULL;
	}

	if (g_Texture_audience)
	{
		g_Texture_audience->Release();
		g_Texture_audience = NULL;
	}

	if (g_Texture_space)
	{
		g_Texture_space->Release();
		g_Texture_space = NULL;
	}

	UninitRanking();
}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void UpdateResult(void)
{
	if (Keyboard_IsKeyDown(KK_SPACE))
	{
		SetScene(TITLE_SCENE);
	}

	UpdateRanking();
}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void DrawResult(void)
{
	//�e�N�X�`���ݒ�
	GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture);
	//�X�v���C�g�`��
	DrawSprite(XMFLOAT2(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT));

	//�e�N�X�`���ݒ�
	GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture_result);

	int score = g_score;

	for (int i = 0; i < MAX_DIGIT; i++)
	{
		//�X�v���C�g�`��
		DrawSpriteAnim(XMFLOAT2(480.0f + NUMBER_WIDTH * 0.5f * (i + 1), SCREEN_HEIGHT - 300.0f), 0.0f, XMFLOAT2(NUMBER_WIDTH, NUMBER_HEIGHT), 5, 5, score / (int)pow(10, MAX_DIGIT - 1 - i));
		score %= (int)pow(10, MAX_DIGIT - 1 - i);
	}

	//�e�N�X�`���ݒ�
	GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture_audience);
	//�X�v���C�g�`��
	DrawSprite(XMFLOAT2(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 4), 0.0f, XMFLOAT2(1000.0f, 300.0f));

	//�e�N�X�`���ݒ�
	GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture_space);
	//�X�v���C�g�`��
	DrawSprite(XMFLOAT2(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2 + 300.0f), 0.0f, XMFLOAT2(1000.0f, 300.0f));

	DrawRanking();
}

