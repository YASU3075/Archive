//-----------------------------------------------
// result.h
//-----------------------------------------------

#pragma once

#include "renderer.h"

//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------
void InitResult(void);
void UninitResult(void);
void UpdateResult(void);
void DrawResult(void);
