// -----------------------------------------------
// score.cpp
// ������F2024/06/19
//-----------------------------------------------
#include "score.h"
#include "sprite.h"

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------


//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------

//-----------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------
static ID3D11ShaderResourceView * g_Texture = NULL;
static int g_score;
static int g_old_score;

//-----------------------------------------------
// ����������
//-----------------------------------------------
void InitScore(void)
{
	//ID3D11Device* pDevice = GetDevice();

	//�e�N�X�`���ǂݍ���
	TexMetadata metadata;
	ScratchImage image;

	LoadFromWICFile(L"asset\\texture\\number.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &g_Texture);
	assert(g_Texture);

	g_score = 0;
	g_old_score = 0;
}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void UninitScore(void)
{
	//�e�N�X�`���[�̉��
	if (g_Texture)
	{
		g_Texture->Release();
		g_Texture = NULL;
	}

}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void UpdateScore(void)
{
	if (g_old_score < g_score)
	{
		g_old_score++;
	}
}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void DrawScore(void)
{
	//�e�N�X�`���ݒ�
	GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture);

	int score = g_old_score;

	for (int i = 0; i < MAX_DIGIT; i++)
	{
		//�X�v���C�g�`��
		DrawSpriteAnim(XMFLOAT2(NUMBER_X + NUMBER_WIDTH * 0.5f * (i + 1), NUMBER_HEIGHT * 0.5f), 0.0f, XMFLOAT2(NUMBER_WIDTH, NUMBER_HEIGHT), 5, 5, score / (int)pow(10, MAX_DIGIT - 1 - i));
		score %= (int)pow(10, MAX_DIGIT - 1 - i);
	}
}

//-----------------------------------------------
// �X�R�A���Z
//-----------------------------------------------
void AddScore(void)
{
	g_score += 10;
}

//-----------------------------------------------
// �X�R�A�̃Q�b�^�[
//-----------------------------------------------
int GetScore(void)
{
	return g_score;
}