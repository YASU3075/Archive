//-----------------------------------------------
// score.h
//-----------------------------------------------

#pragma once

#include "renderer.h"

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------
#define NUMBER_WIDTH	(100.0f)
#define NUMBER_HEIGHT	(100.0f)
#define NUMBER_X		(765.0f)
#define MAX_DIGIT		(4)

//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------
void InitScore(void);
void UninitScore(void);
void UpdateScore(void);
void DrawScore(void);
void AddScore(void);
int GetScore(void);
