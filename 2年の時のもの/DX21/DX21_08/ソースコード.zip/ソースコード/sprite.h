//-----------------------------------------------
// sprite.h
// ������F2024/06/19
// ����ҁF���c���l
//-----------------------------------------------
#pragma once

#include "renderer.h"

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------
#define DOT_SIZE		(10)

//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------
void InitSprite(void);
void UninitSprite(void);
void DrawSprite(XMFLOAT2 Position, float Rotation, XMFLOAT2 Scale);
void DrawSpriteColor(XMFLOAT2 Position, float Rotation, XMFLOAT2 Scale, XMFLOAT4 c = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f));
void DrawSpriteAnim(XMFLOAT2 Position, float Rotation, XMFLOAT2 Scale, int AnimCols, int AnimRows, int AnimPattern);
void DrawLine(XMINT2 start, XMINT2 finish, XMFLOAT4 c);