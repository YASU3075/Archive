//-----------------------------------------------
// title.cpp
// ������F2024/05/13
//-----------------------------------------------
#include "main.h"
#include "title.h"
#include "keyboard.h"
#include "sprite.h"
#include "fade.h"

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------


//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------

//-----------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------
static ID3D11ShaderResourceView* g_Texture = NULL;
static ID3D11ShaderResourceView* g_Texture_title = NULL;
static ID3D11ShaderResourceView* g_Texture_enter = NULL;

//-----------------------------------------------
// ����������
//-----------------------------------------------
void InitTitle(void)
{
	//ID3D11Device* pDevice = GetDevice();

	//�e�N�X�`���ǂݍ���
	TexMetadata metadata[3];
	ScratchImage image[3];
	
	LoadFromWICFile(L"asset\\texture\\BG.png" ,WIC_FLAGS_NONE, &metadata[0], image[0]);
	CreateShaderResourceView(GetDevice(), image[0].GetImages(), image[0].GetImageCount(), metadata[0], &g_Texture);
	assert(g_Texture);

	LoadFromWICFile(L"asset\\texture\\title.png", WIC_FLAGS_NONE, &metadata[1], image[1]);
	CreateShaderResourceView(GetDevice(), image[1].GetImages(), image[1].GetImageCount(), metadata[1], &g_Texture_title);
	assert(g_Texture_title);

	LoadFromWICFile(L"asset\\texture\\enter.png", WIC_FLAGS_NONE, &metadata[2], image[2]);
	CreateShaderResourceView(GetDevice(), image[2].GetImages(), image[2].GetImageCount(), metadata[2], &g_Texture_enter);
	assert(g_Texture_enter);
}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void UninitTitle(void)
{
	//�e�N�X�`���[�̉��
	if (g_Texture)
	{
		g_Texture->Release();
		g_Texture = NULL;
	}

	if (g_Texture_title)
	{
		g_Texture_title->Release();
		g_Texture_title = NULL;
	}

	if (g_Texture_enter)
	{
		g_Texture_enter->Release();
		g_Texture_enter = NULL;
	}
}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void UpdateTitle(void)
{
	if (Keyboard_IsKeyDown(KK_ENTER))
	{
		FadeOut();
	}

	if (IsFadeOutFinish())
	{
		SetScene(GAME_SCENE);
	}
}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void DrawTitle(void)
{
	//�e�N�X�`���ݒ�
	GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture);
	//�X�v���C�g�`��
	DrawSprite(XMFLOAT2(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT));

	//�e�N�X�`���ݒ�
	GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture_title);
	//�X�v���C�g�`��
	DrawSprite(XMFLOAT2(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 4), 0.0f, XMFLOAT2(1000.0f, 300.0f));

	//�e�N�X�`���ݒ�
	GetDeviceContext()->PSSetShaderResources(0, 1, &g_Texture_enter);
	//�X�v���C�g�`��
	DrawSprite(XMFLOAT2(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2 + 250.0f), 0.0f, XMFLOAT2(1000.0f, 300.0f));

}

