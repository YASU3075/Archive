//-----------------------------------------------
// title.h
//-----------------------------------------------

#pragma once

#include "renderer.h"

//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------
void InitTitle(void);
void UninitTitle(void);
void UpdateTitle(void);
void DrawTitle(void);
