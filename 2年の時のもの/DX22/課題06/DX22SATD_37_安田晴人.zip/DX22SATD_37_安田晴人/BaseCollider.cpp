//-----------------------------------------------
// BaseCollider.cpp
// ������F2024/12/11
// ����ҁF���c���l
//-----------------------------------------------
#include "BaseCollider.h"
#include "ColliderManager.h"

int BASE_COLLIDER::Register(COLLIDER_MANAGER* p_collider_manager)
{
	int ret = p_collider_manager->Register(this);
	return ret;
}