//-----------------------------------------------
// Box.h
// ������F2024/12/10
// ����ҁF���c���l
//-----------------------------------------------
#pragma once

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------
#define		BOX_MAX		(100)		//BOX�̐�
#define BOX_WIDTH	(2.0f)
#define BOX_HEIGHT	(2.0f)


//-----------------------------------------------
// �񋓑̐錾
//-----------------------------------------------
enum BOX_TYPE
{
	BOX_TYPE_NORMAL = 0,
	BOX_TYPE_FLOOR,			//��
	BOX_TYPE_WALL,			//��
};

#include "GameObject3D.h"

class BOX : public GAME_OBJECT_3D
{
private:
	BOX_TYPE m_type;
	ID3D11ShaderResourceView* m_texture;

public:
	void Init(void) override;
	void Uninit(void) override;
	void Update(void) override;
	void Draw(void) override;

	//�Z�b�^�[
	void SetType(BOX_TYPE type) { m_type = type; };

	//�Q�b�^�[
	BOX_TYPE GetType(void) { return m_type; };
};



void	InitBox();
void	UninitBox();
void	UpdateBox();
void	DrawBox();


