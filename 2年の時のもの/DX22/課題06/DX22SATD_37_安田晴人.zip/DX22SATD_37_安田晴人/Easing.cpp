//-----------------------------------------------
// Easing.cpp
// ������F2025/01/18
//-----------------------------------------------
#include "Easing.h"
#include "sprite.h"

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------
#define BEIZER_NUM			20

//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------
float TimeCheck(float time, float speed, int num);

//-----------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------
static EASING Easing[BEIZER_NUM];

// ������	main.cpp�ɓ˂�����
void InitEasing(void)
{
	for (int i = 0; i < BEIZER_NUM; i++)
	{
		Easing[i].posi = {};
		Easing[i].time = 0;
		Easing[i].isReset = true;
	}
}

// �eUpdata�ɓ˂�����



/*========================================================
// �Q�b�^�[
========================================================*/
EASING GetEasing(int num)
{
	return Easing[num];
}

/*========================================================
// ���ݒn�v�Z
* p0 �n�_
* p1 �x�_1
* p2 �x�_2
* p3 �I�_
* num �ԍ�
========================================================*/
void RecalBezier(XMFLOAT2 p0, XMFLOAT2 p1, XMFLOAT2 p2, XMFLOAT2 p3, int num)
{
	XMFLOAT2 P;			// �_P
	float t = Easing[num].time;

	float i = 1 - t;	// 1 - t

	P.x = pow(i, 3) * p0.x + 3 * t * pow(i, 2) * p1.x + 3 * pow(t, 2) * i * p2.x + pow(t, 3) * p3.x;
	P.y = pow(i, 3) * p0.y + 3 * t * pow(i, 2) * p1.y + 3 * pow(t, 2) * i * p2.y + pow(t, 3) * p3.y;

	Easing[num].posi = P;
}

/*========================================================
// �΂ߌv�Z
* p0 �n�_
* p1 �I�_
* num �ԍ�
========================================================*/
XMFLOAT2 DiagonalEasing(XMFLOAT2 p0, XMFLOAT2 p1, int num)
{
	if (Easing[num].isReset)
	{
		Easing[num].time = 0.0f;
		Easing[num].isReset = false;
	}

	XMFLOAT2 P;			// �_P

	float saX, saY;
	saX = p1.x - p0.x;
	saY = p1.y - p0.y;

	P.x = Easing[num].posi.y * saX + p0.x;
	P.y = Easing[num].posi.y * saY + p0.y;
	
	return P;
}

/*========================================================
// 3���x�W�F�l https://cubic-bezier.com/#.19,.85,.89,.13
* p0	���n�_
* p1	���I�_
* p2	�s���N�̓_
* p3	�̓_
* ���x
* ���[�v
* �ԍ�
========================================================*/
void Bezier(float speed, int num, XMFLOAT2 p2, XMFLOAT2 p3)
{
	RecalBezier(XMFLOAT2(0, 0), p2, p3, XMFLOAT2(1, 1), num);

	Easing[num].time = TimeCheck(Easing[num].time, speed, num);
}

/*========================================================
// Easing functions
* p0 �n�_
* p1 �I�_
* speed ���� 0.0�`1.0
* loop �J��Ԃ�
* num ���Ԃ̔ԍ�
========================================================*/
void easeInElastic(float speed, int num)
{
	Easing[num].time = TimeCheck(Easing[num].time, speed, num);

	float c4 = (2 * 3.14f) / 3;
	Easing[num].posi.y = -powf(2, 10 * Easing[num].time - 10) * sinf((Easing[num].time * 10 - 10.75) * c4);
}
void easeOutElastic(float speed, int num)
{
	Easing[num].time = TimeCheck(Easing[num].time, speed, num);

	float c4 = (2 * 3.14f) / 3;
	Easing[num].posi.y = powf(2, -10 * Easing[num].time) * sinf((Easing[num].time * 10 - 0.75) * c4) + 1;
}
void easeInOutElastic(float speed, int num)
{
	Easing[num].time = TimeCheck(Easing[num].time, speed, num);

	float c5 = (2 * 3.14f) / 4.5;

	if (Easing[num].time < 0.5f)
		Easing[num].posi.y = -(powf(2, 20 * Easing[num].time - 10) * sinf((20 * Easing[num].time - 11.125) * c5)) / 2;
	else
		Easing[num].posi.y = (powf(2, -20 * Easing[num].time + 10) * sinf((20 * Easing[num].time - 11.125) * c5)) / 2 + 1;
}
void easeInBounce(float speed, int num)
{
	Easing[num].time = TimeCheck(Easing[num].time, speed, num);

	float time = 1 - Easing[num].time;

	float n1 = 7.5625f;
	float d1 = 2.75f;

	if (time < 1.0f / d1) {
		Easing[num].posi.y = 1 - (n1 * time * time);
	}
	else if (time < 2.0f / d1) {
		Easing[num].posi.y = 1 - (n1 * (time -= 1.5f / d1) * time + 0.75f);
	}
	else if (time < 2.5f / d1) {
		Easing[num].posi.y = 1 - (n1 * (time -= 2.25f / d1) * time + 0.9375f);
	}
	else {
		Easing[num].posi.y = 1 - (n1 * (time -= 2.625f / d1) * time + 0.984375f);
	}
}
void easeOutBounce(float speed, int num)
{
	Easing[num].time = TimeCheck(Easing[num].time, speed, num);

	float time = Easing[num].time;

	float n1 = 7.5625f;
	float d1 = 2.75f;

	if (time < 1.0f / d1) {
		Easing[num].posi.y = n1 * time * time;
	}
	else if (time < 2.0f / d1) {
		Easing[num].posi.y = n1 * (time -= 1.5f / d1) * time + 0.75f;
	}
	else if (time < 2.5f / d1) {
		Easing[num].posi.y = n1 * (time -= 2.25f / d1) * time + 0.9375f;
	}
	else {
		Easing[num].posi.y = n1 * (time -= 2.625f / d1) * time + 0.984375f;
	}
}
void easeInOutBounce(float speed, int num)
{
	Easing[num].time = TimeCheck(Easing[num].time, speed, num);

	float time;
	float n1 = 7.5625f;
	float d1 = 2.75f;

	if (Easing[num].time < 0.5)
		time = 1 - 2 * Easing[num].time;
	else
		time = 2 * Easing[num].time - 1;

	if (time < 1.0f / d1) {
		Easing[num].posi.y = n1 * time * time;
	}
	else if (time < 2.0f / d1) {
		Easing[num].posi.y = n1 * (time -= 1.5f / d1) * time + 0.75f;
	}
	else if (time < 2.5f / d1) {
		Easing[num].posi.y = n1 * (time -= 2.25f / d1) * time + 0.9375f;
	}
	else {
		Easing[num].posi.y = n1 * (time -= 2.625f / d1) * time + 0.984375f;
	}

	if (Easing[num].time < 0.5)
		Easing[num].posi.y = (1 - Easing[num].posi.y) / 2;
	else
		Easing[num].posi.y = (1 + Easing[num].posi.y) / 2;
}



// ���[�v���邩�A���Z�b�g�����邩�m�F
float TimeCheck(float time, float speed, int num)
{
	time += speed;
	if (1.0f + 60 * speed < time)
	{
		Easing[num].isReset = true;
		return 0;
	}
	return time;
}

// �蓮
void TimeReset(int num)
{
	Easing[num].time = 0.0f;
}