//-----------------------------------------------
// Game.h
// ������F2024/12/10
// ����ҁF���c���l
//-----------------------------------------------
#include "Game.h"
#include "GameObject3D.h"
#include "Ball.h"
#include <string>
#include "Player.h"
#include "Enemy.h"
#include "ColliderManager.h"
#include "BoxCollider.h"
#include "SphereCollider.h"
#include "SceneManager.h"
#include "keyboard.h"

//-----------------------------------------------
// ����������
//-----------------------------------------------
void GAME::Init(void)
{
	m_p_collider_manager = new COLLIDER_MANAGER();

	m_p_collider_manager->Init();

	for (int i = 0; i < MAX_GAMEOBJECT_NUM; i++)
	{
		m_p_game_object[i] = nullptr;
	}

	m_p_camera[0] = new CAMERA(XMFLOAT3(0.0f, 3.0f, -5.0f), XMFLOAT3(1.0f, 3.0f, 1.0f));
	m_p_camera[1] = new CAMERA(XMFLOAT3(50.0f, 30.0f, 50.0f), XMFLOAT3(0.0f, -10.0f, 0.0f));
	m_p_camera[2] = new CAMERA(XMFLOAT3(-1.0f, 5.0f, 50.0f), XMFLOAT3(10.0f, 0.0f, 0.0f));
	

	m_p_camera[0]->Init();
	m_p_camera[1]->Init();
	m_p_camera[2]->Init();
	
	

	m_p_light = new LIGHT();

	m_p_map = new MAP();

	m_p_map->Init();

	GAME_OBJECT_3D* player = new PLAYER(this, m_p_camera[0], m_p_collider_manager, "PLAYER", XMFLOAT3(1.0f, 3.0f, 1.0f), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT3(1.0f, 1.0f, 1.0f), XMFLOAT4(0.0f, 1.0f, 0.0f, 1.0f), 0.0f);
	GAME_OBJECT_3D* enemy = new ENEMY(this, "ENEMY", XMFLOAT3(10.0f, 2.0f, 5.0f), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT3(2.0f, 2.0f, 2.0f), XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f), 1.0f);

	this->Register(player);
	this->Register(enemy);

	player->SetColliderIndex(m_p_collider_manager->Register(new SPHERE_COLLIDER(player, player->GetTag())));
	enemy->SetColliderIndex(m_p_collider_manager->Register(new BOX_COLLIDER(enemy, enemy->GetTag())));

	for (int i = 0; i < MAX_GAMEOBJECT_NUM; i++)
	{
		if (m_p_game_object[i])
		{
			m_p_game_object[i]->Init();
		}
	}


	//���C�g�\���̂̏�����
	m_p_light->Direction = XMFLOAT4(1.0f, -1.0f, 1.0f, 0.0f);
	m_p_light->Diffuse = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
	m_p_light->Ambient = XMFLOAT4(0.5f, 0.5f, 0.5f, 1.0f);
	XMVECTOR vec = XMLoadFloat4(&m_p_light->Direction);
	vec = XMVector4Normalize(vec);
	XMStoreFloat4(&m_p_light->Direction, vec);
}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void GAME::Uninit(void)
{
	m_p_camera[0]->Uninit();
	m_p_camera[1]->Uninit();
	m_p_camera[2]->Uninit();
	

	m_p_map->Uninit();

	m_p_collider_manager->Uninit();

	for (int i = 0; i < MAX_GAMEOBJECT_NUM; i++)
	{
		if (m_p_game_object[i])
		{
			delete m_p_game_object[i];
		}
	}

	
}

//-----------------------------------------------
// �o�^����
//-----------------------------------------------
void GAME::Register(GAME_OBJECT_3D* p_object)
{
	for (int i = 0; i < MAX_GAMEOBJECT_NUM; i++)
	{
		if (!m_p_game_object[i])
		{
			m_p_game_object[i] = p_object;
			m_p_game_object[i]->SetGame(this);
			break;
		}
	}
}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void GAME::Update(void)
{
	if (Keyboard_IsKeyDownTrigger(KK_D1))
	{
		m_camera_num = 0;
	}

	else if (Keyboard_IsKeyDownTrigger(KK_D2))
	{
		m_camera_num = 1;
	}

	else if (Keyboard_IsKeyDownTrigger(KK_D3))
	{
		m_camera_num = 2;
	}

	m_p_camera[0]->Update();
	
	m_p_map->Update();

	for (int i = 0; i < MAX_GAMEOBJECT_NUM; i++)
	{
		if (m_p_game_object[i])
		{
			m_p_game_object[i]->Update();
		}
	}

	m_p_collider_manager->Update();

	for (int i = 0; i < MAX_GAMEOBJECT_NUM; i++)
	{
		if (m_p_game_object[i])
		{
			if (m_p_game_object[i]->IsDestroy())
			{
				m_p_collider_manager->Destroy(m_p_game_object[i]->GetColliderIndex());
				delete m_p_game_object[i];
				m_p_game_object[i] = nullptr;
			}
		}
	}

	int count = 0;
	for (int i = 0; i < MAX_GAMEOBJECT_NUM; i++)
	{
		if (m_p_game_object[i])
		{
			if (m_p_game_object[i]->GetTag() == "ENEMY")
			{
				count++;
			}
		}
	}

	if (count <= 0)
	{
		m_p_scene_manager->ChangeScene(SCENE_TITLE);
	}

}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void GAME::Draw(void)
{
	SetWorldViewProjection3D();
	SetDepthEnable(true);
	SetLight(*m_p_light);

	m_p_camera[m_camera_num]->Draw();
	
	m_p_map->Draw();

	for (int i = 0; i < MAX_GAMEOBJECT_NUM; i++)
	{
		if (m_p_game_object[i])
		{
			m_p_game_object[i]->Draw();
		}
	}

	m_p_collider_manager->Draw();
}

//-----------------------------------------------
// tag�ŃI�u�W�F�N�g�擾
//-----------------------------------------------
GAME_OBJECT_3D_CONTAINER GAME::GetGameObjectContainer(std::string tag)
{
	//�Ώۂ̐��𐔂���
	int count = 0;
	for (int i = 0; i < MAX_GAMEOBJECT_NUM; i++)
	{
		if (m_p_game_object[i] && m_p_game_object[i]->GetTag() == tag)
		{
			count++;
		}
	}
	GAME_OBJECT_3D_CONTAINER ret(count);

	count = 0;

	//�Q�[���I�u�W�F�N�g�R���e�i�ɑΏۂ̃|�C���^���l�߂�
	for (int i = 0; i < MAX_GAMEOBJECT_NUM; i++)
	{
		if (m_p_game_object[i] && m_p_game_object[i]->GetTag() == tag)
		{
			ret.SetGameObject(count++, m_p_game_object[i]);
		}
	}

	return ret;
}

//-----------------------------------------------
// �����蔻��ŃI�u�W�F�N�g�擾
//-----------------------------------------------
GAME_OBJECT_3D_CONTAINER GAME::GetGameObjectContainer(int collider_id)
{
	//�Ώۂ̐��𐔂���
	BASE_COLLIDER* p_collider = m_p_collider_manager->GetCollider(collider_id);

	int count = 0;
	for (int i = 0; i < MAX_GAMEOBJECT_NUM; i++)
	{
		if (m_p_game_object[i] && m_p_collider_manager->GetCollision(*p_collider, *m_p_collider_manager->GetCollider(m_p_game_object[i]->GetColliderIndex())))
		{
			count++;
		}
	}
	GAME_OBJECT_3D_CONTAINER ret(count);

	count = 0;

	//�Q�[���I�u�W�F�N�g�R���e�i�ɑΏۂ̃|�C���^���l�߂�
	for (int i = 0; i < MAX_GAMEOBJECT_NUM; i++)
	{
		if (m_p_game_object[i] && m_p_collider_manager->GetCollision(*p_collider, *m_p_collider_manager->GetCollider(m_p_game_object[i]->GetColliderIndex())))
		{
			ret.SetGameObject(count++, m_p_game_object[i]);
		}
	}

	return ret;
}
