//-----------------------------------------------
// Result.h
// ������F2024/12/10
// ����ҁF���c���l
//-----------------------------------------------
#pragma once
#include "BaseScene.h"

class RESULT : public BASE_SCENE
{
private:

public:
	RESULT(class SCENE_MANAGER* p_scene_manager) : BASE_SCENE(p_scene_manager) {}
	~RESULT() {}

	void Init(void) override;
	void Uninit(void) override;
	void Update(void) override;
	void Draw(void) override;
};
