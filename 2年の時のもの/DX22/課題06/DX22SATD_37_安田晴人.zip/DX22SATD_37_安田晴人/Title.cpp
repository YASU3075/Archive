//-----------------------------------------------
// Title.h
// ������F2024/12/10
// ����ҁF���c���l
//-----------------------------------------------
#include "Title.h"
#include "sprite.h"
#include "Sprite3D.h"
#include "keyboard.h"
#include "SceneManager.h"
#include "Easing.h"

void	debugSprite(XMFLOAT3 position, float rotate, XMFLOAT2 size, XMFLOAT4 color)
{
	//	//���s�ړ��s��̍쐬�i�\�����W�����߂�j
	XMMATRIX	TranslationMatrix = XMMatrixTranslation(
		position.x, position.y, 0.0f);

	//��]�s��iZ��]�j�s��̍쐬
	XMMATRIX	RotationMatrix = XMMatrixRotationZ(XMConvertToRadians(rotate));

	//�X�P�[�����O�s��쐬�i�{��1.0�����{�A0�{�̓_���I�j
	XMMATRIX	ScalingMatrix = XMMatrixIdentity();

	//���[���h�s��̍쐬�i�|���S���̕\���̎d�����w�肷��ŏI�I�ȍs��
	XMMATRIX	WorldMatrix = ScalingMatrix * RotationMatrix * TranslationMatrix;

	//���[���h�s���DirectX�փZ�b�g
	SetWorldMatrix(WorldMatrix);

	DrawSprite(size, color);
}

//-----------------------------------------------
// ����������
//-----------------------------------------------
void TITLE::Init(void)
{
	m_p_camera = new CAMERA;
	m_p_camera->Init();

	//�e�N�X�`���̓ǂݍ���
	TexMetadata		metadata1;
	ScratchImage	image1;

	LoadFromWICFile(L"asset\\texture\\enter.png", WIC_FLAGS_NONE, &metadata1, image1);
	CreateShaderResourceView(GetDevice(), image1.GetImages(), image1.GetImageCount(), metadata1, &m_texture_enter);
	assert(m_texture_enter);

	TexMetadata		metadata;
	ScratchImage	image;

	LoadFromWICFile(L"asset\\texture\\title.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture);
	assert(m_texture);

	m_p_light = new LIGHT();

	//���C�g�\���̂̏�����
	m_p_light->Direction = XMFLOAT4(1.0f, -1.0f, 1.0f, 0.0f);
	m_p_light->Diffuse = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
	m_p_light->Ambient = XMFLOAT4(0.5f, 0.5f, 0.5f, 1.0f);
	XMVECTOR vec = XMLoadFloat4(&m_p_light->Direction);
	vec = XMVector4Normalize(vec);
	XMStoreFloat4(&m_p_light->Direction, vec);

	TimeReset(0);
	TimeReset(1);
	TimeReset(2);
}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void TITLE::Uninit(void)
{
	m_p_camera->Uninit();
}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void TITLE::Update(void)
{
	m_frame_count++;
	if (m_frame_count >= 360.0f)
	{
		m_frame_count = 0;
		TimeReset(0);
		TimeReset(1);
		TimeReset(2);
		m_easing = true;
	}

	if (Keyboard_IsKeyDownTrigger(KK_ENTER))
	{
		m_p_scene_manager->ChangeScene(SCENE_GAME);
	}
}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void TITLE::Draw(void)
{
	SetWorldViewProjection2D();
	SetDepthEnable(false);

	
	easeOutBounce(1.0f / 360.0f, 0);
	float sca = GetEasing(0).posi.y;
	
	easeInOutBounce(1.0f / 360.0f, 2);
	float pos = GetEasing(2).posi.y;

	easeInOutElastic(1.0f / 360.0f, 1);
	float alpha = GetEasing(1).posi.y;
	if (m_easing)
	{
		sca = 1.0f;
		pos = 1.0f;
		alpha = 1.0f;
	}

	GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture);
	debugSprite(XMFLOAT3(SCREEN_WIDTH * 0.5f, SCREEN_HEIGHT * 0.5f * pos, 0.0f), 0.0f, XMFLOAT2(1600.0f * sca, 200.0f * sca), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f));

	GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_enter);
	debugSprite(XMFLOAT3(SCREEN_WIDTH * 0.5f, SCREEN_HEIGHT * 0.5f + 300.0f, 0.0f), 0.0f, XMFLOAT2(1000.0f, 200.0f), XMFLOAT4(1.0f, 1.0f, 1.0f, alpha));
}