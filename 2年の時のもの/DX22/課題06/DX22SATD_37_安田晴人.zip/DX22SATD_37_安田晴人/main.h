/*==============================================================================

   ���ʃw�b�_�[ [main.h]
                                                         Author : 
                                                         Date   : 
--------------------------------------------------------------------------------

==============================================================================*/
#pragma once

#define NOMINMAX

#pragma warning(push)
#pragma warning(disable:4005)

#define _CRT_SECURE_NO_WARNINGS			// scanf ��warning�h�~
#include <stdio.h>

#include <d3d11.h>
#include <d3dcompiler.h>

#define DIRECTINPUT_VERSION 0x0800		// �x���Ώ�
#include "dinput.h"
#include "mmsystem.h"

#pragma warning(pop)

//*****************************************************************************
// �}�N����`
//*****************************************************************************
#define SCREEN_WIDTH	(1920)				// �E�C���h�E�̕�
#define SCREEN_HEIGHT	(1080)				// �E�C���h�E�̍���


//*****************************************************************************
// �v���g�^�C�v�錾
//*****************************************************************************



class MAIN_MANAGER
{
private:
    class SCENE_MANAGER* m_p_scene_manager = nullptr;

public:
    MAIN_MANAGER() {}         //�R���X�g���N�^
    ~MAIN_MANAGER() {}        //�f�X�g���N�^

    //�������֐�
    HRESULT	Init(HINSTANCE hInstance, HWND hWnd, BOOL bWindow);
    //�I������
    void	Uninit(void);
    //�X�V����
    void	Update(void);
    //�`�揈��
    void	Draw(void);
};


#include <DirectXMath.h>
using namespace DirectX;

#include "DirectXTex.h"//<<<<

#if _DEBUG
#pragma comment(lib, "DirectXTex_Debug.lib")
#else
#pragma comment(lib, "DirectXTex_Release.lib")
#endif
