/*==============================================================================

   ���_�Ǘ� [sprite.cpp]
														 Author :
														 Date   :
--------------------------------------------------------------------------------

==============================================================================*/
#include	"main.h"
#include	"sprite.h"

//*****************************************************************************
// �}�N����`
//*****************************************************************************
#define NUM_SPRITEVERTEX 4

//*****************************************************************************
// �v���g�^�C�v�錾
//*****************************************************************************
void SetVertex2D(void);

struct VERTEX_T
{
	XMFLOAT2 pos;
	XMFLOAT2 vec;
	XMFLOAT4 color;
	XMFLOAT2 texCoord;
};

static VERTEX_T g_Vertex[NUM_SPRITEVERTEX];

//*****************************************************************************
// �O���[�o���ϐ�
//*****************************************************************************
static ID3D11Buffer				*g_VertexBuffer = NULL;		// ���_���

//=============================================================================
// ����������
//=============================================================================
HRESULT InitSprite(void)
{
	ID3D11Device *pDevice = GetDevice();

	// ���_�o�b�t�@����
	D3D11_BUFFER_DESC bd;
	ZeroMemory(&bd, sizeof(bd));
	bd.Usage = D3D11_USAGE_DYNAMIC;
	bd.ByteWidth = sizeof(VERTEX_3D) * NUM_SPRITEVERTEX;
	bd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	bd.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	GetDevice()->CreateBuffer(&bd, NULL, &g_VertexBuffer);

	g_Vertex[0].pos.x = -0.5f;
	g_Vertex[0].pos.y = -0.5f;
	g_Vertex[0].color = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
	g_Vertex[0].texCoord = XMFLOAT2(0.0f, 0.0f);

	g_Vertex[1].pos.x = 0.5f;
	g_Vertex[1].pos.y = -0.5f;
	g_Vertex[1].color = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
	g_Vertex[1].texCoord = XMFLOAT2(1.0f, 0.0f);

	g_Vertex[2].pos.x = -0.5f;
	g_Vertex[2].pos.y = 0.5f;
	g_Vertex[2].color = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
	g_Vertex[2].texCoord = XMFLOAT2(0.0f, 1.0f);

	g_Vertex[0].pos.x = 0.5f;
	g_Vertex[0].pos.y = 0.5f;
	g_Vertex[0].color = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
	g_Vertex[0].texCoord = XMFLOAT2(1.0f, 1.0f);

	SetVertex2D();

	return S_OK;
}

//=============================================================================
// �I������
//=============================================================================
void UninitSprite(void)
{
	// ���_�o�b�t�@�̉��
	if (g_VertexBuffer)
	{
		g_VertexBuffer->Release();
		g_VertexBuffer = NULL;
	}
}

//=============================================================================
// �`�揈��
//====================
void DrawSpriteUI(XMFLOAT3 pos, XMFLOAT3 sca, float rot, XMFLOAT4 color, int xnum, int ynum, int anim)
{
	UINT stride = sizeof(VERTEX_3D);
	UINT offset = 0;
	GetDeviceContext()->IASetVertexBuffers(0, 1, &g_VertexBuffer, &stride, &offset);

	XMMATRIX TranslationMatrix = XMMatrixTranslation(SCREEN_WIDTH * 0.5f + pos.x, SCREEN_HEIGHT * 0.5f + pos.y, pos.z);
	XMMATRIX RotationMatrix = XMMatrixRotationZ(XMConvertToRadians(rot));
	XMMATRIX ScalingMatirx = XMMatrixScaling(sca.x, sca.y, 1.0f);
	XMMATRIX WorldMatrix = ScalingMatirx * RotationMatrix * TranslationMatrix;

	SetWorldMatrix(WorldMatrix);

	float x, y;
	x = anim % xnum;
	y = anim / ynum;

	g_Vertex[0].texCoord = XMFLOAT2((1.0f / xnum) * x, 1.0f / ynum * y);
	g_Vertex[1].texCoord = XMFLOAT2((1.0f / xnum) * (x + 1), 1.0f / ynum * y);
	g_Vertex[2].texCoord = XMFLOAT2((1.0f / xnum) * x, 1.0f / ynum * (y + 1));
	g_Vertex[3].texCoord = XMFLOAT2((1.0f / xnum) * (x + 1), 1.0f / ynum * (y + 1));

	GetDeviceContext()->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);

	MATERIAL material;
	ZeroMemory(&material, sizeof(material));
	material.Diffuse = color;
	SetMaterial(material);

	SetVertex2D();

	GetDeviceContext()->Draw(4, 0);
}

void DrawSprite(XMFLOAT2 size, XMFLOAT4 color)
{

	//���_�̍쐬
	D3D11_MAPPED_SUBRESOURCE msr;
	GetDeviceContext()->Map(g_VertexBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &msr);

	VERTEX_3D* vertex = (VERTEX_3D*)msr.pData;

	float size_W = size.x * 0.5f;
	float size_H = size.y * 0.5f;

	//���� ���S����T�C�Y�̔����̏ꏊ�ō��W�����
	vertex[0].Position = XMFLOAT3(-size_W, -size_H, 0.0f);
	vertex[0].Diffuse = color;
	vertex[0].TexCoord = XMFLOAT2(0.0f, 0.0f);
	//�E�� ���S����T�C�Y�̔����̏ꏊ�ō��W�����
	vertex[1].Position = XMFLOAT3(size_W, -size_H, 0.0f);
	vertex[1].Diffuse = color;
	vertex[1].TexCoord = XMFLOAT2(1.0f, 0.0f);
	//���� ���S����T�C�Y�̔����̏ꏊ�ō��W�����
	vertex[2].Position = XMFLOAT3(-size_W, size_H, 0.0f);
	vertex[2].Diffuse = color;
	vertex[2].TexCoord = XMFLOAT2(0.0f, 1.0f);
	//�E�� ���S����T�C�Y�̔����̏ꏊ�ō��W�����
	vertex[3].Position = XMFLOAT3(size_W, size_H, 0.0f);
	vertex[3].Diffuse = color;
	vertex[3].TexCoord = XMFLOAT2(1.0f, 1.0f);

	GetDeviceContext()->Unmap(g_VertexBuffer, 0);


	// ���_�o�b�t�@�ݒ�
	UINT stride = sizeof(VERTEX_3D);
	UINT offset = 0;
	GetDeviceContext()->IASetVertexBuffers(0, 1, &g_VertexBuffer, &stride, &offset);

	// �v���~�e�B�u�g�|���W�ݒ�
	GetDeviceContext()->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);

	// �}�e���A���ݒ�
	MATERIAL material;
	ZeroMemory(&material, sizeof(material));
	material.Diffuse = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
	SetMaterial(material);

	// �|���S���`��
	GetDeviceContext()->Draw(4, 0);
}

void SetVertex2D(void)
{
	D3D11_MAPPED_SUBRESOURCE msr;
	GetDeviceContext()->Map(g_VertexBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &msr);
	VERTEX_3D* vertex = (VERTEX_3D*)msr.pData;
	for (int i = 0; i < NUM_SPRITEVERTEX; i++)
	{
		vertex[i].Position = XMFLOAT3(g_Vertex[i].pos.x, g_Vertex[i].pos.y, 0.0f);
		vertex[i].Diffuse = g_Vertex[i].color;
		vertex[i].TexCoord = g_Vertex[i].texCoord;
	}

	GetDeviceContext()->Unmap(g_VertexBuffer, 0);
}