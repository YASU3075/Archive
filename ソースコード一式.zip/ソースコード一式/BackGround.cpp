//-----------------------------------------------
// BackGround.cpp
// ������F2024/11/11
// ����ҁF���c���l
//-----------------------------------------------
#include "BackGround.h"
#include "sprite.h"
#include "camera.h"

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------
#define FOG_DIVISION_NUM		(1000)		//���摜�̕�����

//-----------------------------------------------
// ����������
//-----------------------------------------------
void BACK_GROUND::InitBackGround(void)
{
	//�e�N�X�`���ǂݍ���
	TexMetadata metadata;
	ScratchImage image;

	//�e�N�X�`��
	//�w�i�̌����i�O�j
	LoadFromWICFile(L"Asset\\Texture\\Environment\\City_ver2_01.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_front);
	assert(m_texture_front);
	//�w�i�̌����i�^�񒆁j
	LoadFromWICFile(L"Asset\\Texture\\Environment\\City_ver2_02.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_mid);
	assert(m_texture_mid);
	//�w�i�̌����i���j
	LoadFromWICFile(L"Asset\\Texture\\Environment\\City_ver2_03.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_back);
	assert(m_texture_back);
	//�w�i
	LoadFromWICFile(L"Asset\\Texture\\Environment\\bg008.jpg", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_bg);
	assert(m_texture_bg);
	//��
	LoadFromWICFile(L"Asset\\Texture\\Environment\\��_ver02_01.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_fog);
	assert(m_texture_fog);
	//�`���[�g���A���p�w�i
	LoadFromWICFile(L"Asset\\Texture\\Tutorial\\Concrete.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_tutorial_bg);
	assert(m_texture_tutorial_bg);

}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void BACK_GROUND::UninitBackGround(void)
{
	//�e�e�N�X�`�����
	if (m_texture_front)
	{
		m_texture_front->Release();
		m_texture_front = NULL;
	}
	if (m_texture_mid)
	{
		m_texture_mid->Release();
		m_texture_mid = NULL;
	}
	if (m_texture_back)
	{
		m_texture_back->Release();
		m_texture_back = NULL;
	}
	if (m_texture_bg)
	{
		m_texture_bg->Release();
		m_texture_bg = NULL;
	}
	if (m_texture_fog)
	{
		m_texture_fog->Release();
		m_texture_fog = NULL;
	}
	if (m_texture_tutorial_bg)
	{
		m_texture_tutorial_bg->Release();
		m_texture_tutorial_bg = NULL;
	}
}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void BACK_GROUND::UpdateBackGround(void)
{
	//�t���[������
	m_fog_frame_count++;

	if (m_fog_frame_count >= FOG_DIVISION_NUM)
	{//�t���[�����Z�b�g
		m_fog_frame_count = 0;
	}
}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void BACK_GROUND::DrawBackGround(void)
{
	//�w�i�`��
	GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_bg);
	DrawSprite(m_p_network_manager->GetType(), m_pos, 0.0f, XMFLOAT2(SCREEN_WIDTH * 3.0f, SCREEN_HEIGHT * 1.3f), XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f), 1, 1, 0);

	//���`��
	GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_fog);
	DrawSpriteUI(m_p_network_manager->GetType(), XMFLOAT2(0.0f, 0.0f), 0.0f, XMFLOAT2(SCREEN_WIDTH * 3.0f, SCREEN_HEIGHT), XMFLOAT4(0.5f, 0.5f, 0.5f, 0.5f), 1, FOG_DIVISION_NUM, m_fog_frame_count);

	//�J�����擾
	CAMERA* p_camera = GetCamera();
	float x = p_camera->GetCameraPos().x * -1.0f;

	//�w�i�̌����`��
	GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_back);
	DrawSprite(m_p_network_manager->GetType(), XMFLOAT2(x * 0.1f, -SCREEN_HEIGHT * 0.5f), 0.0f, XMFLOAT2(SCREEN_WIDTH * 6.0f, SCREEN_HEIGHT * 2.0f), m_color, 1, 1, 0);

	GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_mid);
	DrawSprite(m_p_network_manager->GetType(), XMFLOAT2(x * 0.1f, -SCREEN_HEIGHT * 0.5f), 0.0f, XMFLOAT2(SCREEN_WIDTH * 6.0f, SCREEN_HEIGHT * 2.0f), m_color, 1, 1, 0);

	GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_front);
	DrawSprite(m_p_network_manager->GetType(), XMFLOAT2(x * 0.1f, -SCREEN_HEIGHT * 0.5f), 0.0f, XMFLOAT2(SCREEN_WIDTH * 6.0f, SCREEN_HEIGHT * 2.0f), m_color, 1, 1, 0);
}

void BACK_GROUND::DrawTutorialBackGround(void)
{
	//�J�����擾
	CAMERA* p_camera = GetCamera();
	float x = p_camera->GetCameraPos().x * -1.0f;
	//�`���[�g���A���w�i�`��
	GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_tutorial_bg);
	DrawSprite(m_p_network_manager->GetType(), XMFLOAT2(x * 0.1f, -SCREEN_HEIGHT * 0.5f), 0.0f, XMFLOAT2(SCREEN_WIDTH * 3.0, SCREEN_HEIGHT * 2.0f), m_color, 1, 1, 0);
}