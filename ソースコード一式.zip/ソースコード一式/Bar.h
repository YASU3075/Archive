#pragma once
//-----------------------------------------------
// Ber.cpp
// ����ҁF�V�c����
// ������F2024/11/05		�X�V���F2024/11/05
//-----------------------------------------------
#include "NetworkManager.h"

void InitBer(void);

void UninitBer(void);

void UpdateBer(void);

void DrawBarToRight(USER_TYPE type, XMFLOAT2 pos, XMFLOAT2 scale, XMFLOAT4 c, float value, float max_value);
void DrawBarToRightColor(USER_TYPE type, XMFLOAT2 pos, XMFLOAT2 scale, XMFLOAT4 c1, XMFLOAT4 c2, XMFLOAT4 c3, XMFLOAT4 c4, float value, float max_value);
void DrawBarToLeft(USER_TYPE type, XMFLOAT2 pos, XMFLOAT2 scale, XMFLOAT4 c, float value, float max_value);
void DrawBarToLeftColor(USER_TYPE type, XMFLOAT2 pos, XMFLOAT2 scale, XMFLOAT4 c1, XMFLOAT4 c2, XMFLOAT4 c3, XMFLOAT4 c4, float value, float max_value);