//==========================================
// BulletManager.cpp
// �����:2024/11/26
// �����:�c����
// �X�V���F2024/12/03		�X�V�ҁF���c���l
//==========================================

#include"BulletManager.h"
#include"PlayerBullet.h"

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------


void BULLET_MANAGER::Init(void)
{
	for (int i = 0; i < MAX_PLAYER_BULLET; i++)
	{
		m_p_player_bullet[i] = nullptr;
	}

	app_atomex_initialize(&m_bullet_manager_app_obj, bullet_cue_list, sizeof(bullet_cue_list) / sizeof(CueInfo), ACF_PATH, BULLET_SE_ACB, BULLET_SE_AWB);
}



void BULLET_MANAGER::UnInit()
{
	for (int i = 0; i < MAX_PLAYER_BULLET; i++)
	{
		if (m_p_player_bullet[i] != nullptr)
		{
			m_p_player_bullet[i]->UnInit();
		}
	}

	app_atomex_finalize(&m_bullet_manager_app_obj);
}

void BULLET_MANAGER::Update(void)
{
	int num = 0;
	for (int i = 0; i < MAX_PLAYER_BULLET; i++)
	{
		if (m_p_player_bullet[i] != nullptr)
		{
			m_p_player_bullet[i]->Update();
			num++;
		}
	}
	if (num > 0)
	{
		m_bullet_manager_app_obj.ui_cue_index = CRI_ROBOTSE_ROBO_MISILE_FLYING;
		app_atomex_start(&m_bullet_manager_app_obj);
	}
}

void BULLET_MANAGER::Draw(void)
{
	for (int i = 0; i < MAX_PLAYER_BULLET; i++)
	{
		if (m_p_player_bullet[i] != nullptr)
		{
			m_p_player_bullet[i]->Draw();
		}
	}
}

int BULLET_MANAGER::SetPlayerBullet(XMFLOAT3 pos, XMFLOAT3 vec, XMFLOAT2 scale)
{
	for (int i = 0; i < MAX_PLAYER_BULLET; i++)
	{
		if (m_p_player_bullet[i] == nullptr)
		{
			m_p_player_bullet[i] = new PLAYER_BULLET(pos, vec, scale, m_p_network_manager, m_p_effect_manager);
			m_p_player_bullet[i]->Init();
			return i;
			break;
		}
	}

	//�G���[
	return -1;
}

PLAYER_BULLET* BULLET_MANAGER::GetPlayerBullet(int id)
{
	if (m_p_player_bullet)
	{
		return m_p_player_bullet[id];
	}
	else
	{
		return nullptr;
	}
}

void BULLET_MANAGER::DeletePlayerBullet(int id)
{
	if (m_p_player_bullet[id])
	{
		app_atomex_stop_player(&m_bullet_manager_app_obj);
		m_bullet_manager_app_obj.ui_cue_index = CRI_ROBOTSE_ROBO_MISILE_FIRE;
		app_atomex_start(&m_bullet_manager_app_obj);

		m_p_effect_manager->SetEffect(60, m_p_player_bullet[id]->GetPos(), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(m_p_player_bullet[id]->GetScale().x * 1.5f, m_p_player_bullet[id]->GetScale().y * 1.5f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_EXPLOSION, LAYER_ENEMY);
		m_p_player_bullet[id]->UnInit();
		delete m_p_player_bullet[id];
		m_p_player_bullet[id] = nullptr;
	}
}