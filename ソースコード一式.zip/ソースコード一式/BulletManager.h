//==========================================
// PlayerBullet.h
// �����:2024/11/26
// �����:�c����
// �X�V���F2024/12/03		�X�V�ҁF���c���l
//==========================================
#pragma once
#include"PlayerBullet.h"
#include "NetworkManager.h"
#include "EffectManager.h"
#include "RobotSE.h"
#include "Criplayer.h"

#define MAX_PLAYER_BULLET		(64)

#define BULLET_SE_ACB	"Asset\\Sound\\RobotSE.acb"
#define BULLET_SE_AWB	"Asset\\Sound\\RobotSE.awb"

static CueInfo bullet_cue_list[] =
{
	CRI_ROBOTSE_MACHINE_ANBIENTNOISE,
	CRI_ROBOTSE_ROBO_GAMEOVER,
	CRI_ROBOTSE_ROBO_DAMAGE,
	CRI_ROBOTSE_ROBO_DAMAGE_HEAVY,
	CRI_ROBOTSE_ROBO_GUARD_HIT,
	CRI_ROBOTSE_ROBO_GUARD,
	CRI_ROBOTSE_ROBO_PUNCH_FINISH,
	CRI_ROBOTSE_ROBO_PUNCH,
	CRI_ROBOTSE_ROBO_MISILE_FIRE,
	CRI_ROBOTSE_ROBO_MISILE_FLYING,
	CRI_ROBOTSE_ROBO_MISILE_HIT,
	CRI_ROBOTSE_ROBO_HISSATUWAZA_FULLCHARGE,
	CRI_ROBOTSE_ROBO_HISSATUWAZA_SUCCESS,
	CRI_ROBOTSE_ROBO_HISSATUWAZA_FAILED,
	CRI_ROBOTSE_ROBO_HISSATUWAZA_MISS,
	CRI_ROBOTSE_ROBO_HISSATUWAZA_SEIKAI,
	CRI_ROBOTSE_ROBO_HISSATUBEAM_CHARGE,
	CRI_ROBOTSE_ROBO_HISSATUBEAM_HIT,
	CRI_ROBOTSE_ROBO_HISSATUBEAM_SHOOT,
	CRI_ROBOTSE_ROBO_PUNCHES,
	CRI_ROBOTSE_ROBO_WALK,
	CRI_ROBOTSE_ROBO_PUNCH_ARMMOVE
};

class BULLET_MANAGER
{
private:
	PLAYER_BULLET* m_p_player_bullet[MAX_PLAYER_BULLET];	//�v���C���[�̒e�̃|�C���^
	NETWORK_MANAGER* m_p_network_manager;
	EFFECT_MANAGER* m_p_effect_manager;

	AppObj m_bullet_manager_app_obj;

public:
	BULLET_MANAGER() = default;
	BULLET_MANAGER(NETWORK_MANAGER* p_network_manager, EFFECT_MANAGER* p_effect_manager) : m_p_network_manager(p_network_manager), m_p_effect_manager(p_effect_manager) {}
	~BULLET_MANAGER() {}

	void Init(void);
	void UnInit(void);
	void Update(void);
	void Draw(void);

	int SetPlayerBullet(XMFLOAT3 pos, XMFLOAT3 vec, XMFLOAT2 scale);
	PLAYER_BULLET* GetPlayerBullet(int id);
	void DeletePlayerBullet(int id);
};