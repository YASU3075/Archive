//-----------------------------------------------
// Effct.cpp
// ������F2025/01/23
// ����ҁF���c���l
//-----------------------------------------------
#include "Effect.h"
#include "Easing.h"
#include "sprite.h"
#include "EffectManager.h"
#include "smoother.h"

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------
#define PUNCH_EFFECT_SCALE_EASING_NUM			(11)
#define PUNCH_EFFECT_ALFA_EASING_NUM			(12)
#define MISSILE_EFFECT_VEC_EASING_NUM			(13)
#define MISSILE_EFFECT_ALFA_EASING_NUM			(14)
#define DAMAGE_EFFECT_ALFA_EASING_NUM			(15)
#define GUARD_EFFECT_SCALE_EASING_NUM			(16)
#define GUARD_EFFECT_ALFA_EASING_NUM			(17)

//-----------------------------------------------
// ����������
//-----------------------------------------------
void EFFECT::Init(void)
{
	
}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void EFFECT::Uninit(void)
{
	m_use = false;
	m_frame_count = 0;
	m_max_frame_count = 0;
	m_pos = XMFLOAT3(0.0f, 0.0f, 0.0f);
	m_vec = XMFLOAT3(0.0f, 0.0f, 0.0f);
	m_original_vec = XMFLOAT3(0.0f, 0.0f, 0.0f);
	m_scale = XMFLOAT2(1.0f, 1.0f);
	m_original_scale = XMFLOAT2(1.0f, 1.0f);
	m_rot = 0.0f;
	m_color = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
	m_original_color = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
	m_destroy = false;
}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void EFFECT::Update(void)
{
	m_pos.x += m_vec.x;
	m_pos.y += m_vec.y;
	m_pos.z += m_vec.z;
	
	m_frame_count++;
	if (m_frame_count >= m_max_frame_count)
	{
		m_destroy = true;
		m_frame_count = 0;
	}

	switch (m_type)
	{
	case EFFECT_TYPE_NONE:
		break;
	case EFFECT_TYPE_ROBOT_PUNCH:
	{
		float percent = EaseOutCub((float)m_frame_count / (float)m_max_frame_count);
		m_scale.x = m_original_scale.x * percent;
		m_scale.y = m_original_scale.y * percent;

		/*percent = EaseOutCub((float)m_frame_count / (float)m_max_frame_count);
		if (m_frame_count >= m_max_frame_count / 2)
		{
			percent = 1.0f - percent;
		}

		m_color.w = m_original_color.w * percent;*/

		if (m_frame_count >= m_max_frame_count)
		{
			m_destroy = true;
		}
	}
		break;
	case EFFECT_TYPE_MISSILE_FIRE:
	{
		easeOutCubic(1.0f / m_max_frame_count, MISSILE_EFFECT_VEC_EASING_NUM);
		float percent = GetEasing(MISSILE_EFFECT_VEC_EASING_NUM).posi.y;
		m_vec.x = m_original_vec.x * percent;
		m_vec.y = m_original_vec.y * percent;

		if (m_frame_count >= m_max_frame_count)
		{
			m_destroy = true;
			TimeReset(MISSILE_EFFECT_VEC_EASING_NUM);
		}
	}
		break;
	case EFFECT_TYPE_DAMAGE:
	{
		float percent = EaseInCub((float)m_frame_count / (float)m_max_frame_count);
		m_color.w = m_original_color.w * (1.0f - percent);

		if (m_frame_count >= m_max_frame_count)
		{
			m_destroy = true;
		}
	}
		break;
	case EFFECT_TYPE_GUARD:
	{
		float percent = EaseOutElastic((float)m_frame_count / (float)m_max_frame_count);
		m_scale.x = m_original_scale.x * percent;
		m_scale.y = m_original_scale.y * percent;

		
		float color = EaseOutCub((float)m_frame_count / (float)(m_max_frame_count / 2));
		if (m_frame_count >= m_max_frame_count / 2)
		{
			color = EaseOutCub((float)(m_frame_count - 30) / (float)(m_max_frame_count / 2));
			color = 1.0f - color;
		}
		m_color.w = m_original_color.w * color;
	}
	break;
	case EFFECT_TYPE_SMALL_GUARD:
	{
		if (m_frame_count == 1)
		{
			float percent = (rand() % 51 + 50) * 0.01;
			m_scale.x = m_original_scale.x * percent;
			m_scale.y = m_original_scale.y * percent;
		}
	}
		break;
	case EFFECT_TYPE_WIND:
	{
		float percent = EaseInCub((float)m_frame_count / (float)m_max_frame_count);
		m_vec.x = m_original_vec.x * percent;
		m_vec.y = m_original_vec.y * percent;
		m_vec.z = m_original_vec.z * percent;
	}
		break;
	case EFFECT_TYPE_DIRT:
		break;
	case EFFECT_TYPE_TAKE_DAMAGE:
		break;
	case EFFECT_TYPE_EXPLOSION:
		break;
	case EFFECT_TYPE_SPECIAL_HIT:
	{
		float percent = 0.0f;
		if (m_frame_count <= 180)
		{
			percent = EaseOutCub((float)m_frame_count / 30.0f);
			if (percent >= 1.0f)
			{
				percent = 1.0f;
			}
		}
		else
		{
			percent = EaseOutCub((float)(m_frame_count - 180) / 110.0f);
			percent = 1.0f - percent;
		}
		m_scale.x = m_original_scale.x * percent;
		m_scale.y = m_original_scale.y * percent;
	}
		break;
	case EFFECT_TYPE_SPECIAL_SHOOT:
	{
		if (m_frame_count >= 180)
		{
			float percent = EaseOutCub((float)(m_frame_count - 180) / 110.0f);
			percent = 1.0f - percent;
			m_scale.x = m_original_scale.x * percent;
			m_scale.y = m_original_scale.y * percent;
			m_color.w = m_original_color.w * percent;
		}
	}
		break;
	case EFFECT_TYPE_FOCUS:
		if (m_frame_count >= m_max_frame_count)
		{
			m_destroy = true;
		}
		break;
	case EFFECT_TYPE_MAX:
		break;
	default:
		break;
	}
}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void EFFECT::Draw(void)
{
	ID3D11ShaderResourceView* texture = nullptr;
	USER_TYPE type = m_p_network_manager->GetType();

	switch (m_type)
	{
	case EFFECT_TYPE_NONE:
		break;
	case EFFECT_TYPE_ROBOT_PUNCH:
		texture = m_p_effect_manager->GetPunchEffectTexture();
		GetDeviceContext()->PSSetShaderResources(0, 1, &texture);
		DrawSprite(type, XMFLOAT2(m_pos.x, m_pos.y), m_rot, XMFLOAT2(m_scale.x + 100.0f, m_scale.y + 100.0f), m_color, 4, 4, (float)m_frame_count / ((float)m_max_frame_count / 16.0f));

		break;
	case EFFECT_TYPE_MISSILE_FIRE:
		texture = m_p_effect_manager->GetMissileEffectTexture();
		GetDeviceContext()->PSSetShaderResources(0, 1, &texture);
		DrawSprite(type, XMFLOAT2(m_pos.x, m_pos.y), m_rot, XMFLOAT2(m_scale.x, m_scale.y), m_color, 4, 2, m_frame_count / 8);
		break;
	case EFFECT_TYPE_DAMAGE:
		texture = m_p_effect_manager->GetDamageEffectTexture();
		GetDeviceContext()->PSSetShaderResources(0, 1, &texture);
		DrawSprite(type, XMFLOAT2(m_pos.x, m_pos.y), m_rot, XMFLOAT2(m_scale.x, m_scale.y), m_color, 1, 1, 0);
		break;
	case EFFECT_TYPE_GUARD:
	case EFFECT_TYPE_SMALL_GUARD:
		texture = m_p_effect_manager->GetGuardEffectTexture();
		GetDeviceContext()->PSSetShaderResources(0, 1, &texture);
		DrawSprite(type, XMFLOAT2(m_pos.x, m_pos.y), m_rot, XMFLOAT2(m_scale.x, m_scale.y), m_color, 4, 4, (float)m_frame_count / ((float)m_max_frame_count / 16.0f));
		break;
	case EFFECT_TYPE_WIND:
		texture = m_p_effect_manager->GetWindEffectTexture();
		GetDeviceContext()->PSSetShaderResources(0, 1, &texture);
		DrawSprite(type, XMFLOAT2(m_pos.x, m_pos.y), m_rot, XMFLOAT2(m_scale.x, m_scale.y), m_color, 1, 1, 0);
		break;
	case EFFECT_TYPE_DIRT:
		texture = m_p_effect_manager->GetDirtEffectTexture();
		GetDeviceContext()->PSSetShaderResources(0, 1, &texture);
		DrawSprite(type, XMFLOAT2(m_pos.x, m_pos.y), m_rot, XMFLOAT2(m_scale.x, m_scale.y), m_color, 4, 4, (float)m_frame_count / ((float)m_max_frame_count / 16.0f));
		break;
	case EFFECT_TYPE_TAKE_DAMAGE:
		texture = m_p_effect_manager->GetTakeDamageEffectTexture();
		GetDeviceContext()->PSSetShaderResources(0, 1, &texture);
		DrawSprite(type, XMFLOAT2(m_pos.x, m_pos.y), m_rot, XMFLOAT2(m_scale.x, m_scale.y), m_color, 4, 4, (float)m_frame_count / ((float)m_max_frame_count / 16.0f));
		break;
	case EFFECT_TYPE_EXPLOSION:
		texture = m_p_effect_manager->GetExplosionEffectTexture();
		GetDeviceContext()->PSSetShaderResources(0, 1, &texture);
		DrawSprite(type, XMFLOAT2(m_pos.x, m_pos.y), m_rot, XMFLOAT2(m_scale.x, m_scale.y), m_color, 4, 4, (float)m_frame_count / ((float)m_max_frame_count / 16.0f));
		break;
	case EFFECT_TYPE_SPECIAL_HIT:
		texture = m_p_effect_manager->GetSpecialHitEffectTexture();
		GetDeviceContext()->PSSetShaderResources(0, 1, &texture);
		//DrawSprite(type, XMFLOAT2(m_pos.x, m_pos.y), m_rot, XMFLOAT2(m_scale.x, m_scale.y), m_color, 4, 4, (float)m_frame_count / ((float)m_max_frame_count / 16.0f));
		DrawSprite(type, XMFLOAT2(m_pos.x, m_pos.y), m_rot, XMFLOAT2(m_scale.x, m_scale.y), m_color, 4, 4, m_frame_count % 16);
		break;
	case EFFECT_TYPE_SPECIAL_SHOOT:
		texture = m_p_effect_manager->GetSpecialShootEffectTexture();
		GetDeviceContext()->PSSetShaderResources(0, 1, &texture);
		//DrawSprite(type, XMFLOAT2(m_pos.x, m_pos.y), m_rot, XMFLOAT2(m_scale.x, m_scale.y), m_color, 4, 4, (float)m_frame_count / ((float)m_max_frame_count / 16.0f));
		DrawSprite(type, XMFLOAT2(m_pos.x, m_pos.y), m_rot, XMFLOAT2(m_scale.x, m_scale.y), m_color, 4, 4, m_frame_count % 16);
		break;
	case EFFECT_TYPE_FOCUS:
		texture = m_p_effect_manager->GetFocusEffectTexture();
		GetDeviceContext()->PSSetShaderResources(0, 1, &texture);
		DrawSprite(type, XMFLOAT2(m_pos.x, m_pos.y), m_rot, XMFLOAT2(m_scale.x, m_scale.y), m_color, 1, 6, m_frame_count % 6);
		break;
	case EFFECT_TYPE_MAX:
		break;
	default:
		break;
	}
}