//-----------------------------------------------
// Effect.h
// ������F2025/01/23
// ����ҁF���c���l
//-----------------------------------------------
#pragma once
#include "renderer.h"
#include "NetworkManager.h"

enum EFFECT_TYPE
{
	EFFECT_TYPE_NONE = 0,
	EFFECT_TYPE_ROBOT_PUNCH,
	EFFECT_TYPE_MISSILE_FIRE,
	EFFECT_TYPE_DAMAGE,
	EFFECT_TYPE_GUARD,
	EFFECT_TYPE_SMALL_GUARD,
	EFFECT_TYPE_WIND,
	EFFECT_TYPE_DIRT,
	EFFECT_TYPE_TAKE_DAMAGE,
	EFFECT_TYPE_EXPLOSION,
	EFFECT_TYPE_SPECIAL_SHOOT,
	EFFECT_TYPE_SPECIAL_HIT,
	EFFECT_TYPE_FOCUS,

	EFFECT_TYPE_MAX,
};

enum LAYER
{
	LAYER_NONE = 0,

	LAYER_BACKGROUND,

	LAYER_ENEMY,

	LAYER_ROBOT,

	LAYER_UI,
};

class EFFECT_MANAGER;

class EFFECT
{
private:
	bool m_use = false;
	int m_frame_count = 0;
	int m_max_frame_count = 0;
	XMFLOAT3 m_pos = XMFLOAT3(0.0f, 0.0f, 0.0f);
	XMFLOAT3 m_vec = XMFLOAT3(0.0f, 0.0f, 0.0f);
	XMFLOAT3 m_original_vec = XMFLOAT3(0.0f, 0.0f, 0.0f);
	XMFLOAT2 m_scale = XMFLOAT2(1.0f, 1.0f);
	XMFLOAT2 m_original_scale = XMFLOAT2(1.0f, 1.0f);
	float m_rot = 0.0f;
	XMFLOAT4 m_color = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
	XMFLOAT4 m_original_color = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
	
	bool m_destroy = false;

	EFFECT_TYPE m_type = EFFECT_TYPE_NONE;
	LAYER m_layer = LAYER_NONE;

	EFFECT_MANAGER* m_p_effect_manager;

	NETWORK_MANAGER* m_p_network_manager;

public:
	EFFECT() = default;
	EFFECT(XMFLOAT3 pos, XMFLOAT3 vec, XMFLOAT2 sca, float rot, XMFLOAT4 color, int max_frame_count, EFFECT_TYPE type, LAYER layer, NETWORK_MANAGER* p_network_manager, EFFECT_MANAGER* p_effect_manager) : 
		m_use(true), m_frame_count(0), m_pos(pos), m_vec(vec), m_original_vec(vec), m_scale(sca), m_original_scale(sca), m_rot(rot), m_color(color), m_original_color(color), m_max_frame_count(max_frame_count), m_type(type), m_layer(layer), m_p_network_manager(p_network_manager), m_p_effect_manager(p_effect_manager) {}
	~EFFECT() = default;

	void Init(void);
	void Uninit(void);
	void Update(void);
	void Draw(void);

	void SetUse(bool use) { m_use = use; };
	void SetFrameCount(int frame_count) { m_frame_count = frame_count; };
	void SetPos(XMFLOAT3 pos) { m_pos = pos; };
	void SetVec(XMFLOAT3 vec) { m_vec = vec; };
	void SetScale(XMFLOAT2 scale) { m_scale = scale; };
	void SetRot(float rot) { m_rot = rot; };
	void SetColor(XMFLOAT4 color) { m_color = color; };
	void SetType(EFFECT_TYPE type) { m_type = type; };
	void SetLayer(LAYER layer) { m_layer = layer; };

	bool GetUse(void) const { return m_use; };
	int GetFrameCount(void) const { return m_frame_count; };
	XMFLOAT3 GetPos(void) const { return m_pos; };
	XMFLOAT3 GetVec(void) const { return m_vec; };
	XMFLOAT2 GetScale(void) const { return m_scale; };
	float GetRot(void) const { return m_rot; };
	XMFLOAT4 GetColor(void) const { return m_color; };
	EFFECT_TYPE GetType(void) const { return m_type; };
	LAYER GetLayer(void) const { return m_layer; };
	bool GetDestroy(void) const { return m_destroy; };
};
