//-----------------------------------------------
// EffectManager.cpp
// ������F2025/01/23
// ����ҁF���c���l
//-----------------------------------------------
#include "EffectManager.h"

//-----------------------------------------------
// ����������
//-----------------------------------------------
void EFFECT_MANAGER::Init(void)
{
	for (int i = 0; i < MAX_EFFECT; i++)
	{
		m_p_effect[i] = nullptr;
	}

	//�e�N�X�`���ǂݍ���
	TexMetadata metadata;
	ScratchImage image;

	LoadFromWICFile(L"Asset\\Texture\\Effect\\attack_hit.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_punch_effect);
	assert(m_texture_punch_effect);

	LoadFromWICFile(L"Asset\\Texture\\Effect\\fire.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_missile_effect);
	assert(m_texture_missile_effect);

	LoadFromWICFile(L"Asset\\Texture\\Effect\\damage.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_damage_effect);
	assert(m_texture_damage_effect);

	LoadFromWICFile(L"Asset\\Texture\\Effect\\guard.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_guard_effect);
	assert(m_texture_guard_effect);

	LoadFromWICFile(L"Asset\\Texture\\Effect\\damage.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_wind_effect);
	assert(m_texture_wind_effect);

	LoadFromWICFile(L"Asset\\Texture\\Effect\\�y��.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_dirt_effect);
	assert(m_texture_dirt_effect);

	LoadFromWICFile(L"Asset\\Texture\\Effect\\take_damage.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_take_damage_effect);
	assert(m_texture_take_damage_effect);

	LoadFromWICFile(L"Asset\\Texture\\Effect\\explosion.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_explosion_effect);
	assert(m_texture_explosion_effect);

	LoadFromWICFile(L"Asset\\Texture\\Effect\\special_shoot.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_special_shoot_effect);
	assert(m_texture_special_shoot_effect);

	LoadFromWICFile(L"Asset\\Texture\\Effect\\special_hit.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_special_hit_effect);
	assert(m_texture_special_hit_effect);

	LoadFromWICFile(L"Asset\\Texture\\Effect\\focus.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_focus_effect);
	assert(m_texture_focus_effect);
}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void EFFECT_MANAGER::Uninit(void)
{
	

	if (m_texture_punch_effect)
	{
		m_texture_punch_effect->Release();
		m_texture_punch_effect = NULL;
	}
	if (m_texture_missile_effect)
	{
		m_texture_missile_effect->Release();
		m_texture_missile_effect = NULL;
	}
	if (m_texture_damage_effect)
	{
		m_texture_damage_effect->Release();
		m_texture_damage_effect = NULL;
	}
	if (m_texture_guard_effect)
	{
		m_texture_guard_effect->Release();
		m_texture_guard_effect = NULL;
	}
	if (m_texture_wind_effect)
	{
		m_texture_wind_effect->Release();
		m_texture_wind_effect = NULL;
	}
	if (m_texture_dirt_effect)
	{
		m_texture_dirt_effect->Release();
		m_texture_dirt_effect = NULL;
	}
	if (m_texture_take_damage_effect)
	{
		m_texture_take_damage_effect->Release();
		m_texture_take_damage_effect = NULL;
	}
	if (m_texture_explosion_effect)
	{
		m_texture_explosion_effect->Release();
		m_texture_explosion_effect = NULL;
	}
	if (m_texture_special_shoot_effect)
	{
		m_texture_special_shoot_effect->Release();
		m_texture_special_shoot_effect = NULL;
	}
	if (m_texture_special_hit_effect)
	{
		m_texture_special_hit_effect->Release();
		m_texture_special_hit_effect = NULL;
	}
	if (m_texture_focus_effect)
	{
		m_texture_focus_effect->Release();
		m_texture_focus_effect = NULL;
	}

	for (int i = 0; i < MAX_EFFECT; i++)
	{
		if (m_p_effect[i])
		{
			m_p_effect[i]->Uninit();
		}
	}
	delete[] m_p_effect;
}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void EFFECT_MANAGER::Update(void)
{
	for (int i = 0; i < MAX_EFFECT; i++)
	{
		if (m_p_effect[i])
		{
			m_p_effect[i]->Update();
		}
	}

	for (int i = 0; i < MAX_EFFECT; i++)
	{
		if (m_p_effect[i])
		{
			if (m_p_effect[i]->GetDestroy())
			{
				m_p_effect[i]->Uninit();
				delete m_p_effect[i];
				m_p_effect[i] = nullptr;
			}
		}
	}

}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void EFFECT_MANAGER::Draw(LAYER layer)
{
	for (int i = 0; i < MAX_EFFECT; i++)
	{
		if (m_p_effect[i] && m_p_effect[i]->GetLayer() == layer)
		{
			m_p_effect[i]->Draw();
		}
	}
}

//-----------------------------------------------
// �Z�b�^�[
//-----------------------------------------------
void EFFECT_MANAGER::SetEffect(int max_frame_count, XMFLOAT3 pos, XMFLOAT3 vec, XMFLOAT2 sca, float rot, XMFLOAT4 color, EFFECT_TYPE type, LAYER layer)
{
	for (int i = 0; i < MAX_EFFECT; i++)
	{
		if (m_p_effect[i] == nullptr)
		{
			m_p_effect[i] = new EFFECT(pos, vec, sca, rot, color, max_frame_count, type, layer, m_p_network_manager, this);
			m_p_effect[i]->Init();
			return;
		}
	}
}