//-----------------------------------------------
// EffectManager.h
// ������F2025/01/23
// ����ҁF���c���l
//-----------------------------------------------
#pragma once
#include "renderer.h"
#include "Effect.h"
#include "NetworkManager.h"

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------
#define MAX_EFFECT			(100)			//�G�t�F�N�g�̍ő吔

class EFFECT_MANAGER
{
private:
	EFFECT* m_p_effect[MAX_EFFECT];
	NETWORK_MANAGER* m_p_network_manager;

	ID3D11ShaderResourceView* m_texture_punch_effect;
	ID3D11ShaderResourceView* m_texture_missile_effect;
	ID3D11ShaderResourceView* m_texture_damage_effect;
	ID3D11ShaderResourceView* m_texture_guard_effect;
	ID3D11ShaderResourceView* m_texture_wind_effect;
	ID3D11ShaderResourceView* m_texture_dirt_effect;
	ID3D11ShaderResourceView* m_texture_take_damage_effect;
	ID3D11ShaderResourceView* m_texture_explosion_effect;
	ID3D11ShaderResourceView* m_texture_special_shoot_effect;
	ID3D11ShaderResourceView* m_texture_special_hit_effect;
	ID3D11ShaderResourceView* m_texture_focus_effect;


public:
	EFFECT_MANAGER() = default;
	EFFECT_MANAGER(NETWORK_MANAGER* p_network_manager) : m_p_network_manager(p_network_manager) {}
	~EFFECT_MANAGER() = default;

	void Init(void);
	void Uninit(void);
	void Update(void);
	void Draw(LAYER layer);

	void SetEffect(int max_frame_count, XMFLOAT3 pos, XMFLOAT3 vec, XMFLOAT2 sca, float rot, XMFLOAT4 color, EFFECT_TYPE type, LAYER layer);

	ID3D11ShaderResourceView* GetPunchEffectTexture(void) const { return m_texture_punch_effect; };
	ID3D11ShaderResourceView* GetMissileEffectTexture(void) const { return m_texture_missile_effect; };
	ID3D11ShaderResourceView* GetDamageEffectTexture(void) const { return m_texture_damage_effect; };
	ID3D11ShaderResourceView* GetGuardEffectTexture(void) const { return m_texture_guard_effect; };
	ID3D11ShaderResourceView* GetWindEffectTexture(void) const { return m_texture_wind_effect; };
	ID3D11ShaderResourceView* GetDirtEffectTexture(void) const { return m_texture_dirt_effect; };
	ID3D11ShaderResourceView* GetTakeDamageEffectTexture(void) const { return m_texture_take_damage_effect; };
	ID3D11ShaderResourceView* GetExplosionEffectTexture(void) const { return m_texture_explosion_effect; };
	ID3D11ShaderResourceView* GetSpecialShootEffectTexture(void) const { return m_texture_special_shoot_effect; };
	ID3D11ShaderResourceView* GetSpecialHitEffectTexture(void) const { return m_texture_special_hit_effect; };
	ID3D11ShaderResourceView* GetFocusEffectTexture(void) const { return m_texture_focus_effect; };
};