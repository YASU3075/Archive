//-----------------------------------------------
// NetworkManager.cpp
// ������F2024/12/16
// ����ҁF���c���l
//-----------------------------------------------
#include "NetworkManager.h"

//-----------------------------------------------
// ����������
//-----------------------------------------------
void NETWORK_MANAGER::Init(void)
{
	switch (m_type)
	{
	case MIDDLE_PC:
		InitServer();
		break;
	case LEFT_PC:
		InitClient(LEFT_PC);
		break;
	case RIGHT_PC:
		InitClient(RIGHT_PC);
		break;
	case MAX_SOCKET:
		break;
	default:
		break;
	}
}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void NETWORK_MANAGER::Uninit(void)
{
	switch (m_type)
	{
	case MIDDLE_PC:
		UninitServer();
		break;
	case LEFT_PC:
		UninitClient();
		break;
	case RIGHT_PC:
		UninitClient();
		break;
	case MAX_SOCKET:
		break;
	default:
		break;
	}
}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void NETWORK_MANAGER::Update(void)
{

}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void NETWORK_MANAGER::Draw(void)
{
	//�����������邱�ƂȂ�
}