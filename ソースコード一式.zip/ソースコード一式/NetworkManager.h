//-----------------------------------------------
// NetworkManager.h
// ������F2024/12/16
// ����ҁF���c���l
//-----------------------------------------------
#pragma once
#include "Network.h"

#include "Server.h"
#include "Client.h"

class NETWORK_MANAGER
{
private:
	//PC�̎��ʗp
	USER_TYPE m_type;
	
public:
	NETWORK_MANAGER() = default;		//�R���X�g���N�^
	NETWORK_MANAGER(USER_TYPE type) : m_type(type) {}
	~NETWORK_MANAGER() {}

	void Init(void);
	void Uninit(void);
	void Update(void);
	void Draw(void);

	void SetType(USER_TYPE type) { m_type = type; };
	USER_TYPE GetType(void) const { return m_type; };
};