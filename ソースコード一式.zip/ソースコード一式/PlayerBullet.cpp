//==========================================
// PlayerBullet.cpp
// �����:2024/11/26
// �����:�c����
// �X�V���F2024/12/03		�X�V�ҁF���c���l
//==========================================
#include"PlayerBullet.h"
#include"sprite.h"

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------
#define EFFECT_NUM_PER_SECOND		(10)				//1�b�Ԃ̃G�t�F�N�g�̐�

//-----------------------------------------------
// ����������
//-----------------------------------------------
void PLAYER_BULLET::Init(void)
{
	m_color = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);

	//�e�N�X�`���ǂݍ���
	TexMetadata metadata;
	ScratchImage image;

	LoadFromWICFile(L"Asset\\Texture\\Robot\\player_bullet.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture[1]);
	assert(m_texture[1]);

	LoadFromWICFile(L"Asset\\Texture\\Effect\\fire.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture[2]);
	assert(m_texture[2]);

}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void PLAYER_BULLET::UnInit(void)
{
	if (m_texture[1])
	{
		m_texture[1]->Release();
		m_texture[1] = NULL;
	}
	if (m_texture[2])
	{
		m_texture[2]->Release();
		m_texture[2] = NULL;
	}
}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void PLAYER_BULLET::Update(void)
{
	m_rot += 1.0f;
	
	m_frame_count++;
	if (m_frame_count >= 8 * 2)
	{
		m_frame_count = 0;
	}
	//�ړ�����
	m_pos = XMFLOAT3(m_pos.x + m_vec.x, m_pos.y + m_vec.y, m_pos.z + m_vec.z);
}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void PLAYER_BULLET::Draw(void)
{
	GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture[1]);
	DrawSprite(m_p_network_manager->GetType(), XMFLOAT2(m_pos.x, m_pos.y), m_rot, m_scale, m_color, 1, 1, 0);

	GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture[2]);
	DrawSprite(m_p_network_manager->GetType(), XMFLOAT2(m_pos.x, m_pos.y), m_rot, XMFLOAT2(m_scale.x * 0.8f, m_scale.y * 0.8f), m_color, 4, 2, m_frame_count / 2);

}