//-----------------------------------------------
// Robot.cpp
// ������F2024/11/07
// ����ҁF���c���l
//-----------------------------------------------
#include "renderer.h"
#include "Robot.h"
#include "camera.h"
#include "sprite.h"
#include"keyboard.h"
#include "smoother.h"
#include "Easing.h"
#include <time.h>
#include "VideoPlayer.h"
#include "DirectWriteSample.h"

//-----------------------------------------------
// �}�N����`
//-----------------------------------------------
#define MOVE_FRAME_NUM						(30)					//�ړ��ɂ�����t���[����
#define MOVE_GAP_NUM						(30)					//�ړ��̓��������̗P�\�t���[��
#define SQUARES_SIZE						(SCREEN_WIDTH / 2.0f)	//�}�b�v�̃}�X�̃T�C�Y�i���j

#define MISS_FRAME							(30)					//�s�����s�����Ƃ��̃t���[����

#define ROBOT_MIN_X							(-SQUARES_SIZE)			//���{��X���W�̍ŏ��l
#define ROBOT_MAX_X							(SQUARES_SIZE)			//���{��X���W�̍ő�l
#define SIDE_MOVE_HEIGHT					(100.0f)				//�ړ��̎R�Ȃ�l

#define GUARD_MOTION_FRONT_FRAME			(15)					//�K�[�h�̘r���o���X�s�[�h
#define GUARD_MOTION_BACK_FRAME				(15)					//�K�[�h�̘r��߂��X�s�[�h

#define GUARD_MOTION_SHAKE_STRENGTH			(1.0f)					//�K�[�h�̗h�炷����(0.0f-1.0f)

#define JUST_GUARD_FRAME					(60)					//�W���X�g�K�[�h�̗P�\�t���[��
#define GUARD_EFFECT_FRAME					(10)					//���t���[���Ɉ��K�[�h�̃G�t�F�N�g���o����
#define GUARD_EFFECT_NUM					(5)						//�K�[�h�̃G�t�F�N�g�̐�
#define GUARD_FRAME							(JUST_GUARD_FRAME + 40)	//�K�[�h�S�̗̂P�\�t���[��

#define PUNCH_RESERVE_MOTION_MOVE_X			(100.0f)				//���Ԃ��������Ƃ��̈ʒu����
#define PUNCH_RESERVE_MOTION_MOVE_Y			(300.0f)				//���Ԃ��������Ƃ��̈ʒu����
#define PUNCH_MOTION_SHAKE_STRENGTH			(0.5f)					//���Ԃ���h�炷����(0.0f-1.0f)

#define PUNCH_RESERVE_MOTION_FRAME			(20)					//���Ԃ��������ď�������܂ł̃t���[����
#define PUNCH_MOTION_FRONT_FRAME			(20)					//���Ԃ���U��t���[����
#define PUNCH_MOTION_SHAKE_FRAME			(20)					//���Ԃ���h�炷�t���[����
#define PUNCH_MOTION_BACK_FRAME				(20)					//���Ԃ���߂��t���[����
#define IS_ATTACKING_TIME					(1)						//�U���t���O���擾�ł���t���[����
#define SECOND_PUNCH_EFFECT_FRAME			(10)					//2�ڂ̃G�t�F�N�g�𔭐�����t���[����

#define PUNCH_MISS_FRAME					(60)					//�p���`�~�X�t���[����

#define SPECIAL_IDLE_FRAME					(20)					//�K�E�Z�̃T�N�Z�X�I���o������
#define SPECIAL_MOTION_FRAME				(60)					//�K�E�Z�̃��[�V�����̃t���[����
#define SPECIAL_MOTION_BEAM_FRAME			(60)					//�K�E�Z�̃r�[����������
#define SPECIAL_MOTION_TEXTURE_MAX			(3)						//�K�E�Z�̃e�N�X�`���[�̍ő吔
#define SPECIAL_MISS_FRAME					(120)					//�K�E�Z�̎��s�t���[����

#define SHOOT_GAP_FRAME						(30)					//�ˌ��̓��������P�\�t���[��
#define SHOOT_MOTION_FRONT_FRAME			(30)					//�ˌ��̘r���o���t���[����
#define SHOOT_MOTION_STAY_FRAME				(20)					//�ˌ��̘r���Ƃǂ߂�t���[����
#define SHOOT_MOTION_BACK_FRAME				(30)					//�ˌ��̘r��߂��t���[����
#define SHOOT_SHAKE_STRENGTH				(0.7f)					//�ˌ��������̗h��̑傫��
#define SHOOT_SHAKE_DULATION				(20)					//�ˌ��������̗h��̎�������
#define BULLET_SPEED						(1.0f)					//�e�̃X�s�[�h
#define MAX_BULLET_Z						(1000.0f)				//�e��Z���W�̍ő�l

#define POSE_MOTION_FRAME					(15)					//���߃|�[�Y�̃t���[����
#define POSE_FRAME							(180)					//���߃|�[�Y�̑S�̃t���[����
#define POSE_MOTION_TEXTURE_MAX				(8)						//���߃|�[�Y�̃e�N�X�`���ő吔

#define INTERCEPT_PUNCH_RESERVE_FRAME		(15)					//�}���C�x���g�̎��̂��Ԃ�����������t���[����
#define INTERCEPT_PUNCH_FRONT_FRAME			(15)					//�}���C�x���g�̎��̂��Ԃ���U��t���[����
#define INTERCEPT_PUNCH_SHAKE_FRAME			(15)					//�}���C�x���g�̎��̂��Ԃ���h�炷�t���[����
#define INTERCEPT_PUNCH_BACK_FRAME			(15)					//�}���C�x���g�̎��̂��Ԃ���߂��t���[����

#define IDLE_FLOATING_FRAME_COUNT			(180)					//�ҋ@���[�V�����̈��㉺����t���[����
#define IDLE_FLOATING_HEIGHT				(50.0f)					//�ҋ@���[�V�����̏㉺���镝

#define LOWER_BACK_MOTION_FRAME				(30)					//�ジ����̃t���[����
#define LOWER_BACK_MOTION_TEXTURE_MAX		(3)						//���ꃂ�[�V�����̃e�N�X�`����

#define MUSIC_ARM_MOTION_FRAME				(30)					//���{�^���������Ƃ��̘r�̃��[�V�����t���[����
#define LEFT_MUSIC_FRAME					(120)					//���̉��{�^���������Ƃ��̉��̃t���[����
#define RIGHT_MUSIC_FRAME					(120)					//�E�̉��{�^���������Ƃ��̉��̃t���[����


#define GUARD_GAP_FRAME						(30)					//�h��̓��������̗P�\�t���[��
#define GUARD_MOTION_FRAME					(60)					//�h��ɂ�����t���[����

#define PUNCH_MOTION_TEXTURE_MAX			(4)						//�p���`�̃e�N�X�`���̃X�v���C�g�̐�
#define GUARD_MOTION_TEXTURE_MAX			(2)						//�K�[�h�̃e�N�X�`���̍ő吔

#define PUNCH_PREPARE_MOVE_X				(800.0f)				//�p���`�̗\�������X�����ɂ��炷�l
#define PUNCH_PREPARE_MOVE_Y				(500.0f)				//�p���`�̗\�������Y�����ɂ��炷�l
#define PUNCHING_Y							(100.0f)				//�p���`�̐U��Y�����ɂ��炷�l

#define GUARD_SUCCESS_FRAME					(60)					//�K�[�h���������Ƃ��̃t���[����
#define GUARD_AURA_FRAME					(30)					//�K�[�h�̃I�[������ԑ傫���Ȃ�܂ł̃t���[����
#define MAX_GUARD_AURA_NUM					(1)						//�����ɃK�[�h�̃I�[�����������邩�̍ő�l

#define INTERCEPT_MISSILE_POS_X				(400.0f)				//�}�����̃~�T�C�����o���ʒu
#define INTERCEPT_MISSILE_FRAME				(30)					//�}�����Ƀ~�T�C������ɓ͂��܂łɂ�����t���[����

#define STAN_CHANCE_ATTACK_GAP_FRAME		(30)					//�C��`�����X�̎��̓��������̗P�\�t���[��
#define STAN_PUNCH_RESERVE_MOTION_FRAME		(15)					//�C��`�����X�̃p���`�̏�������t���[����
#define STAN_PUNCH_FRONT_MOTION_FRAME		(15)					//�C��`�����X�̃p���`��U��t���[����
#define STAN_PUNCH_SHAKE_MOTION_FRAME		(15)					//�C��`�����X�̃p���`�̗h�炷�t���[����
#define STAN_PUNCH_BACK_MOTION_FRAME		(15)					//�C��`�����X�̃p���`�̖߂��t���[����
#define STAN_PUNCH_ALL_MOTION_FRAME			(STAN_PUNCH_RESERVE_MOTION_FRAME + STAN_PUNCH_FRONT_MOTION_FRAME + STAN_PUNCH_SHAKE_MOTION_FRAME + STAN_PUNCH_BACK_MOTION_FRAME)

#define INTERCEPT_GUARD_MOTION_FRONT_FRAME	(15)					//�m�A�h���S���A���C�x���g��QTE���������Ƃ��K�[�h�̘r���o���t���[����
#define INTERCEPT_GUARD_MOTION_BACK_FRAME	(15)					//�m�A�h���S���A���C�x���g��QTE���������Ƃ��K�[�h�̘r��߂��t���[����

#define GUARD_EFFECT_SCALE					(1500.0f)				//�K�[�h�������̃G�t�F�N�g�̑傫��

#define QTE_BUTTON_MAX_SCALE				(1000.0f)				//QTE�̃{�^���̑傫���̍ő�l

#define QTE_BUTTON_SHAKE_DULATION			(20)

#define INTERCEPT_MISSILE_COOL_TIME			(10)					//�}���̃~�T�C���̃N�[���^�C��
#define INTERCEPT_MISSILE_SHAKE_STRENGTH		(0.5f)

#define BUTTON_FADE_FRAME					(30)					//�t�F�[�h�A�E�g�̃t���[��

#define MISSION_FAILED_FRAME				(300)					//���s���̉��o����
#define EXPLOSION_INTERVAL_FRAME			(5)						//�����Ԋu
#define EXPLOSION_EFFECT_FRAME				(15)					//�����G�t�F�N�g�̃t���[����
#define EXPLOSION_EFFECT_SCALE				(900.0f)				//�����G�t�F�N�g�̃T�C�Y

//�v�����i�[������Ȃ��ŁI�I(�C�[�W���O�p�̔ԍ�)
#define LEFT_ATTACK_EASING_NUM					(1)
#define RIGHT_ATTACK_EASING_NUM					(2)
#define LEFT_GUARD_EASING_NUM					(3)
#define RIGHT_GUARD_EASING_NUM					(4)
#define	LEFT_MUSIC_EASING_NUM					(5)
#define	RIGHT_MUSIC_EASING_NUM					(6)

//-----------------------------------------------
// ����������
//-----------------------------------------------
void ROBOT::InitRobot(void)
{
	//����
	srand((unsigned int)time(0));

	//�e�N�X�`���ǂݍ���
	TexMetadata metadata;
	ScratchImage image;

	//�K�E�Z�R�}���h�e�N�X�`��
	LoadFromWICFile(L"Asset\\Texture\\UI\\cursol_p1.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_arrow[0]);
	assert(m_texture_arrow[0]);

	LoadFromWICFile(L"Asset\\Texture\\UI\\cursol_p2.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_arrow[1]);
	assert(m_texture_arrow[1]);

	for (int i = 0; i < 4; i++)
	{//��󏉊���
		m_left_arrow[i] = new SPECIAL_ARROW();
		m_right_arrow[i] = new SPECIAL_ARROW();

		m_left_arrow[i]->SetTexture(m_texture_arrow[0]);
		m_right_arrow[i]->SetTexture(m_texture_arrow[1]);

		m_left_arrow[i]->SetPos(XMFLOAT2(-SCREEN_WIDTH * 1.5f + ARROW_SIZE * 0.25f + ARROW_SIZE *  0.6f * i, -150.0f));
		m_left_arrow[i]->SetSca(XMFLOAT2(ARROW_SIZE, ARROW_SIZE));
		m_left_arrow[i]->SetColor(XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f));
		m_right_arrow[i]->SetPos(XMFLOAT2(SCREEN_WIDTH * 0.5f + ARROW_SIZE * 0.25f + ARROW_SIZE * 0.6f * i, -150.0f));
		m_right_arrow[i]->SetSca(XMFLOAT2(ARROW_SIZE, ARROW_SIZE));
		m_right_arrow[i]->SetColor(XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f));

		m_left_arrow[i]->m_index = i;
		m_right_arrow[i]->m_index = i;
		m_left_arrow[i]->m_left = true;
		m_right_arrow[i]->m_left = false;

		m_left_arrow[i]->SetNetworkManager(m_p_network_manager);
		m_right_arrow[i]->SetNetworkManager(m_p_network_manager);
	}

	m_left_arrow[0]->SetRot(0.0f);
	m_left_arrow[1]->SetRot(180.0f);
	m_left_arrow[2]->SetRot(270.0f);
	m_left_arrow[3]->SetRot(90.0f);

	m_right_arrow[0]->SetRot(0.0f);
	m_right_arrow[1]->SetRot(180.0f);
	m_right_arrow[2]->SetRot(270.0f);
	m_right_arrow[3]->SetRot(90.0f);

	//�K�E�Z�����e�N�X�`��
	LoadFromWICFile(L"Asset\\Texture\\UI\\special_success.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_special_success);
	assert(m_texture_special_success);

	//�K�E�Z���s�e�N�X�`��
	LoadFromWICFile(L"Asset\\Texture\\UI\\special_miss.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_special_miss);
	assert(m_texture_special_miss);

	//�r�ҋ@�e�N�X�`��
	LoadFromWICFile(L"Asset\\Texture\\Robot\\���{�X�v���C�g_�p���`_L.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_left_combo_punch);
	assert(m_texture_left_combo_punch);


	LoadFromWICFile(L"Asset\\Texture\\Robot\\���{�X�v���C�g_�p���`_R.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_right_combo_punch);
	assert(m_texture_right_combo_punch);

	//�p���`�e�N�X�`��
	
	//��
	LoadFromWICFile(L"Asset\\Texture\\Robot\\���{�r�S��_L.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_left_punch);
	assert(m_texture_left_punch);

	

	LoadFromWICFile(L"Asset\\Texture\\Robot\\���{�r�S��_R.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_right_punch);
	assert(m_texture_right_punch);

	//�K�[�h�e�N�X�`��
	
	//��
	LoadFromWICFile(L"Asset\\Texture\\Robot\\���{�X�v���C�g_�K�[�h_L.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_left_guard);
	assert(m_texture_left_guard);

	LoadFromWICFile(L"Asset\\Texture\\Robot\\���{�X�v���C�g_�K�[�h_R.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_right_guard);
	assert(m_texture_right_guard);

	LoadFromWICFile(L"Asset\\Texture\\Robot\\���{_�N���X�K�[�h.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_cross_guard);
	assert(m_texture_cross_guard);

	//���߃|�[�Y�e�N�X�`��
	LoadFromWICFile(L"Asset\\Texture\\Robot\\���{�X�v���C�g_���߃|�[�Y01.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_pose);
	assert(m_texture_pose);

	//�K�E�Z�̘r�e�N�X�`��
	LoadFromWICFile(L"Asset\\Texture\\Robot\\���{_�K�E�Z_L.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_left_ult_arm);
	assert(m_texture_left_ult_arm);

	LoadFromWICFile(L"Asset\\Texture\\Robot\\���{_�K�E�Z_R.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_right_ult_arm);
	assert(m_texture_right_ult_arm);

	//�K�E�Z�̃r�[���e�N�X�`��
	LoadFromWICFile(L"Asset\\Texture\\Robot\\beam_1.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_ult_beam[0]);
	assert(m_texture_ult_beam[0]);

	LoadFromWICFile(L"Asset\\Texture\\Robot\\beam_2.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_ult_beam[1]);
	assert(m_texture_ult_beam[1]);

	//����e�N�X�`��
	LoadFromWICFile(L"Asset\\Texture\\Robot\\���{�X�v���C�g_����_L.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_left_lower_back);
	assert(m_texture_left_lower_back);

	LoadFromWICFile(L"Asset\\Texture\\Robot\\���{�X�v���C�g_����_R.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_right_lower_back);
	assert(m_texture_right_lower_back);

	//�T�E���h���[�V�����e�N�X�`��
	LoadFromWICFile(L"Asset\\Texture\\Robot\\���{_�T�E���h���[�V����_L.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_left_sound);
	assert(m_texture_left_sound);

	LoadFromWICFile(L"Asset\\Texture\\Robot\\���{_�T�E���h���[�V����_R.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_right_sound);
	assert(m_texture_right_sound);

	LoadFromWICFile(L"Asset\\Texture\\Effect\\focus.png", WIC_FLAGS_NONE, &metadata, image);
	CreateShaderResourceView(GetDevice(), image.GetImages(), image.GetImageCount(), metadata, &m_texture_focus);
	assert(m_texture_focus);

	//�A�v���P�[�V�����̏�����
	app_atomex_initialize(&m_cv_app_obj, cv_cue_list, sizeof(cv_cue_list) / sizeof(CueInfo), ACF_PATH, CV_SE_ACB, CV_SE_AWB);
	app_atomex_initialize(&m_robot_app_obj, robot_cue_list, sizeof(robot_cue_list) / sizeof(CueInfo), ACF_PATH, ROBOT_SE_ACB, ROBOT_SE_AWB);
}

//-----------------------------------------------
// �I������
//-----------------------------------------------
void ROBOT::UninitRobot(void)
{
	//�A�v���P�[�V�����̏I��
	app_atomex_finalize(&m_cv_app_obj);
	app_atomex_finalize(&m_robot_app_obj);

	//�K�E�Z�R�}���h�e�N�X�`��
	if (m_texture_arrow[0])
	{
		m_texture_arrow[0]->Release();
		m_texture_arrow[0] = NULL;
	}

	if (m_texture_arrow[1])
	{
		m_texture_arrow[1]->Release();
		m_texture_arrow[1] = NULL;
	}

	//�K�E�Z�����e�N�X�`��
	if (m_texture_special_success)
	{
		m_texture_special_success->Release();
		m_texture_special_success = NULL;
	}

	//�K�E�Z���s�e�N�X�`��
	if (m_texture_special_miss)
	{
		m_texture_special_miss->Release();
		m_texture_special_miss = NULL;
	}

	//�r�ҋ@�e�N�X�`��
	if (m_texture_left_combo_punch)
	{
		m_texture_left_combo_punch->Release();
		m_texture_left_combo_punch = NULL;
	}
	if (m_texture_right_combo_punch)
	{
		m_texture_right_combo_punch->Release();
		m_texture_right_combo_punch = NULL;
	}

	//�r�p���`�e�N�X�`���[
	if (m_texture_left_punch)
	{
		m_texture_left_punch->Release();
		m_texture_left_punch = NULL;
	}
	if (m_texture_right_punch)
	{
		m_texture_right_punch->Release();
		m_texture_right_punch = NULL;
	}

	//�r�h���p���`�e�N�X�`���[
	if (m_texture_left_combo_punch)
	{
		m_texture_left_combo_punch->Release();
		m_texture_left_combo_punch = NULL;
	}
	if (m_texture_right_combo_punch)
	{
		m_texture_right_combo_punch->Release();
		m_texture_right_combo_punch = NULL;
	}

	//�r�K�[�h�e�N�X�`���[
	if (m_texture_left_guard)
	{
		m_texture_left_guard->Release();
		m_texture_left_guard = NULL;
	}
	if (m_texture_right_guard)
	{
		m_texture_right_guard->Release();
		m_texture_right_guard = NULL;
	}
	if (m_texture_cross_guard)
	{
		m_texture_cross_guard->Release();
		m_texture_cross_guard = NULL;
	}

	//���߃|�[�Y�e�N�X�`��
	if (m_texture_pose)
	{
		m_texture_pose->Release();
		m_texture_pose = NULL;
	}

	//�K�E�Z�̘r�e�N�X�`��
	if (m_texture_left_ult_arm)
	{
		m_texture_left_ult_arm->Release();
		m_texture_left_ult_arm = NULL;
	}
	if (m_texture_right_ult_arm)
	{
		m_texture_right_ult_arm->Release();
		m_texture_right_ult_arm = NULL;
	}

	//�K�E�Z�̃r�[���e�N�X�`��
	if (m_texture_ult_beam[0])
	{
		m_texture_ult_beam[0]->Release();
		m_texture_ult_beam[0] = NULL;
	}
	if (m_texture_ult_beam[1])
	{
		m_texture_ult_beam[1]->Release();
		m_texture_ult_beam[1] = NULL;
	}
	

	//����e�N�X�`��
	if (m_texture_left_lower_back)
	{
		m_texture_left_lower_back->Release();
		m_texture_left_lower_back = NULL;
	}
	if (m_texture_right_lower_back)
	{
		m_texture_right_lower_back->Release();
		m_texture_right_lower_back = NULL;
	}

	//�T�E���h���[�V�����e�N�X�`��
	if (m_texture_left_sound)
	{
		m_texture_left_sound->Release();
		m_texture_left_sound = NULL;
	}
	if (m_texture_right_sound)
	{
		m_texture_right_sound->Release();
		m_texture_right_sound = NULL;
	}

	//�W�����e�N�X�`��
	if (m_texture_focus)
	{
		m_texture_focus->Release();
		m_texture_focus = NULL;
	}
}

//-----------------------------------------------
// �X�V����
//-----------------------------------------------
void ROBOT::UpdateRobot(void)
{
	//����
	m_robot_app_obj.ui_cue_index = CRI_ROBOTSE_MACHINE_ANBIENTNOISE;
	app_atomex_start(&m_robot_app_obj);

	//�X�V����
	{
		//���{�̗h�ꏈ���ɕK�v
		if (m_can_shake)
		{
			m_shake_cur_time--;
			if (m_shake_cur_time <= 0)
			{
				m_shake_cur_time = 0;
				m_can_shake = false;
			}
		}

		if (m_p_network_manager->GetType() == MIDDLE_PC)
		{
			if (m_hp <= 0 && m_state != ROBOT_STATE_MISSION_FAILED)
			{//���s������

				if (m_p_network_manager->GetType() == MIDDLE_PC)
				{
					//���s�X�e�[�g�ɂ���
					m_state = ROBOT_STATE_MISSION_FAILED;
					m_frame_count = 0;

					ServerPackData(ROBOT_OBJECT, STATE, m_state);
					ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
					ServerPackData(ROBOT_OBJECT, SPECIAL_SUCCESS_NUM, m_special_success_num);
					ServerPackData(ROBOT_OBJECT, SUCCESS_NUM, m_success_num);
					ServerPackData(ROBOT_OBJECT, MISS_NUM, m_miss_num);

				}
			}
		}

		//�}�b�v�擾�H
		ROUND* round = GetRound();
		m_map_x = 1;
		m_map_z = ROBO_START_MAP_Z + round->round;

		if (m_missile_stack < 3)
		{//�e�̃X�^�b�N��3��菬����������
			//�t���[������
			m_missile_charge_frame_count++;
		}

		if (m_missile_charge_frame_count >= 600)
		{//�t���[������萔��������
			//���U
			m_missile_stack++;
			//�t���[�������Z�b�g
			m_missile_charge_frame_count = 0;

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{//�T�[�o�[
				ServerPackData(ROBOT_OBJECT, MISSILE_STACK, m_missile_stack);
				ServerPackData(ROBOT_OBJECT, MISSILE_CHARGE_FRAME_COUNT, m_missile_charge_frame_count);
			}
		}

		if (m_missile_shoot)
		{//�e��ł��Ă���
			m_missile_cool_time++;

			if (m_missile_cool_time > 30)
			{//�N�[���^�C�����I�������
				m_missile_shoot = false;
				m_missile_cool_time = 0;

				if (m_p_network_manager->GetType() == MIDDLE_PC)
				{//�T�[�o�[
					ServerPackData(ROBOT_OBJECT, MISSILE_SHOOT, m_missile_shoot);
					ServerPackData(ROBOT_OBJECT, MISSILE_COOL_TIME, m_missile_cool_time);
				}

			}
		}

		//�t���[��������
		m_frame_count++;
		if (m_left_music)
		{//�����{�^��
			//���t���[��������
			m_music_frame_count++;

			if (m_music_frame_count == MUSIC_GAP_FRAME)
			{
				if (m_next_right_music)
				{//�����ĉ����Ă���
					m_cv_num = (rand() % 4) * 2 + 1;
					m_cv_app_obj.ui_cue_index = m_cv_num;
					app_atomex_start(&m_cv_app_obj);
				}
				else
				{//�Е�����
					m_cv_num = rand() % 3 + 9;
					m_cv_app_obj.ui_cue_index = m_cv_num;
					app_atomex_start(&m_cv_app_obj);
				}
			}

			if (m_music_frame_count > LEFT_MUSIC_FRAME + MUSIC_GAP_FRAME)
			{//CV�������I�������
				if (m_next_right_music)
				{//�E���{�^���������Ă���
					m_music_frame_count = 0;
					m_left_music = false;

					m_cv_num++;
					m_cv_app_obj.ui_cue_index = m_cv_num;
					app_atomex_start(&m_cv_app_obj);

					if (m_p_network_manager->GetType() == MIDDLE_PC)
					{//�f�[�^���l�߂�
						ServerPackData(ROBOT_OBJECT, MUSIC_FRAME_COUNT, m_music_frame_count);
						ServerPackData(ROBOT_OBJECT, LEFT_MUSIC, m_left_music);
					}
				}

				else
				{//�����ĂȂ�������
					m_left_music = false;
					m_music_frame_count = 0;

					if (m_p_network_manager->GetType() == MIDDLE_PC)
					{//�f�[�^���l�߂�
						ServerPackData(ROBOT_OBJECT, LEFT_MUSIC, m_left_music);
						ServerPackData(ROBOT_OBJECT, MUSIC_FRAME_COUNT, m_music_frame_count);
					}
				}
			}
		}

		else if (m_right_music)
		{//�E���{�^��
			m_music_frame_count++;
			if (m_music_frame_count == MUSIC_GAP_FRAME)
			{
				if (m_next_left_music)
				{
					m_cv_num = (rand() % 4) * 2 + 1;
					m_cv_app_obj.ui_cue_index = m_cv_num;
					app_atomex_start(&m_cv_app_obj);
				}
				else
				{
					m_cv_num = rand() % 3 + 9;
					m_cv_app_obj.ui_cue_index = m_cv_num;
					app_atomex_start(&m_cv_app_obj);
				}
			}

			if (m_music_frame_count > RIGHT_MUSIC_FRAME + MUSIC_GAP_FRAME)
			{
				if (m_next_left_music)
				{//�����{�^���������Ă���
					m_music_frame_count = 0;
					m_right_music = false;

					m_cv_num++;
					m_cv_app_obj.ui_cue_index = m_cv_num;
					app_atomex_start(&m_cv_app_obj);

					if (m_p_network_manager->GetType() == MIDDLE_PC)
					{
						ServerPackData(ROBOT_OBJECT, MUSIC_FRAME_COUNT, m_music_frame_count);
						ServerPackData(ROBOT_OBJECT, RIGHT_MUSIC, m_right_music);
					}
				}

				else
				{//�Е�����
					m_right_music = false;
					m_music_frame_count = 0;

					if (m_p_network_manager->GetType() == MIDDLE_PC)
					{
						ServerPackData(ROBOT_OBJECT, RIGHT_MUSIC, m_right_music);
						ServerPackData(ROBOT_OBJECT, MUSIC_FRAME_COUNT, m_music_frame_count);
					}
				}
			}
		}

		if (!m_right_music && m_next_left_music)
		{//���̍���CV
			m_music_frame_count++;
			
			if (m_music_frame_count > LEFT_MUSIC_FRAME)
			{//���Z�b�g
				m_next_left_music = false;
				m_music_frame_count = 0;

				ServerPackData(ROBOT_OBJECT, NEXT_LEFT_MUSIC, m_next_left_music);
				ServerPackData(ROBOT_OBJECT, MUSIC_FRAME_COUNT, m_music_frame_count);
			}
			
		}

		else if (!m_left_music && m_next_right_music)
		{//���̉E��CV
			m_music_frame_count++;
			
			if (m_music_frame_count > RIGHT_MUSIC_FRAME)
			{//���Z�b�g
				m_next_right_music = false;
				m_music_frame_count = 0;

				ServerPackData(ROBOT_OBJECT, NEXT_RIGHT_MUSIC, m_next_right_music);
				ServerPackData(ROBOT_OBJECT, MUSIC_FRAME_COUNT, m_music_frame_count);
			}
			
		}

		//�}�C�t���[���U�����I�t
		m_is_attacking = false;
		if (m_p_network_manager->GetType() == MIDDLE_PC)
		{
			ServerPackData(ROBOT_OBJECT, IS_ATTAKING, m_is_attacking);
		}

		if (m_can_move)
		{//��������

			switch (m_state)
			{
			case ROBOT_STATE_IDLE:		//�ҋ@
			{
				CAMERA* p_camera = GetCamera();
				p_camera->TiltCamera(0);
				break;
			}
			case ROBOT_STATE_MOVE:		//�ړ�
				ROBOT::MoveRobot();
				break;

			case ROBOT_STATE_MISS:		//���s
				if (m_frame_count >= MISS_FRAME)
				{
					m_state = ROBOT_STATE_IDLE;
					m_frame_count = 0;
					AddMissNum();
					if (m_p_network_manager->GetType() == MIDDLE_PC)
					{//�T�[�o�[
						ServerPackData(ROBOT_OBJECT, STATE, m_state);
						ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
					}
				}
				break;
			case ROBOT_STATE_ATTACK:	//�p���`
				ROBOT::PunchRobot();
				break;
			case ROBOT_STATE_GUARD:		//�K�[�h
				ROBOT::GuardRobot();
				break;
			case ROBOT_STATE_SHOOT:		//�ˌ�
				ROBOT::ShootRobot();
				break;
			case ROBOT_STATE_POSE:		//���߃|�[�Y
				if (m_frame_count > POSE_FRAME)
				{
					m_state = ROBOT_STATE_IDLE;
					m_left_punch = false;
					m_right_punch = false;
					m_shoot_state = ROBOT_SHOOT_STATE_IDLE;
					m_left_shoot_state = ROBOT_LEFT_SHOOT_STATE_IDLE;
					m_right_shoot_state = ROBOT_RIGHT_SHOOT_STATE_IDLE;
					m_guard_state = ROBOT_GUARD_STATE_IDLE;
					m_left_guard_state = ROBOT_LEFT_GUARD_STATE_IDLE;
					m_right_guard_state = ROBOT_RIGHT_GUARD_STATE_IDLE;
					m_move_state = ROBOT_MOVE_STATE_IDLE;
					m_special_state = ROBOT_SPECIAL_STATE_CHANCE_TEXT;
					m_is_attacking = false;
					m_frame_count = 0;
					m_left_frame_count = 0;
					m_right_frame_count = 0;
					m_special_frame_count = 0;
					m_can_move = true;
					m_music_frame_count = 0;
					m_left_music = false;
					m_right_music = false;
					m_next_left_music = false;
					m_next_right_music = false;

					if (m_p_network_manager->GetType() == MIDDLE_PC)
					{//�T�[�o�[
						ServerPackData(ROBOT_OBJECT, RESET, 0);
					}
				}
				break;
			case ROBOT_STATE_SPECIAL:		//�K�E�Z
				ROBOT::SpecialRobot();
				for (int i = 0; i < 4; i++)
				{
					m_left_arrow[i]->Update();
					m_right_arrow[i]->Update();
				}
				break;
			case ROBOT_STATE_LOWER_BACK:	//���
				ROBOT::MapLowerBack();
				break;
			case ROBOT_STATE_INTERCEPT_ERINGI:	//�G�����M�}��
				ROBOT::InterceptEringi();
				break;
			case ROBOT_STATE_INTERCEPT_NOADORAGON_BREATH:	//�m�A�h���S���}��
				ROBOT::InterceptNoadoragonBreath();
				break;
			case ROBOT_STATE_MISSION_FAILED:		//���s
				ROBOT::MissionFailed();
				break;
			default:
				break;
			}

		}

		//�N���C�A���g�Ȃ�T�[�o�[����f�[�^�󂯎���ď�������
		if (m_p_network_manager->GetType() != MIDDLE_PC)
		{//�N���C�A���g��������

			for (int i = 0; i < MAX_SERVER_DATA_NUM; i++)
			{
				void* data = ClientGetData(i);

				if (data == nullptr)
				{
					break;
				}

				if ((int)data / (int)pow(10, MAX_DISTINCTION_NUM) == ROBOT_OBJECT)
				{//���{�f�[�^�擾
					ROBOT_VARIABLE_DISTINCT_NUM robot_variable = (ROBOT_VARIABLE_DISTINCT_NUM)(((int)data % (int)pow(10, MAX_DISTINCTION_NUM - 1)) / (int)pow(10, VALUE_DIGIT_NUM + SIGN_DISTINCTION_NUM));
					int robot_data = (int)data % (int)pow(10, VALUE_DIGIT_NUM);
					int sign = (int)data % (int)pow(10, MAX_DISTINCTION_NUM - VARIABLE_DISTINCTION_DIGIT_NUM - 1) / (int)pow(10, VALUE_DIGIT_NUM);
					if (sign == SIGN_MINUS)
					{
						robot_data *= -1;
					}

					switch (robot_variable)
					{
					case ROBOT_NONE:
						break;
					case ROBOT_POS_X:
						m_pos.x = (float)robot_data;
						break;
					case ROBOT_POS_Y:
						m_pos.y = (float)robot_data;
						break;
					case ROBOT_POS_Z:
						m_pos.z = (float)robot_data;
						break;
					case STATE:
						m_state = (ROBOT_STATE)robot_data;
						break;
					case LEFT_PUNCH:
						m_left_punch = (bool)robot_data;
						break;
					case RIGHT_PUNCH:
						m_right_punch = (bool)robot_data;
						break;
					case SHOOT_STATE:
						m_shoot_state = (ROBOT_SHOOT_STATE)robot_data;
						break;
					case LEFT_SHOOT_STATE:
						m_left_shoot_state = (ROBOT_LEFT_SHOOT_STATE)robot_data;
						break;
					case RIGHT_SHOOT_STATE:
						m_right_shoot_state = (ROBOT_RIGHT_SHOOT_STATE)robot_data;
						break;
					case GUARD_STATE:
						m_guard_state = (ROBOT_GUARD_STATE)robot_data;
						break;
					case LEFT_GUARD_STATE:
						m_left_guard_state = (ROBOT_LEFT_GUARD_STATE)robot_data;
						break;
					case RIGHT_GUARD_STATE:
						m_right_guard_state = (ROBOT_RIGHT_GUARD_STATE)robot_data;
						break;
					case MOVE_STATE:
						m_move_state = (ROBOT_MOVE_STATE)robot_data;
						break;
					case SPECIAL_STATE:
						m_special_state = (ROBOT_SPECIAL_STATE)robot_data;
						break;
					case ROBOT_MAP_X:
						m_map_x = (int)robot_data;
						break;
					case ROBOT_MAP_Z:
						m_map_z = (int)robot_data;
						break;
					case ROBOT_MAP_POS_X:
						m_map_pos.x = (float)robot_data;
						break;
					case ROBOT_MAP_POS_Y:
						m_map_pos.y = (float)robot_data;
						break;
					case ROBOT_MAP_POS_Z:
						m_map_pos.z = (float)robot_data;
						break;
					case ROBOT_HP:
						m_hp = (int)robot_data;
						break;
					case ROBOT_ATK:
						m_atk = (int)robot_data;
						break;
					case IS_ATTAKING:
						m_is_attacking = (bool)robot_data;
						break;
					case MISSILE_STACK:
						m_missile_stack = (int)robot_data;
						break;
					case MISSILE_COOL_TIME:
						m_missile_cool_time = (int)robot_data;
						break;
					case MISSILE_SHOOT:
						m_missile_shoot = (bool)robot_data;
						break;
					case SPECIAL_GAUGE:
						m_special_gauge = (int)robot_data;
						break;
					case FRAME_COUNT:
						m_frame_count = (int)robot_data;
						break;
					case LEFT_FRAME_COUNT:
						m_left_frame_count = (int)robot_data;
						break;
					case RIGHT_FRAME_COUNT:
						m_right_frame_count = (int)robot_data;
						break;
					case MISSILE_CHARGE_FRAME_COUNT:
						m_missile_charge_frame_count = (int)robot_data;
						break;
					case SPECIAL_FRAME_COUNT:
						m_special_frame_count = (int)robot_data;
						break;
					case CAN_MOVE:
						m_can_move = (bool)robot_data;
						break;
					case MUSIC_FRAME_COUNT:
						m_music_frame_count = (int)robot_data;
						break;
					case LEFT_MUSIC:
						m_left_music = (bool)robot_data;
						break;
					case RIGHT_MUSIC:
						m_right_music = (bool)robot_data;
						break;
					case NEXT_LEFT_MUSIC:
						m_next_left_music = (bool)robot_data;
						break;
					case NEXT_RIGHT_MUSIC:
						m_next_right_music = (bool)robot_data;
						break;
					case INTERCEPT_LEFT_MISSILE:
						m_intercept_left_missile = (bool)robot_data;
						break;
					case INTERCEPT_RIGHT_MISSILE:
						m_intercept_right_missile = (bool)robot_data;
						break;
					case INTERCEPT_LEFT_PUNCH:
						m_intercept_left_punch = (bool)robot_data;
						break;
					case INTERCEPT_RIGHT_PUNCH:
						m_intercept_right_punch = (bool)robot_data;
						break;
					case EXPLOSION_POS_X:
						m_explosion_pos_x = (float)robot_data;
						break;
					case EXPLOSION_POS_Y:
						m_explosion_pos_y = (float)robot_data;
						break;
					case SPECIAL_SUCCESS_NUM:
						m_special_success_num = (int)robot_data;
						break;
					case SUCCESS_NUM:
						m_success_num = (int)robot_data;
						break;
					case MISS_NUM:
						m_miss_num = (int)robot_data;
						break;
					case ROBOT_INIT_POS_X:
						m_init_pos.x = (float)robot_data;
						break;
					case ROBOT_INIT_POS_Y:
						m_init_pos.y = (float)robot_data;
						break;
					case ROBOT_INIT_POS_Z:
						m_init_pos.z = (float)robot_data;
						break;
					case ROBOT_SPECIAL_ACTIVE_SECOND:
						m_special_active_second = (int)robot_data;
						break;
					case RESET:
						m_state = ROBOT_STATE_IDLE;
						m_left_punch = false;
						m_right_punch = false;
						m_shoot_state = ROBOT_SHOOT_STATE_IDLE;
						m_left_shoot_state = ROBOT_LEFT_SHOOT_STATE_IDLE;
						m_right_shoot_state = ROBOT_RIGHT_SHOOT_STATE_IDLE;
						m_guard_state = ROBOT_GUARD_STATE_IDLE;
						m_left_guard_state = ROBOT_LEFT_GUARD_STATE_IDLE;
						m_right_guard_state = ROBOT_RIGHT_GUARD_STATE_IDLE;
						m_move_state = ROBOT_MOVE_STATE_IDLE;
						m_special_state = ROBOT_SPECIAL_STATE_CHANCE_TEXT;
						m_is_attacking = false;
						m_frame_count = 0;
						m_left_frame_count = 0;
						m_right_frame_count = 0;
						m_special_frame_count = 0;
						m_can_move = true;
						m_music_frame_count = 0;
						m_left_music = false;
						m_right_music = false;
						m_next_left_music = false;
						m_next_right_music = false;
						break;
					default:
						break;
					}

				}
				if ((int)data / (int)pow(10, MAX_DISTINCTION_NUM) == ARROW_OBJECT)
				{//���f�[�^�擾
					ARROW_VARIABLE_DISTINCT_NUM arrow_variable = (ARROW_VARIABLE_DISTINCT_NUM)(((int)data % (int)pow(10, MAX_DISTINCTION_NUM - 1)) / (int)pow(10, VALUE_DIGIT_NUM + SIGN_DISTINCTION_NUM));
					int arrow_data = (int)data % (int)pow(10, VALUE_DIGIT_NUM);
					int sign = (int)data % (int)pow(10, MAX_DISTINCTION_NUM - VARIABLE_DISTINCTION_DIGIT_NUM - 1) / (int)pow(10, VALUE_DIGIT_NUM);

					if (sign == SIGN_MINUS)
					{
						arrow_data *= -1;
					}

					switch (arrow_variable)
					{
					case LEFT_0_ARROW_POS_X:
						m_left_arrow[0]->SetPosX((float)arrow_data);
						break;
					case LEFT_0_ARROW_POS_Y:
						m_left_arrow[0]->SetPosY((float)arrow_data);
						break;
					case LEFT_0_ARROW_ROT:
						m_left_arrow[0]->SetRot((float)arrow_data);
						break;
					case LEFT_0_ARROW_USE:
						m_left_arrow[0]->SetUse((bool)arrow_data);
						break;
					case LEFT_0_ARROW_CAN_SHAKE:
						m_left_arrow[0]->SetCanShake((bool)arrow_data);
						break;
					case LEFT_0_ARROW_RAND_TIME:
						m_left_arrow[0]->SetRandTime((float)arrow_data);
						break;
					case LEFT_0_ARROW_SHAKE_DURATION:
						m_left_arrow[0]->SetShakeDulation((float)arrow_data);
						break;
					case LEFT_0_ARROW_SHAKE_STRENGTH:
						m_left_arrow[0]->SetShakeStrength((float)arrow_data);
						break;
					case LEFT_0_ARROW_SHAKE_CUR_TIME:
						m_left_arrow[0]->SetShakeCurTime((float)arrow_data);
						break;
					case LEFT_0_ARROW_INIT_POS_X:
						m_left_arrow[0]->SetInitPosX((float)arrow_data);
						break;
					case LEFT_0_ARROW_INIT_POS_Y:
						m_left_arrow[0]->SetInitPosY((float)arrow_data);
						break;
					case LEFT_1_ARROW_POS_X:
						m_left_arrow[1]->SetPosX((float)arrow_data);
						break;
					case LEFT_1_ARROW_POS_Y:
						m_left_arrow[1]->SetPosY((float)arrow_data);
						break;
					case LEFT_1_ARROW_ROT:
						m_left_arrow[1]->SetRot((float)arrow_data);
						break;
					case LEFT_1_ARROW_USE:
						m_left_arrow[1]->SetUse((bool)arrow_data);
						break;
					case LEFT_1_ARROW_CAN_SHAKE:
						m_left_arrow[1]->SetCanShake((bool)arrow_data);
						break;
					case LEFT_1_ARROW_RAND_TIME:
						m_left_arrow[1]->SetRandTime((float)arrow_data);
						break;
					case LEFT_1_ARROW_SHAKE_DURATION:
						m_left_arrow[1]->SetShakeDulation((float)arrow_data);
						break;
					case LEFT_1_ARROW_SHAKE_STRENGTH:
						m_left_arrow[1]->SetShakeStrength((float)arrow_data);
						break;
					case LEFT_1_ARROW_SHAKE_CUR_TIME:
						m_left_arrow[1]->SetShakeCurTime((float)arrow_data);
						break;
					case LEFT_1_ARROW_INIT_POS_X:
						m_left_arrow[1]->SetInitPosX((float)arrow_data);
						break;
					case LEFT_1_ARROW_INIT_POS_Y:
						m_left_arrow[1]->SetInitPosY((float)arrow_data);
						break;
					case LEFT_2_ARROW_POS_X:
						m_left_arrow[2]->SetPosX((float)arrow_data);
						break;
					case LEFT_2_ARROW_POS_Y:
						m_left_arrow[2]->SetPosY((float)arrow_data);
						break;
					case LEFT_2_ARROW_ROT:
						m_left_arrow[2]->SetRot((float)arrow_data);
						break;
					case LEFT_2_ARROW_USE:
						m_left_arrow[2]->SetUse((bool)arrow_data);
						break;
					case LEFT_2_ARROW_CAN_SHAKE:
						m_left_arrow[2]->SetCanShake((bool)arrow_data);
						break;
					case LEFT_2_ARROW_RAND_TIME:
						m_left_arrow[2]->SetRandTime((float)arrow_data);
						break;
					case LEFT_2_ARROW_SHAKE_DURATION:
						m_left_arrow[2]->SetShakeDulation((float)arrow_data);
						break;
					case LEFT_2_ARROW_SHAKE_STRENGTH:
						m_left_arrow[2]->SetShakeStrength((float)arrow_data);
						break;
					case LEFT_2_ARROW_SHAKE_CUR_TIME:
						m_left_arrow[2]->SetShakeCurTime((float)arrow_data);
						break;
					case LEFT_2_ARROW_INIT_POS_X:
						m_left_arrow[2]->SetInitPosX((float)arrow_data);
						break;
					case LEFT_2_ARROW_INIT_POS_Y:
						m_left_arrow[2]->SetInitPosY((float)arrow_data);
						break;
					case LEFT_3_ARROW_POS_X:
						m_left_arrow[3]->SetPosX((float)arrow_data);
						break;
					case LEFT_3_ARROW_POS_Y:
						m_left_arrow[3]->SetPosY((float)arrow_data);
						break;
					case LEFT_3_ARROW_ROT:
						m_left_arrow[3]->SetRot((float)arrow_data);
						break;
					case LEFT_3_ARROW_USE:
						m_left_arrow[3]->SetUse((bool)arrow_data);
						break;
					case LEFT_3_ARROW_CAN_SHAKE:
						m_left_arrow[3]->SetCanShake((bool)arrow_data);
						break;
					case LEFT_3_ARROW_RAND_TIME:
						m_left_arrow[3]->SetRandTime((float)arrow_data);
						break;
					case LEFT_3_ARROW_SHAKE_DURATION:
						m_left_arrow[3]->SetShakeDulation((float)arrow_data);
						break;
					case LEFT_3_ARROW_SHAKE_STRENGTH:
						m_left_arrow[3]->SetShakeStrength((float)arrow_data);
						break;
					case LEFT_3_ARROW_SHAKE_CUR_TIME:
						m_left_arrow[3]->SetShakeCurTime((float)arrow_data);
						break;
					case LEFT_3_ARROW_INIT_POS_X:
						m_left_arrow[3]->SetInitPosX((float)arrow_data);
						break;
					case LEFT_3_ARROW_INIT_POS_Y:
						m_left_arrow[3]->SetInitPosY((float)arrow_data);
						break;
					case RIGHT_0_ARROW_POS_X:
						m_right_arrow[0]->SetPosX((float)arrow_data);
						break;
					case RIGHT_0_ARROW_POS_Y:
						m_right_arrow[0]->SetPosY((float)arrow_data);
						break;
					case RIGHT_0_ARROW_ROT:
						m_right_arrow[0]->SetRot((float)arrow_data);
						break;
					case RIGHT_0_ARROW_USE:
						m_right_arrow[0]->SetUse((bool)arrow_data);
						break;
					case RIGHT_0_ARROW_CAN_SHAKE:
						m_right_arrow[0]->SetCanShake((bool)arrow_data);
						break;
					case RIGHT_0_ARROW_RAND_TIME:
						m_right_arrow[0]->SetRandTime((float)arrow_data);
						break;
					case RIGHT_0_ARROW_SHAKE_DURATION:
						m_right_arrow[0]->SetShakeDulation((float)arrow_data);
						break;
					case RIGHT_0_ARROW_SHAKE_STRENGTH:
						m_right_arrow[0]->SetShakeStrength((float)arrow_data);
						break;
					case RIGHT_0_ARROW_SHAKE_CUR_TIME:
						m_right_arrow[0]->SetShakeCurTime((float)arrow_data);
						break;
					case RIGHT_0_ARROW_INIT_POS_X:
						m_right_arrow[0]->SetInitPosX((float)arrow_data);
						break;
					case RIGHT_0_ARROW_INIT_POS_Y:
						m_right_arrow[0]->SetInitPosY((float)arrow_data);
						break;
					case RIGHT_1_ARROW_POS_X:
						m_right_arrow[1]->SetPosX((float)arrow_data);
						break;
					case RIGHT_1_ARROW_POS_Y:
						m_right_arrow[1]->SetPosY((float)arrow_data);
						break;
					case RIGHT_1_ARROW_ROT:
						m_right_arrow[1]->SetRot((float)arrow_data);
						break;
					case RIGHT_1_ARROW_USE:
						m_right_arrow[1]->SetUse((bool)arrow_data);
						break;
					case RIGHT_1_ARROW_CAN_SHAKE:
						m_right_arrow[1]->SetCanShake((bool)arrow_data);
						break;
					case RIGHT_1_ARROW_RAND_TIME:
						m_right_arrow[1]->SetRandTime((float)arrow_data);
						break;
					case RIGHT_1_ARROW_SHAKE_DURATION:
						m_right_arrow[1]->SetShakeDulation((float)arrow_data);
						break;
					case RIGHT_1_ARROW_SHAKE_STRENGTH:
						m_right_arrow[1]->SetShakeStrength((float)arrow_data);
						break;
					case RIGHT_1_ARROW_SHAKE_CUR_TIME:
						m_right_arrow[1]->SetShakeCurTime((float)arrow_data);
						break;
					case RIGHT_1_ARROW_INIT_POS_X:
						m_right_arrow[1]->SetInitPosX((float)arrow_data);
						break;
					case RIGHT_1_ARROW_INIT_POS_Y:
						m_right_arrow[1]->SetInitPosY((float)arrow_data);
						break;
					case RIGHT_2_ARROW_POS_X:
						m_right_arrow[2]->SetPosX((float)arrow_data);
						break;
					case RIGHT_2_ARROW_POS_Y:
						m_right_arrow[2]->SetPosY((float)arrow_data);
						break;
					case RIGHT_2_ARROW_ROT:
						m_right_arrow[2]->SetRot((float)arrow_data);
						break;
					case RIGHT_2_ARROW_USE:
						m_right_arrow[2]->SetUse((bool)arrow_data);
						break;
					case RIGHT_2_ARROW_CAN_SHAKE:
						m_right_arrow[2]->SetCanShake((bool)arrow_data);
						break;
					case RIGHT_2_ARROW_RAND_TIME:
						m_right_arrow[2]->SetRandTime((float)arrow_data);
						break;
					case RIGHT_2_ARROW_SHAKE_DURATION:
						m_right_arrow[2]->SetShakeDulation((float)arrow_data);
						break;
					case RIGHT_2_ARROW_SHAKE_STRENGTH:
						m_right_arrow[2]->SetShakeStrength((float)arrow_data);
						break;
					case RIGHT_2_ARROW_SHAKE_CUR_TIME:
						m_right_arrow[2]->SetShakeCurTime((float)arrow_data);
						break;
					case RIGHT_2_ARROW_INIT_POS_X:
						m_right_arrow[2]->SetInitPosX((float)arrow_data);
						break;
					case RIGHT_2_ARROW_INIT_POS_Y:
						m_right_arrow[2]->SetInitPosY((float)arrow_data);
						break;
					case RIGHT_3_ARROW_POS_X:
						m_right_arrow[3]->SetPosX((float)arrow_data);
						break;
					case RIGHT_3_ARROW_POS_Y:
						m_right_arrow[3]->SetPosY((float)arrow_data);
						break;
					case RIGHT_3_ARROW_ROT:
						m_right_arrow[3]->SetRot((float)arrow_data);
						break;
					case RIGHT_3_ARROW_USE:
						m_right_arrow[3]->SetUse((bool)arrow_data);
						break;
					case RIGHT_3_ARROW_CAN_SHAKE:
						m_right_arrow[3]->SetCanShake((bool)arrow_data);
						break;
					case RIGHT_3_ARROW_RAND_TIME:
						m_right_arrow[3]->SetRandTime((float)arrow_data);
						break;
					case RIGHT_3_ARROW_SHAKE_DURATION:
						m_right_arrow[3]->SetShakeDulation((float)arrow_data);
						break;
					case RIGHT_3_ARROW_SHAKE_STRENGTH:
						m_right_arrow[3]->SetShakeStrength((float)arrow_data);
						break;
					case RIGHT_3_ARROW_SHAKE_CUR_TIME:
						m_right_arrow[3]->SetShakeCurTime((float)arrow_data);
						break;
					case RIGHT_3_ARROW_INIT_POS_X:
						m_right_arrow[3]->SetInitPosX((float)arrow_data);
						break;
					case RIGHT_3_ARROW_INIT_POS_Y:
						m_right_arrow[3]->SetInitPosY((float)arrow_data);
						break;
					default:
						break;
					}
				}
			}

		}
	}
}

//-----------------------------------------------
// �`�揈��
//-----------------------------------------------
void ROBOT::DrawRobot(void)
{
	USER_TYPE type = m_p_network_manager->GetType();

	switch (m_state)
	{
	case ROBOT_STATE_IDLE:
	{
		//���̌v�Z
		float radian = (float)m_frame_count * 360.0f / IDLE_FLOATING_FRAME_COUNT * M_PI / 180.0f;
		float floating_height = IDLE_FLOATING_HEIGHT * sinf(radian);

		//���r�ҋ@
		if (!(m_left_music || (m_next_left_music || m_next_right_music)))
		{
			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_combo_punch);
			DrawSprite(type, XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f, m_pos.y + 50.0f + floating_height), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 2, 1);
		}
		//�E�r�ҋ@
		if (!(m_right_music || (m_next_right_music || m_next_left_music)))
		{
			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_combo_punch);
			DrawSprite(type, XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f, m_pos.y + 50.0f + floating_height), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 2, 1);
		}
	}
		break;
	case ROBOT_STATE_MOVE:
		break;
	case ROBOT_STATE_MISS:

		break;
	case ROBOT_STATE_ATTACK:
		if (m_left_punch)
		{
			if (m_left_frame_count <= PUNCH_RESERVE_MOTION_FRAME)
			{//�r�������i�����j
				XMFLOAT2 start_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f - PUNCH_RESERVE_MOTION_MOVE_X, m_pos.y + PUNCH_RESERVE_MOTION_MOVE_Y);
				XMFLOAT2 vec = XMFLOAT2(-PUNCH_PREPARE_MOVE_X, PUNCH_PREPARE_MOVE_Y);

				float percent = EaseInCub((float)m_left_frame_count / (float)PUNCH_RESERVE_MOTION_FRAME);

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_punch);
				DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * percent, start_pos.y + vec.y * percent), 0.0f,
					XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
			}

			else if (m_left_frame_count <= PUNCH_MOTION_FRONT_FRAME + PUNCH_RESERVE_MOTION_FRAME)
			{//�r��O�ɏo���i�p���`�j
				XMFLOAT2 start_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f - PUNCH_PREPARE_MOVE_X, m_pos.y + PUNCH_RESERVE_MOTION_MOVE_Y + PUNCH_PREPARE_MOVE_Y);
				XMFLOAT2 vec = XMFLOAT2(PUNCH_PREPARE_MOVE_X + PUNCHING_X, -PUNCH_PREPARE_MOVE_Y - PUNCHING_Y);

				float percent = EaseInCub((float)(m_left_frame_count - PUNCH_RESERVE_MOTION_FRAME) / (float)PUNCH_MOTION_FRONT_FRAME);

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_punch);
				DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * percent, start_pos.y + vec.y * percent), 0.0f,
					XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
			}

			else if (m_left_frame_count <= PUNCH_MOTION_FRONT_FRAME + PUNCH_RESERVE_MOTION_FRAME + PUNCH_MOTION_SHAKE_FRAME)
			{//�r��h�炷

				XMFLOAT3 pos = m_pos;
				if (m_can_shake)
				{
					pos = ShakeProcess();
				}

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_punch);
				DrawSprite(type, XMFLOAT2(pos.x - SCREEN_WIDTH * 0.5f + PUNCHING_X, pos.y - PUNCHING_Y + PUNCH_RESERVE_MOTION_MOVE_Y), 0.0f,
					XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
			}

			else
			{//�r��߂�
				XMFLOAT2 start_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f + PUNCHING_X, m_pos.y - PUNCHING_Y + PUNCH_RESERVE_MOTION_MOVE_Y);
				XMFLOAT2 vec = XMFLOAT2(0.0f, PUNCH_PREPARE_MOVE_Y);

				float percent = EaseInCub((float)(m_left_frame_count - PUNCH_MOTION_FRONT_FRAME - PUNCH_RESERVE_MOTION_FRAME - PUNCH_MOTION_SHAKE_FRAME) / (float)PUNCH_MOTION_BACK_FRAME);

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_punch);
				DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * percent, start_pos.y + vec.y * percent), 0.0f,
					XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
			}
		}
		else
		{
			//���̌v�Z
			float radian = (float)m_frame_count * 360.0f / IDLE_FLOATING_FRAME_COUNT * M_PI / 180.0f;
			float floating_height = IDLE_FLOATING_HEIGHT * sinf(radian);

			//���r�ҋ@
			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_combo_punch);
			DrawSprite(type, XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f, m_pos.y + 50.0f + floating_height), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 2, 1);
		}
		if (m_right_punch)
		{
			//�E�p���`�`��
			if (m_right_frame_count <= PUNCH_RESERVE_MOTION_FRAME)
			{//�r�������i�����j
				XMFLOAT2 start_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f + PUNCH_RESERVE_MOTION_MOVE_X, m_pos.y + PUNCH_RESERVE_MOTION_MOVE_Y);
				XMFLOAT2 vec = XMFLOAT2(PUNCH_PREPARE_MOVE_X, PUNCH_PREPARE_MOVE_Y);

				float percent = EaseInCub((float)m_right_frame_count / (float)PUNCH_RESERVE_MOTION_FRAME);

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_punch);
				DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * percent, start_pos.y + vec.y * percent), 0.0f,
					XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
			}

			else if (m_right_frame_count <= PUNCH_MOTION_FRONT_FRAME + PUNCH_RESERVE_MOTION_FRAME)
			{//�r��O�ɏo���i�p���`�j
				XMFLOAT2 start_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f + PUNCH_PREPARE_MOVE_X, m_pos.y + PUNCH_PREPARE_MOVE_Y + PUNCH_RESERVE_MOTION_MOVE_Y);
				XMFLOAT2 vec = XMFLOAT2(-PUNCH_PREPARE_MOVE_X - PUNCHING_X, -PUNCH_PREPARE_MOVE_Y - PUNCHING_Y);

				float percent = EaseInCub((float)(m_right_frame_count - PUNCH_MOTION_FRONT_FRAME) / (float)PUNCH_MOTION_FRONT_FRAME);

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_punch);
				DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * percent, start_pos.y + vec.y * percent), 0.0f,
					XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
			}

			else if (m_right_frame_count <= PUNCH_MOTION_FRONT_FRAME + PUNCH_RESERVE_MOTION_FRAME + PUNCH_MOTION_SHAKE_FRAME)
			{//�r��h�炷

				XMFLOAT3 pos = m_pos;
				if (m_can_shake)
				{
					pos = ShakeProcess();
				}

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_punch);
				DrawSprite(type, XMFLOAT2(pos.x + SCREEN_WIDTH * 0.5f - PUNCHING_X, pos.y - PUNCHING_Y + PUNCH_RESERVE_MOTION_MOVE_Y), 0.0f,
					XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
			}

			else
			{//�r��߂�
				XMFLOAT2 start_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f - PUNCHING_X, m_pos.y - PUNCHING_Y + PUNCH_RESERVE_MOTION_MOVE_Y);
				XMFLOAT2 vec = XMFLOAT2(0.0f, PUNCH_PREPARE_MOVE_Y);

				float percent = EaseInCub((float)(m_right_frame_count - PUNCH_MOTION_FRONT_FRAME - PUNCH_RESERVE_MOTION_FRAME - PUNCH_MOTION_SHAKE_FRAME) / (float)PUNCH_MOTION_BACK_FRAME);

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_punch);
				DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * percent, start_pos.y + vec.y * percent), 0.0f,
					XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
			}
		}
		else
		{
			//���̌v�Z
			float radian = (float)m_frame_count * 360.0f / IDLE_FLOATING_FRAME_COUNT * M_PI / 180.0f;
			float floating_height = IDLE_FLOATING_HEIGHT * sinf(radian);

			//�E�r�ҋ@
			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_combo_punch);
			DrawSprite(type, XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f, m_pos.y + 50.0f + floating_height), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 2, 1);
			
		}
		break;

	case ROBOT_STATE_GUARD:
		switch (m_guard_state)
		{
		case ROBOT_GUARD_STATE_IDLE:
		{
			switch (m_left_guard_state)
			{
			case ROBOT_LEFT_GUARD_STATE_IDLE:
				break;
			case ROBOT_LFET_GUARD_STATE_MIDDLE:
			{
				XMFLOAT2 start_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH, m_pos.y);
				XMFLOAT2 end_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f, m_pos.y);
				XMFLOAT2 vec = XMFLOAT2(end_pos.x - start_pos.x, end_pos.y - start_pos.y);

				easeInOutCubic(1.0f / GUARD_MOTION_FRONT_FRAME, LEFT_GUARD_EASING_NUM);
				float percent = GetEasing(LEFT_GUARD_EASING_NUM).posi.y;

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_guard);
				DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * percent, start_pos.y + vec.y * percent), 20.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 1, 1);

				if (m_left_frame_count == GUARD_MOTION_FRONT_FRAME)
				{
					TimeReset(LEFT_GUARD_EASING_NUM);
				}
			}
				break;
			case ROBOT_LEFT_GUARD_STATE_SUCCESS:
				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_guard);
				DrawSprite(type, XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f, m_pos.y), 20.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 1, 1);
				break;
			case ROBOT_LEFT_GUARD_STATE_MISS:
				break;
			default:
				break;
			}

			switch (m_right_guard_state)
			{
			case ROBOT_RIGHT_GUARD_STATE_IDLE:
				break;
			case ROBOT_RIGHT_GUARD_STATE_MIDDLE:
			{
				XMFLOAT2 start_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH, m_pos.y);
				XMFLOAT2 end_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f, m_pos.y);
				XMFLOAT2 vec = XMFLOAT2(end_pos.x - start_pos.x, end_pos.y - start_pos.y);

				easeInOutCubic(1.0f / GUARD_MOTION_FRONT_FRAME, RIGHT_GUARD_EASING_NUM);
				float percent = GetEasing(RIGHT_GUARD_EASING_NUM).posi.y;

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_guard);
				DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * percent, start_pos.y + vec.y * percent), -20.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 1, 1);

				if (m_right_frame_count == GUARD_MOTION_FRONT_FRAME)
				{
					TimeReset(RIGHT_GUARD_EASING_NUM);
				}
			}
				break;
			case ROBOT_RIGHT_GUARD_STATE_SUCCESS:
				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_guard);
				DrawSprite(type, XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f, m_pos.y), -20.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 1, 1);
				break;
			case ROBOT_RIGHT_GUARD_STATE_MISS:
				break;
			default:
				break;
			}

		}
			break;
		case ROBOT_GUARD_STATE_JUST_RECEPTION:

			XMFLOAT3 pos = m_pos;

			if (m_can_shake)
			{
				pos = ShakeProcess();
			}

			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_guard);
			DrawSprite(type, XMFLOAT2(pos.x - SCREEN_WIDTH * 0.5f, pos.y), 20.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 1, 1);
			
			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_guard);
			DrawSprite(type, XMFLOAT2(pos.x + SCREEN_WIDTH * 0.5f, pos.y), -20.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 1, 1);
			break;
		case ROBOT_GUARD_STATE_NORMAL_RECEPTION:
			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_guard);
			DrawSprite(type, XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f, m_pos.y), 20.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 1, 1);

			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_guard);
			DrawSprite(type, XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f, m_pos.y), -20.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 1, 1);
			break;
		case ROBOT_GUARD_STATE_JUST_SUCCESS:
		{//�W���X�K
			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_cross_guard);

			for (int i = 0; i < MAX_GUARD_AURA_NUM; i++)
			{
				if (m_frame_count % GUARD_AURA_FRAME == i * GUARD_AURA_FRAME / MAX_GUARD_AURA_NUM)
				{
					TimeReset(9 + i);
				}

				if (m_frame_count % GUARD_AURA_FRAME >= i * GUARD_AURA_FRAME / MAX_GUARD_AURA_NUM)
				{
					easeOutCubic(1.0f / GUARD_AURA_FRAME, 9 + i);

					float percent = GetEasing(9 + i).posi.y;
					float alpha = (float)(m_frame_count % GUARD_AURA_FRAME) / (float)(GUARD_AURA_FRAME + GUARD_AURA_FRAME / MAX_GUARD_AURA_NUM * i);

					DrawSprite(type, XMFLOAT2(m_pos.x, m_pos.y), 0.0f, XMFLOAT2(SCREEN_WIDTH * 1.75f * percent, SCREEN_HEIGHT * 1.75f * percent), XMFLOAT4(1.0f, 1.0f, 1.0f, 0.8f - alpha), 1, 1, 0);
				}
			}

			XMFLOAT3 shake_pos = m_pos;
			if (m_can_shake)
			{
				shake_pos = ShakeProcess();
			}

			XMFLOAT2 left_start_pos = XMFLOAT2(shake_pos.x - SCREEN_WIDTH * 0.5f, shake_pos.y);
			XMFLOAT2 left_end_pos = XMFLOAT2(shake_pos.x - SCREEN_WIDTH * 0.25f, shake_pos.y);
			XMFLOAT2 left_vec = XMFLOAT2(left_end_pos.x - left_start_pos.x, left_end_pos.y - left_start_pos.y);

			easeInOutCubic(1.0f / 10.0f, LEFT_GUARD_EASING_NUM);
			float left_percent = GetEasing(LEFT_GUARD_EASING_NUM).posi.y;
			if (left_percent >= 1.0f)
			{
				left_percent = 1.0f;
			}

			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_guard);
			DrawSprite(type, XMFLOAT2(left_start_pos.x + left_vec.x * left_percent, left_start_pos.y + left_vec.y * left_percent), 20.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 1, 1);

			XMFLOAT2 right_start_pos = XMFLOAT2(shake_pos.x + SCREEN_WIDTH * 0.5f, shake_pos.y);
			XMFLOAT2 right_end_pos = XMFLOAT2(shake_pos.x + SCREEN_WIDTH * 0.25f, shake_pos.y);
			XMFLOAT2 right_vec = XMFLOAT2(right_end_pos.x - right_start_pos.x, right_end_pos.y - right_start_pos.y);

			easeInOutCubic(1.0f / 10.0f, RIGHT_GUARD_EASING_NUM);
			float right_percent = GetEasing(RIGHT_GUARD_EASING_NUM).posi.y;

			if (right_percent >= 1.0f)
			{
				right_percent = 1.0f;
			}

			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_guard);
			DrawSprite(type, XMFLOAT2(right_start_pos.x + right_vec.x * right_percent, right_start_pos.y + right_vec.y * right_percent), -20.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 1, 1);

			if (m_frame_count == GUARD_SUCCESS_FRAME)
			{
				TimeReset(LEFT_GUARD_EASING_NUM);
				TimeReset(RIGHT_GUARD_EASING_NUM);
			}
		}
			break;
		case ROBOT_GUARD_STATE_NORMAL_SUCCESS:
		{
			XMFLOAT3 shake_pos = m_pos;
			if (m_can_shake)
			{
				shake_pos = ShakeProcess();
			}

			XMFLOAT2 left_start_pos = XMFLOAT2(shake_pos.x - SCREEN_WIDTH * 0.5f, shake_pos.y);
			XMFLOAT2 left_end_pos = XMFLOAT2(shake_pos.x - SCREEN_WIDTH * 0.25f, shake_pos.y);
			XMFLOAT2 left_vec = XMFLOAT2(left_end_pos.x - left_start_pos.x, left_end_pos.y - left_start_pos.y);

			easeInOutCubic(1.0f / 10.0f, LEFT_GUARD_EASING_NUM);
			float left_percent = GetEasing(LEFT_GUARD_EASING_NUM).posi.y;
			if (left_percent >= 1.0f)
			{
				left_percent = 1.0f;
			}

			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_guard);
			DrawSprite(type, XMFLOAT2(left_start_pos.x + left_vec.x * left_percent, left_start_pos.y + left_vec.y * left_percent), 20.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 1, 1);

			XMFLOAT2 right_start_pos = XMFLOAT2(shake_pos.x + SCREEN_WIDTH * 0.5f, shake_pos.y);
			XMFLOAT2 right_end_pos = XMFLOAT2(shake_pos.x + SCREEN_WIDTH * 0.25f, shake_pos.y);
			XMFLOAT2 right_vec = XMFLOAT2(right_end_pos.x - right_start_pos.x, right_end_pos.y - right_start_pos.y);

			easeInOutCubic(1.0f / 10.0f, RIGHT_GUARD_EASING_NUM);
			float right_percent = GetEasing(RIGHT_GUARD_EASING_NUM).posi.y;

			if (right_percent >= 1.0f)
			{
				right_percent = 1.0f;
			}

			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_guard);
			DrawSprite(type, XMFLOAT2(right_start_pos.x + right_vec.x * right_percent, right_start_pos.y + right_vec.y * right_percent), -20.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 1, 1);

			if (m_frame_count == GUARD_SUCCESS_FRAME)
			{
				TimeReset(LEFT_GUARD_EASING_NUM);
				TimeReset(RIGHT_GUARD_EASING_NUM);
			}
		}
			break;
		case ROBOT_GUARD_STATE_SUCCESS_FINISH:
		{
			XMFLOAT2 left_start_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.25f, m_pos.y);
			XMFLOAT2 left_end_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.25f, m_pos.y + SCREEN_HEIGHT * 1.5f);
			XMFLOAT2 left_vec = XMFLOAT2(left_end_pos.x - left_start_pos.x, left_end_pos.y - left_start_pos.y);

			easeInOutCubic(1.0f / GUARD_MOTION_BACK_FRAME, LEFT_GUARD_EASING_NUM);
			float left_percent = GetEasing(LEFT_GUARD_EASING_NUM).posi.y;

			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_guard);
			DrawSprite(type, XMFLOAT2(left_start_pos.x + left_vec.x * left_percent, left_start_pos.y + left_vec.y * left_percent), 30.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 1, 1);

			XMFLOAT2 right_start_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.25f, m_pos.y);
			XMFLOAT2 right_end_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.25f, m_pos.y + SCREEN_HEIGHT * 1.5f);
			XMFLOAT2 right_vec = XMFLOAT2(right_end_pos.x - right_start_pos.x, right_end_pos.y - right_start_pos.y);

			easeInOutCubic(1.0f / GUARD_MOTION_BACK_FRAME, RIGHT_GUARD_EASING_NUM);
			float right_percent = GetEasing(RIGHT_GUARD_EASING_NUM).posi.y;

			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_guard);
			DrawSprite(type, XMFLOAT2(right_start_pos.x + right_vec.x * right_percent, right_start_pos.y + right_vec.y * right_percent), -30.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 1, 1);
		
			if (m_frame_count == GUARD_MOTION_BACK_FRAME)
			{
				TimeReset(LEFT_GUARD_EASING_NUM);
				TimeReset(RIGHT_GUARD_EASING_NUM);
			}

		}
			break;
		case ROBOT_GUARD_STATE_NORMAL_FINISH:
		{
			XMFLOAT2 left_start_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f, m_pos.y);
			XMFLOAT2 left_end_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f, m_pos.y + SCREEN_HEIGHT * 1.5f);
			XMFLOAT2 left_vec = XMFLOAT2(left_end_pos.x - left_start_pos.x, left_end_pos.y - left_start_pos.y);

			easeInOutCubic(1.0f / GUARD_MOTION_BACK_FRAME, LEFT_GUARD_EASING_NUM);
			float left_percent = GetEasing(LEFT_GUARD_EASING_NUM).posi.y;

			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_guard);
			DrawSprite(type, XMFLOAT2(left_start_pos.x + left_vec.x * left_percent, left_start_pos.y + left_vec.y * left_percent), 30.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 1, 1);

			XMFLOAT2 right_start_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f, m_pos.y);
			XMFLOAT2 right_end_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f, m_pos.y + SCREEN_HEIGHT * 1.5f);
			XMFLOAT2 right_vec = XMFLOAT2(right_end_pos.x - right_start_pos.x, right_end_pos.y - right_start_pos.y);

			easeInOutCubic(1.0f / GUARD_MOTION_BACK_FRAME, RIGHT_GUARD_EASING_NUM);
			float right_percent = GetEasing(RIGHT_GUARD_EASING_NUM).posi.y;

			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_guard);
			DrawSprite(type, XMFLOAT2(right_start_pos.x + right_vec.x * right_percent, right_start_pos.y + right_vec.y * right_percent), -30.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 1, 1);
		
			if (m_frame_count == GUARD_MOTION_BACK_FRAME)
			{
				TimeReset(LEFT_GUARD_EASING_NUM);
				TimeReset(RIGHT_GUARD_EASING_NUM);
			}
		}
			break;
		case ROBOT_GUARD_STATE_MISS:
			if (m_left_guard_state == ROBOT_LEFT_GUARD_STATE_MISS)
			{
				XMFLOAT2 start_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f, m_pos.y);
				XMFLOAT2 end_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f, m_pos.y + SCREEN_HEIGHT);
				XMFLOAT2 vec = XMFLOAT2(end_pos.x - start_pos.x, end_pos.y - start_pos.y);
				
				easeInOutCubic(1.0f / GUARD_MOTION_BACK_FRAME, LEFT_GUARD_EASING_NUM);
				float percent = GetEasing(LEFT_GUARD_EASING_NUM).posi.y;

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_guard);
				DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * percent, start_pos.y + vec.y * percent), 30.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 1, 1);

				if (m_left_frame_count == GUARD_MOTION_BACK_FRAME)
				{
					TimeReset(LEFT_GUARD_EASING_NUM);
				}
			}

			if (m_right_guard_state == ROBOT_RIGHT_GUARD_STATE_MISS)
			{
				XMFLOAT2 start_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f, m_pos.y);
				XMFLOAT2 end_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f, m_pos.y + SCREEN_HEIGHT);
				XMFLOAT2 vec = XMFLOAT2(end_pos.x - start_pos.x, end_pos.y - start_pos.y);

				easeInOutCubic(1.0f / GUARD_MOTION_BACK_FRAME, RIGHT_GUARD_EASING_NUM);
				float percent = GetEasing(RIGHT_GUARD_EASING_NUM).posi.y;

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_guard);
				DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * percent, start_pos.y + vec.y * percent), -30.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 1, 1);

				if (m_right_frame_count == GUARD_MOTION_BACK_FRAME)
				{
					TimeReset(RIGHT_GUARD_EASING_NUM);
				}
			}

			break;
		default:
			break;
		}
		break;
	case ROBOT_STATE_SHOOT:
		switch (m_shoot_state)
		{
		case ROBOT_SHOOT_STATE_IDLE:
		{
			switch (m_left_shoot_state)
			{
			case ROBOT_LEFT_SHOOT_STATE_IDLE:
				break;
			case ROBOT_LEFT_SHOOT_STATE_MIDDLE:
			{
				XMFLOAT2 start_pos = XMFLOAT2(-SCREEN_WIDTH * 0.5f, SCREEN_HEIGHT * 1.5f);
				XMFLOAT2 end_pos = XMFLOAT2(-SCREEN_WIDTH * 0.5f, 0.0f);
				XMFLOAT2 vec = XMFLOAT2(end_pos.x - start_pos.x, end_pos.y - start_pos.y);

				float percent = EaseOutCub((float)m_left_frame_count / (float)SHOOT_MOTION_FRONT_FRAME);

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_ult_arm);
				DrawSprite(type, XMFLOAT2(m_pos.x + start_pos.x + vec.x * percent, m_pos.y + start_pos.y + vec.y * percent), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);

			}
				break;
			case ROBOT_LEFT_SHOOT_STATE_SUCCESS:
				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_ult_arm);
				DrawSprite(type, XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f, m_pos.y), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);

				break;
			case ROBOT_LEFT_SHOOT_STATE_MISS:
				break;
			default:
				break;
			}

			switch (m_right_shoot_state)
			{
			case ROBOT_RIGHT_SHOOT_STATE_IDLE:
				break;
			case ROBOT_RIGHT_SHOOT_STATE_MIDDLE:
			{
				XMFLOAT2 start_pos = XMFLOAT2(SCREEN_WIDTH * 0.5f, SCREEN_HEIGHT * 1.5f);
				XMFLOAT2 end_pos = XMFLOAT2(SCREEN_WIDTH * 0.5f, 0.0f);
				XMFLOAT2 vec = XMFLOAT2(end_pos.x - start_pos.x, end_pos.y - start_pos.y);

				float percent = EaseOutCub((float)m_right_frame_count / (float)SHOOT_MOTION_FRONT_FRAME);

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_ult_arm);
				DrawSprite(type, XMFLOAT2(m_pos.x + start_pos.x + vec.x * percent, m_pos.y + start_pos.y + vec.y * percent), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);

			}
				break;
			case ROBOT_RIGHT_SHOOT_STATE_SUCCESS:
				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_ult_arm);
				DrawSprite(type, XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f, m_pos.y), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
				break;
			case ROBOT_RIGHT_SHOOT_STATE_MISS:
				break;
			default:
				break;
			}
		}
			break;
		case ROBOT_SHOOT_STATE_SUCCESS:
		{
			if (m_frame_count <= SHOOT_MOTION_STAY_FRAME)
			{
				XMFLOAT3 pos = m_pos;
				if (m_can_shake)
				{
					pos = ShakeProcess();
				}

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_ult_arm);
				DrawSprite(type, XMFLOAT2(pos.x - SCREEN_WIDTH * 0.5f, pos.y), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_ult_arm);
				DrawSprite(type, XMFLOAT2(pos.x + SCREEN_WIDTH * 0.5f, pos.y), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
			}

			else
			{
				float vec = SCREEN_HEIGHT * 1.5f;
				float percent = EaseOutCub((float)(m_frame_count - SHOOT_MOTION_STAY_FRAME) / (float)SHOOT_MOTION_BACK_FRAME);

				XMFLOAT3 pos = m_pos;
				if (m_can_shake)
				{
					pos = ShakeProcess();
				}

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_ult_arm);
				DrawSprite(type, XMFLOAT2(pos.x - SCREEN_WIDTH * 0.5f, pos.y + vec * percent), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_ult_arm);
				DrawSprite(type, XMFLOAT2(pos.x + SCREEN_WIDTH * 0.5f, pos.y + vec * percent), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
			}
		}
			break;
		case ROBOT_SHOOT_STATE_MISS:
			if (m_left_shoot_state == ROBOT_LEFT_SHOOT_STATE_MISS)
			{
				float vec = SCREEN_HEIGHT * 1.5f;
				float percent = EaseOutCub((float)m_frame_count / (float)SHOOT_MOTION_BACK_FRAME);

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_ult_arm);
				DrawSprite(type, XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f, m_pos.y + vec * percent), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
			}

			if (m_right_shoot_state == ROBOT_RIGHT_SHOOT_STATE_MISS)
			{
				float vec = SCREEN_HEIGHT * 1.5f;
				float percent = EaseOutCub((float)m_frame_count / (float)SHOOT_MOTION_BACK_FRAME);

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_ult_arm);
				DrawSprite(type, XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f, m_pos.y + vec * percent), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
			}

			break;
		default:
			break;
		}
		break;

	case ROBOT_STATE_POSE:
	{
		int frame_count = m_frame_count % POSE_MOTION_FRAME;
		int tex = (float)frame_count / ((float)POSE_MOTION_FRAME / (float)POSE_MOTION_TEXTURE_MAX);
		if (m_frame_count / POSE_MOTION_FRAME % 2 == 1)
		{
			tex = POSE_MOTION_TEXTURE_MAX - tex - 1;
		}
		GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_pose);
		DrawSprite(type, XMFLOAT2(m_pos.x, m_pos.y), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 4, 2, tex);
		DrawSprite(type, XMFLOAT2(m_pos.x - SCREEN_WIDTH, m_pos.y), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 4, 2, tex);
		DrawSprite(type, XMFLOAT2(m_pos.x + SCREEN_WIDTH, m_pos.y), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 4, 2, tex);
	}
	break;
	case ROBOT_STATE_SPECIAL:
	{
		switch (m_special_state)
		{
		case ROBOT_SPECIAL_STATE_CHANCE_TEXT:
		case ROBOT_SPECIAL_STATE_1ST_IDLE:
		case ROBOT_SPECIAL_STATE_1ST_LEFT:
		case ROBOT_SPECIAL_STATE_1ST_RIGHT:
		case ROBOT_SPECIAL_STATE_2ND_IDLE:
		case ROBOT_SPECIAL_STATE_2ND_LEFT:
		case ROBOT_SPECIAL_STATE_2ND_RIGHT:
		case ROBOT_SPECIAL_STATE_3RD_IDLE:
		case ROBOT_SPECIAL_STATE_3RD_LEFT:
		case ROBOT_SPECIAL_STATE_3RD_RIGHT:
		case ROBOT_SPECIAL_STATE_4TH_IDLE:
		case ROBOT_SPECIAL_STATE_4TH_LEFT:
		case ROBOT_SPECIAL_STATE_4TH_RIGHT:
			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_focus);
			DrawSpriteUI(type, XMFLOAT2(0.0f, 0.0f), 0.0f, XMFLOAT2(SCREEN_WIDTH * 3.0f, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 6, m_special_frame_count % 6);
			break;
		case ROBOT_SPECIAL_STATE_SUCCESS_IDLE:
			//���旬��
			break;
		case ROBOT_SPECIAL_STATE_SUCCESS:
			//�r
		{
			XMFLOAT3 pos = m_pos;
			if (m_can_shake)
			{
				pos = ShakeProcess();
			}
			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_ult_arm);
			DrawSprite(type, XMFLOAT2(pos.x - SCREEN_WIDTH * 0.5f, pos.y + 300.0f), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_ult_arm);
			DrawSprite(type, XMFLOAT2(pos.x + SCREEN_WIDTH * 0.5f, pos.y + 300.0f), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
		}
			break;
		case ROBOT_SPECIAL_STATE_MISS:
			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_special_miss);
			DrawSprite(type, XMFLOAT2(m_pos.x, m_pos.y), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
			break;
		default:
			break;
		}
	}
	break;
	case ROBOT_STATE_LOWER_BACK:
	{
		int tex = m_frame_count / LOWER_BACK_MOTION_FRAME / LOWER_BACK_MOTION_TEXTURE_MAX;

		//���ꃂ�[�V����
		GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_lower_back);
		DrawSprite(type, XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f, m_pos.y), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), LOWER_BACK_MOTION_TEXTURE_MAX, 1, tex);
		GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_lower_back);
		DrawSprite(type, XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f, m_pos.y), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), LOWER_BACK_MOTION_TEXTURE_MAX, 1, tex);
	}
	break;
	case ROBOT_STATE_INTERCEPT_ERINGI:
	{
		if (m_frame_count < 180)
		{
			XMFLOAT2 start_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f - 200.0f, m_pos.y + SCREEN_HEIGHT * 1.5f);
			XMFLOAT2 end_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f, m_pos.y);
			XMFLOAT2 vec = XMFLOAT2(end_pos.x - start_pos.x, end_pos.y - start_pos.y);
			float percent = EaseOutCub((float)m_frame_count / 180.0f);

			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_ult_arm);
			DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * percent, start_pos.y + vec.y * percent), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);

			start_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f + 200.0f, m_pos.y + SCREEN_HEIGHT * 1.5f);
			end_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f, m_pos.y);
			vec = XMFLOAT2(end_pos.x - start_pos.x, end_pos.y - start_pos.y);

			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_ult_arm);
			DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * percent, start_pos.y + vec.y * percent), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
		}

		else
		{
			XMFLOAT3 pos = m_pos;
			if (m_can_shake)
			{
				pos = ShakeProcess();
			}
			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_ult_arm);
			DrawSprite(type, XMFLOAT2(pos.x - SCREEN_WIDTH * 0.5f, pos.y), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);

			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_ult_arm);
			DrawSprite(type, XMFLOAT2(pos.x + SCREEN_WIDTH * 0.5f, pos.y), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
		}
	}
		break;
	case ROBOT_STATE_INTERCEPT_NOADORAGON_BREATH:
	{
		if (m_intercept_left_punch)
		{
			if (m_left_frame_count <= PUNCH_RESERVE_MOTION_FRAME)
			{//�r�������i�����j
				XMFLOAT2 start_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f - PUNCH_RESERVE_MOTION_MOVE_X, m_pos.y + PUNCH_RESERVE_MOTION_MOVE_Y);
				XMFLOAT2 vec = XMFLOAT2(-PUNCH_PREPARE_MOVE_X, PUNCH_PREPARE_MOVE_Y);


				easeInCubic(1.0f / PUNCH_RESERVE_MOTION_FRAME, LEFT_ATTACK_EASING_NUM);
				float percent = GetEasing(LEFT_ATTACK_EASING_NUM).posi.y;

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_punch);
				DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * percent, start_pos.y + vec.y * percent), 0.0f,
					XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);

				if (m_left_frame_count == PUNCH_RESERVE_MOTION_FRAME)
				{
					TimeReset(LEFT_ATTACK_EASING_NUM);
				}
			}

			else if (m_left_frame_count <= PUNCH_MOTION_FRONT_FRAME + PUNCH_RESERVE_MOTION_FRAME)
			{//�r��O�ɏo���i�p���`�j
				XMFLOAT2 start_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f - PUNCH_PREPARE_MOVE_X, m_pos.y + PUNCH_RESERVE_MOTION_MOVE_Y + PUNCH_PREPARE_MOVE_Y);
				XMFLOAT2 vec = XMFLOAT2(PUNCH_PREPARE_MOVE_X + PUNCHING_X, -PUNCH_PREPARE_MOVE_Y - PUNCHING_Y);

				easeInCubic(1.0f / (PUNCH_MOTION_FRONT_FRAME), LEFT_ATTACK_EASING_NUM);
				float percent = GetEasing(LEFT_ATTACK_EASING_NUM).posi.y;

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_punch);
				DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * percent, start_pos.y + vec.y * percent), 0.0f,
					XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);

				if (m_left_frame_count == PUNCH_MOTION_FRONT_FRAME + PUNCH_RESERVE_MOTION_FRAME)
				{
					TimeReset(LEFT_ATTACK_EASING_NUM);
				}
			}

			else if (m_left_frame_count <= PUNCH_MOTION_FRONT_FRAME + PUNCH_RESERVE_MOTION_FRAME + PUNCH_MOTION_SHAKE_FRAME)
			{//�r��h�炷

				XMFLOAT3 pos = m_pos;
				if (m_can_shake)
				{
					pos = ShakeProcess();
				}

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_punch);
				DrawSprite(type, XMFLOAT2(pos.x - SCREEN_WIDTH * 0.5f + PUNCHING_X, pos.y - PUNCHING_Y + PUNCH_RESERVE_MOTION_MOVE_Y), 0.0f,
					XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
			}

			else
			{//�r��߂�
				XMFLOAT2 start_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f + PUNCHING_X, m_pos.y - PUNCHING_Y + PUNCH_RESERVE_MOTION_MOVE_Y);
				XMFLOAT2 vec = XMFLOAT2(0.0f, PUNCH_PREPARE_MOVE_Y);

				easeInCubic(1.0f / PUNCH_MOTION_BACK_FRAME, LEFT_ATTACK_EASING_NUM);
				float percent = GetEasing(LEFT_ATTACK_EASING_NUM).posi.y;

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_punch);
				DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * percent, start_pos.y + vec.y * percent), 0.0f,
					XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);

				if (m_left_frame_count == PUNCH_MOTION_FRONT_FRAME + PUNCH_RESERVE_MOTION_FRAME + PUNCH_MOTION_SHAKE_FRAME + PUNCH_MOTION_BACK_FRAME)
				{
					TimeReset(LEFT_ATTACK_EASING_NUM);
				}
			}
		}
		else
		{
			float radian = (float)m_frame_count * 360.0f / IDLE_FLOATING_FRAME_COUNT * M_PI / 180.0f;
			float floating_height = IDLE_FLOATING_HEIGHT * sinf(radian);

			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_combo_punch);
			DrawSprite(type, XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f, m_pos.y + 50.0f + floating_height), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 2, 1);
		}

		if (m_intercept_right_punch)
		{
			if (m_right_frame_count <= PUNCH_RESERVE_MOTION_FRAME)
			{//�r�������i�����j
				XMFLOAT2 start_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f + PUNCH_RESERVE_MOTION_MOVE_X, m_pos.y + PUNCH_RESERVE_MOTION_MOVE_Y);
				XMFLOAT2 vec = XMFLOAT2(PUNCH_PREPARE_MOVE_X, PUNCH_PREPARE_MOVE_Y);


				easeInCubic(1.0f / PUNCH_RESERVE_MOTION_FRAME, RIGHT_ATTACK_EASING_NUM);
				float percent = GetEasing(RIGHT_ATTACK_EASING_NUM).posi.y;

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_punch);
				DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * percent, start_pos.y + vec.y * percent), 0.0f,
					XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);

				if (m_right_frame_count == PUNCH_RESERVE_MOTION_FRAME)
				{
					TimeReset(RIGHT_ATTACK_EASING_NUM);
				}
			}

			else if (m_right_frame_count <= PUNCH_MOTION_FRONT_FRAME + PUNCH_RESERVE_MOTION_FRAME)
			{//�r��O�ɏo���i�p���`�j
				XMFLOAT2 start_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f + PUNCH_PREPARE_MOVE_X, m_pos.y + PUNCH_PREPARE_MOVE_Y + PUNCH_RESERVE_MOTION_MOVE_Y);
				XMFLOAT2 vec = XMFLOAT2(-PUNCH_PREPARE_MOVE_X - PUNCHING_X, -PUNCH_PREPARE_MOVE_Y - PUNCHING_Y);

				easeInCubic(1.0f / (PUNCH_MOTION_FRONT_FRAME), RIGHT_ATTACK_EASING_NUM);
				float percent = GetEasing(RIGHT_ATTACK_EASING_NUM).posi.y;

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_punch);
				DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * percent, start_pos.y + vec.y * percent), 0.0f,
					XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);

				if (m_right_frame_count == PUNCH_MOTION_FRONT_FRAME + PUNCH_RESERVE_MOTION_FRAME)
				{
					TimeReset(RIGHT_ATTACK_EASING_NUM);
				}
			}

			else if (m_right_frame_count <= PUNCH_MOTION_FRONT_FRAME + PUNCH_RESERVE_MOTION_FRAME + PUNCH_MOTION_SHAKE_FRAME)
			{//�r��h�炷

				XMFLOAT3 pos = m_pos;
				if (m_can_shake)
				{
					pos = ShakeProcess();
				}

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_punch);
				DrawSprite(type, XMFLOAT2(pos.x + SCREEN_WIDTH * 0.5f - PUNCHING_X, pos.y - PUNCHING_Y + PUNCH_RESERVE_MOTION_MOVE_Y), 0.0f,
					XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
			}

			else
			{//�r��߂�
				XMFLOAT2 start_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f - PUNCHING_X, m_pos.y - PUNCHING_Y + PUNCH_RESERVE_MOTION_MOVE_Y);
				XMFLOAT2 vec = XMFLOAT2(0.0f, PUNCH_PREPARE_MOVE_Y);

				easeInCubic(1.0f / PUNCH_MOTION_BACK_FRAME, RIGHT_ATTACK_EASING_NUM);
				float percent = GetEasing(RIGHT_ATTACK_EASING_NUM).posi.y;

				GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_punch);
				DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * percent, start_pos.y + vec.y * percent), 0.0f,
					XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);

				if (m_right_frame_count == PUNCH_MOTION_FRONT_FRAME + PUNCH_RESERVE_MOTION_FRAME + PUNCH_MOTION_SHAKE_FRAME + PUNCH_MOTION_BACK_FRAME)
				{
					TimeReset(RIGHT_ATTACK_EASING_NUM);
				}
			}
		}
		else
		{
			float radian = (float)m_frame_count * 360.0f / IDLE_FLOATING_FRAME_COUNT * M_PI / 180.0f;
			float floating_height = IDLE_FLOATING_HEIGHT * sinf(radian);

			GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_combo_punch);
			DrawSprite(type, XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f, m_pos.y + 50.0f + floating_height), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 2, 2, 1);
		}
	}
		break;
	default:
		break;
	}

	if (m_left_music)
	{
		XMFLOAT2 start_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f, m_pos.y + SCREEN_HEIGHT);
		XMFLOAT2 end_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f, m_pos.y);
		XMFLOAT2 vec = XMFLOAT2(end_pos.x - start_pos.x, end_pos.y - start_pos.y);

		float percent = EaseOutElastic((float)m_music_frame_count / (float)MUSIC_ARM_MOTION_FRAME);

		GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_sound);
		DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * percent, start_pos.y + vec.y * percent), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
	}

	else if (m_right_music)
	{
		XMFLOAT2 start_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f, m_pos.y + SCREEN_HEIGHT);
		XMFLOAT2 end_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f, m_pos.y);
		XMFLOAT2 vec = XMFLOAT2(end_pos.x - start_pos.x, end_pos.y - start_pos.y);

		float easing = EaseOutElastic((float)m_music_frame_count / (float)MUSIC_ARM_MOTION_FRAME);

		GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_sound);
		DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * easing, start_pos.y + vec.y * easing), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
	}

	if (!m_right_music && m_next_left_music)
	{
		GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_sound);
		DrawSprite(type, XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f, m_pos.y), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);

		XMFLOAT2 start_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f, m_pos.y + SCREEN_HEIGHT);
		XMFLOAT2 end_pos = XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f, m_pos.y);
		XMFLOAT2 vec = XMFLOAT2(end_pos.x - start_pos.x, end_pos.y - start_pos.y);

		float easing = EaseOutElastic((float)m_music_frame_count / (float)MUSIC_ARM_MOTION_FRAME);

		GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_sound);
		DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * easing, start_pos.y + vec.y * easing), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
	}

	else if (!m_left_music && m_next_right_music)
	{
		GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_left_sound);
		DrawSprite(type, XMFLOAT2(m_pos.x - SCREEN_WIDTH * 0.5f, m_pos.y), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);

		XMFLOAT2 start_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f, m_pos.y + SCREEN_HEIGHT);
		XMFLOAT2 end_pos = XMFLOAT2(m_pos.x + SCREEN_WIDTH * 0.5f, m_pos.y);
		XMFLOAT2 vec = XMFLOAT2(end_pos.x - start_pos.x, end_pos.y - start_pos.y);

		float easing = EaseOutElastic((float)m_music_frame_count / (float)MUSIC_ARM_MOTION_FRAME);

		GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture_right_sound);
		DrawSprite(type, XMFLOAT2(start_pos.x + vec.x * easing, start_pos.y + vec.y * easing), 0.0f, XMFLOAT2(SCREEN_WIDTH, SCREEN_HEIGHT), XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), 1, 1, 0);
	}

}

//-----------------------------------------------
// �p���`����
//-----------------------------------------------
void ROBOT::PunchRobot(void)
{
	if (m_left_punch)
	{
		m_left_frame_count++;
		if (m_left_frame_count > PUNCH_MOTION_FRONT_FRAME + PUNCH_RESERVE_MOTION_FRAME && m_left_frame_count <= PUNCH_MOTION_FRONT_FRAME + PUNCH_RESERVE_MOTION_FRAME + IS_ATTACKING_TIME)
		{
			m_is_attacking = true;

			//SE
			m_robot_app_obj.ui_cue_index = CRI_ROBOTSE_ROBO_PUNCH;
			app_atomex_start(&m_robot_app_obj);


			CAMERA* p_camera = GetCamera();
			p_camera->ShakeCamera(PUNCH_MOTION_SHAKE_STRENGTH, PUNCH_MOTION_SHAKE_FRAME);

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{//�T�[�o�[
				ServerPackData(ROBOT_OBJECT, IS_ATTAKING, m_is_attacking);
			}
		}
		if (m_left_frame_count > PUNCH_MOTION_FRONT_FRAME + PUNCH_MOTION_BACK_FRAME + PUNCH_RESERVE_MOTION_FRAME + PUNCH_MOTION_SHAKE_FRAME)
		{
			m_frame_count = 0;
			m_left_frame_count = 0;
			m_left_punch = false;

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{
				ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
				ServerPackData(ROBOT_OBJECT, LEFT_FRAME_COUNT, m_left_frame_count);
				ServerPackData(ROBOT_OBJECT, LEFT_PUNCH, m_left_punch);
			}

			if (!m_right_punch)
			{//�E���p���`���ĂȂ�������A�C�h����
				m_state = ROBOT_STATE_IDLE;

				if (m_p_network_manager->GetType() == MIDDLE_PC)
				{
					ServerPackData(ROBOT_OBJECT, STATE, m_state);
				}

			}
		}
	}

	if (m_right_punch)
	{
		m_right_frame_count++;
		if (m_right_frame_count > PUNCH_MOTION_FRONT_FRAME + PUNCH_RESERVE_MOTION_FRAME && m_right_frame_count <= PUNCH_MOTION_FRONT_FRAME + PUNCH_RESERVE_MOTION_FRAME + IS_ATTACKING_TIME)
		{
			m_is_attacking = true;

			//SE
			m_robot_app_obj.ui_cue_index = CRI_ROBOTSE_ROBO_PUNCH;
			app_atomex_start(&m_robot_app_obj);


			CAMERA* p_camera = GetCamera();
			p_camera->ShakeCamera(PUNCH_MOTION_SHAKE_STRENGTH, PUNCH_MOTION_SHAKE_FRAME);

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{//�T�[�o�[
				ServerPackData(ROBOT_OBJECT, IS_ATTAKING, m_is_attacking);
			}
		}
		if (m_right_frame_count > PUNCH_MOTION_FRONT_FRAME + PUNCH_MOTION_BACK_FRAME + PUNCH_RESERVE_MOTION_FRAME + PUNCH_MOTION_SHAKE_FRAME)
		{
			m_frame_count = 0;
			m_right_frame_count = 0;
			m_right_punch = false;

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{
				ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
				ServerPackData(ROBOT_OBJECT, RIGHT_FRAME_COUNT, m_right_frame_count);
				ServerPackData(ROBOT_OBJECT, RIGHT_PUNCH, m_right_punch);
			}

			if (!m_left_punch)
			{//�����p���`���ĂȂ�������A�C�h����
				m_state = ROBOT_STATE_IDLE;

				if (m_p_network_manager->GetType() == MIDDLE_PC)
				{
					ServerPackData(ROBOT_OBJECT, STATE, m_state);
				}

			}
		}
	}


}

//-----------------------------------------------
// �ړ�����
//-----------------------------------------------
void ROBOT::MoveRobot(void)
{
	//�J�����Z�b�g
	CAMERA* p_camera = GetCamera();
	p_camera->SetPos(m_pos);
	p_camera->SetDefPos(m_pos);

	switch (m_move_state)
	{
	case ROBOT_MOVE_STATE_FRONT:
	{
		//�O�ړ�
		float max_front_pos = 0;
		max_front_pos = GetMap(m_map_x, m_map_z).block_pos.z;

		m_pos = XMFLOAT3(m_pos.x, -SIDE_MOVE_HEIGHT * sinf(m_frame_count * (180 / MOVE_FRAME_NUM) * M_PI / 180), m_pos.z + MAP_BLOCK_HEIGHT / (float)MOVE_FRAME_NUM);

		if (m_pos.z >= max_front_pos)
		{
			m_pos.z = max_front_pos;
		}

		if (m_p_network_manager->GetType() == MIDDLE_PC)
		{//�T�[�o�[
			ServerPackData(ROBOT_OBJECT, ROBOT_POS_X, m_pos.x);
			ServerPackData(ROBOT_OBJECT, ROBOT_POS_Y, m_pos.y);
			ServerPackData(ROBOT_OBJECT, ROBOT_POS_Z, m_pos.z);
		}

		if (m_frame_count == MOVE_FRAME_NUM)
		{
			p_camera->ShakeCamera(0.5f, 10.0f);

			m_p_effect_manager->SetEffect(30, XMFLOAT3(m_pos.x + SCREEN_WIDTH * 0.5f, SCREEN_HEIGHT * 0.5f - 100.0f, m_pos.z), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(1000.0f, 1000.0f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_DIRT, LAYER_ENEMY);
			m_p_effect_manager->SetEffect(30, XMFLOAT3(m_pos.x + SCREEN_WIDTH * 0.5f - 500.0f, SCREEN_HEIGHT * 0.5f - 100.0f, m_pos.z), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(1000.0f, 1000.0f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_DIRT, LAYER_ENEMY);
			m_p_effect_manager->SetEffect(30, XMFLOAT3(m_pos.x + SCREEN_WIDTH * 0.5f - 1000.0f, SCREEN_HEIGHT * 0.5f - 100.0f, m_pos.z), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(1000.0f, 1000.0f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_DIRT, LAYER_ENEMY);
			m_p_effect_manager->SetEffect(30, XMFLOAT3(m_pos.x - SCREEN_WIDTH * 0.5f, SCREEN_HEIGHT * 0.5f - 100.0f, m_pos.z), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(1000.0f, 1000.0f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_DIRT, LAYER_ENEMY);
		}

		if (m_frame_count >= MOVE_FRAME_NUM)
		{//���Z�b�g
			m_move_state = ROBOT_MOVE_STATE_IDLE;
			m_state = ROBOT_STATE_IDLE;
			m_frame_count = 0;

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{//�T�[�o�[
				ServerPackData(ROBOT_OBJECT, MOVE_STATE, m_move_state);
				ServerPackData(ROBOT_OBJECT, STATE, m_state);
				ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
			}
		}

		break;
	}
	case ROBOT_MOVE_STATE_BACK:
	{
		//���ړ�

		float max_back_pos = 0;
		max_back_pos = GetMap(m_map_x, m_map_z - 2).block_pos.z;

		m_pos = XMFLOAT3(m_pos.x, -SIDE_MOVE_HEIGHT * sinf(m_frame_count * (180 / MOVE_FRAME_NUM) * M_PI / 180), m_pos.z - MAP_BLOCK_HEIGHT / (float)MOVE_FRAME_NUM);

		if (m_pos.z <= max_back_pos)
		{
			m_pos.z = max_back_pos;
		}

		if (m_p_network_manager->GetType() == MIDDLE_PC)
		{//�T�[�o�[
			ServerPackData(ROBOT_OBJECT, ROBOT_POS_X, m_pos.x);
			ServerPackData(ROBOT_OBJECT, ROBOT_POS_Y, m_pos.y);
			ServerPackData(ROBOT_OBJECT, ROBOT_POS_Z, m_pos.z);
		}

		if (m_frame_count == MOVE_FRAME_NUM)
		{
			p_camera->ShakeCamera(0.5f, 10.0f);

			m_p_effect_manager->SetEffect(30, XMFLOAT3(m_pos.x + SCREEN_WIDTH * 0.5f, SCREEN_HEIGHT * 0.5f - 100.0f, m_pos.z), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(1000.0f, 1000.0f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_DIRT, LAYER_ENEMY);
			m_p_effect_manager->SetEffect(30, XMFLOAT3(m_pos.x + SCREEN_WIDTH * 0.5f - 500.0f, SCREEN_HEIGHT * 0.5f - 100.0f, m_pos.z), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(1000.0f, 1000.0f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_DIRT, LAYER_ENEMY);
			m_p_effect_manager->SetEffect(30, XMFLOAT3(m_pos.x + SCREEN_WIDTH * 0.5f - 1000.0f, SCREEN_HEIGHT * 0.5f - 100.0f, m_pos.z), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(1000.0f, 1000.0f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_DIRT, LAYER_ENEMY);
			m_p_effect_manager->SetEffect(30, XMFLOAT3(m_pos.x - SCREEN_WIDTH * 0.5f, SCREEN_HEIGHT * 0.5f - 100.0f, m_pos.z), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(1000.0f, 1000.0f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_DIRT, LAYER_ENEMY);
		}

		if (m_frame_count >= MOVE_FRAME_NUM)
		{//���Z�b�g
			m_move_state = ROBOT_MOVE_STATE_IDLE;
			m_state = ROBOT_STATE_IDLE;
			m_frame_count = 0;

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{//�T�[�o�[
				ServerPackData(ROBOT_OBJECT, MOVE_STATE, m_move_state);
				ServerPackData(ROBOT_OBJECT, STATE, m_state);
				ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
			}
		}

		break;
	}
	case ROBOT_MOVE_STATE_LEFT:
		//���ړ�
		
		m_pos = XMFLOAT3(m_pos.x - SQUARES_SIZE / (float)MOVE_FRAME_NUM, -SIDE_MOVE_HEIGHT * sinf(m_frame_count * (180 / MOVE_FRAME_NUM) * M_PI / 180), m_pos.z);
		p_camera->TiltCamera(3);
		if (m_pos.x <= ROBOT_MIN_X)
		{
			m_pos.x = ROBOT_MIN_X;
		}

		if (m_p_network_manager->GetType() == MIDDLE_PC)
		{//�T�[�o�[
			ServerPackData(ROBOT_OBJECT, ROBOT_POS_X, m_pos.x);
			ServerPackData(ROBOT_OBJECT, ROBOT_POS_Y, m_pos.y);
			ServerPackData(ROBOT_OBJECT, ROBOT_POS_Z, m_pos.z);
		}

		if (m_frame_count == MOVE_FRAME_NUM)
		{
			p_camera->ShakeCamera(0.5f, 10.0f);

			m_p_effect_manager->SetEffect(30, XMFLOAT3(m_pos.x + SCREEN_WIDTH * 0.5f, SCREEN_HEIGHT * 0.5f - 100.0f, m_pos.z), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(1000.0f, 1000.0f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_DIRT, LAYER_ENEMY);
			m_p_effect_manager->SetEffect(30, XMFLOAT3(m_pos.x + SCREEN_WIDTH * 0.5f - 500.0f, SCREEN_HEIGHT * 0.5f - 100.0f, m_pos.z), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(1000.0f, 1000.0f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_DIRT, LAYER_ENEMY);
			m_p_effect_manager->SetEffect(30, XMFLOAT3(m_pos.x + SCREEN_WIDTH * 0.5f - 1000.0f, SCREEN_HEIGHT * 0.5f - 100.0f, m_pos.z), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(1000.0f, 1000.0f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_DIRT, LAYER_ENEMY);
			m_p_effect_manager->SetEffect(30, XMFLOAT3(m_pos.x - SCREEN_WIDTH * 0.5f, SCREEN_HEIGHT * 0.5f - 100.0f, m_pos.z), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(1000.0f, 1000.0f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_DIRT, LAYER_ENEMY);
		}

		if (m_frame_count >= MOVE_FRAME_NUM)
		{//���Z�b�g
			m_move_state = ROBOT_MOVE_STATE_IDLE;
			m_state = ROBOT_STATE_IDLE;
			m_frame_count = 0;

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{//�T�[�o�[
				ServerPackData(ROBOT_OBJECT, MOVE_STATE, m_move_state);
				ServerPackData(ROBOT_OBJECT, STATE, m_state);
				ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
			}
		}

		break;
	case ROBOT_MOVE_STATE_RIGHT:
		//�E�ړ�
		p_camera->TiltCamera(-3);
		m_pos = XMFLOAT3(m_pos.x + SQUARES_SIZE / (float)MOVE_FRAME_NUM, -SIDE_MOVE_HEIGHT * sinf(m_frame_count * (180 / MOVE_FRAME_NUM) * M_PI / 180), m_pos.z);
		if (m_pos.x >= ROBOT_MAX_X)
		{
			m_pos.x = ROBOT_MAX_X;
		}

		if (m_p_network_manager->GetType() == MIDDLE_PC)
		{//�T�[�o�[
			ServerPackData(ROBOT_OBJECT, ROBOT_POS_X, m_pos.x);
			ServerPackData(ROBOT_OBJECT, ROBOT_POS_Y, m_pos.y);
			ServerPackData(ROBOT_OBJECT, ROBOT_POS_Z, m_pos.z);
		}

		if (m_frame_count == MOVE_FRAME_NUM)
		{
			p_camera->ShakeCamera(0.5f, 10.0f);

			m_p_effect_manager->SetEffect(30, XMFLOAT3(m_pos.x + SCREEN_WIDTH * 0.5f, SCREEN_HEIGHT * 0.5f - 100.0f, m_pos.z), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(1000.0f, 1000.0f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_DIRT, LAYER_ENEMY);
			m_p_effect_manager->SetEffect(30, XMFLOAT3(m_pos.x + SCREEN_WIDTH * 0.5f - 500.0f, SCREEN_HEIGHT * 0.5f - 100.0f, m_pos.z), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(1000.0f, 1000.0f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_DIRT, LAYER_ENEMY);
			m_p_effect_manager->SetEffect(30, XMFLOAT3(m_pos.x + SCREEN_WIDTH * 0.5f - 1000.0f, SCREEN_HEIGHT * 0.5f - 100.0f, m_pos.z), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(1000.0f, 1000.0f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_DIRT, LAYER_ENEMY);
			m_p_effect_manager->SetEffect(30, XMFLOAT3(m_pos.x - SCREEN_WIDTH * 0.5f, SCREEN_HEIGHT * 0.5f - 100.0f, m_pos.z), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(1000.0f, 1000.0f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_DIRT, LAYER_ENEMY);
		}

		if (m_frame_count >= MOVE_FRAME_NUM)
		{//���Z�b�g
			m_move_state = ROBOT_MOVE_STATE_IDLE;
			m_state = ROBOT_STATE_IDLE;
			m_frame_count = 0;

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{//�T�[�o�[
				ServerPackData(ROBOT_OBJECT, MOVE_STATE, m_move_state);
				ServerPackData(ROBOT_OBJECT, STATE, m_state);
				ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
			}
		}

		break;

	case ROBOT_MOVE_STATE_FRONT_LEFT:
	case ROBOT_MOVE_STATE_FRONT_RIGHT:
	case ROBOT_MOVE_STATE_BACK_LEFT:
	case ROBOT_MOVE_STATE_BACK_RIGHT:
	case ROBOT_MOVE_STATE_LEFT_LEFT:
	case ROBOT_MOVE_STATE_LEFT_RIGHT:
	case ROBOT_MOVE_STATE_RIGHT_LEFT:
	case ROBOT_MOVE_STATE_RIGHT_RIGHT:
		if (m_frame_count > MOVE_GAP_NUM)
		{//���Z�b�g
			m_move_state = ROBOT_MOVE_STATE_IDLE;
			m_state = ROBOT_STATE_IDLE;
			m_frame_count = 0;

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{//�T�[�o�[
				ServerPackData(ROBOT_OBJECT, MOVE_STATE, m_move_state);
				ServerPackData(ROBOT_OBJECT, STATE, m_state);
				ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
			}
		}
		break;
		
	default:
		break;
	}

}

//-----------------------------------------------
// �h�䏈��
//-----------------------------------------------
void ROBOT::GuardRobot(void)
{
	switch (m_guard_state)
	{
	case ROBOT_GUARD_STATE_IDLE:

		if (m_left_guard_state != ROBOT_LEFT_GUARD_STATE_IDLE)
		{//�����K�[�h�{�^���������Ă�Ƃ�
			m_left_frame_count++;
			if (m_right_guard_state == ROBOT_RIGHT_GUARD_STATE_IDLE && m_left_frame_count > GUARD_GAP_FRAME)
			{//���������̗P�\�t���[���𒴂�����
				m_guard_state = ROBOT_GUARD_STATE_MISS;
				m_frame_count = 0;

				m_left_frame_count = 0;
				m_left_guard_state = ROBOT_LEFT_GUARD_STATE_MISS;

				if (m_p_network_manager->GetType() == MIDDLE_PC)
				{
					ServerPackData(ROBOT_OBJECT, GUARD_STATE, m_guard_state);
					ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
					ServerPackData(ROBOT_OBJECT, LEFT_FRAME_COUNT, m_left_frame_count);
					ServerPackData(ROBOT_OBJECT, LEFT_GUARD_STATE, m_left_guard_state);
				}
			}

			if (m_left_guard_state == ROBOT_LFET_GUARD_STATE_MIDDLE && m_left_frame_count > GUARD_MOTION_FRONT_FRAME)
			{//�K�[�h�̘r���o���I�������
				m_left_guard_state = ROBOT_LEFT_GUARD_STATE_SUCCESS;
				m_left_frame_count = 0;

				if (m_p_network_manager->GetType() == MIDDLE_PC)
				{
					ServerPackData(ROBOT_OBJECT, LEFT_GUARD_STATE, m_left_guard_state);
					ServerPackData(ROBOT_OBJECT, LEFT_FRAME_COUNT, m_left_frame_count);
				}
			}
		}

		if (m_right_guard_state != ROBOT_RIGHT_GUARD_STATE_IDLE)
		{
			m_right_frame_count++;
			if (m_left_guard_state == ROBOT_LEFT_GUARD_STATE_IDLE && m_right_frame_count > GUARD_GAP_FRAME)
			{//���������̗P�\�t���[���𒴂�����
				m_guard_state = ROBOT_GUARD_STATE_MISS;
				m_frame_count = 0;

				m_right_frame_count = 0;
				m_right_guard_state = ROBOT_RIGHT_GUARD_STATE_MISS;

				if (m_p_network_manager->GetType() == MIDDLE_PC)
				{
					ServerPackData(ROBOT_OBJECT, GUARD_STATE, m_guard_state);
					ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
					ServerPackData(ROBOT_OBJECT, RIGHT_FRAME_COUNT, m_right_frame_count);
					ServerPackData(ROBOT_OBJECT, RIGHT_GUARD_STATE, m_right_guard_state);
				}
			}

			if (m_right_guard_state == ROBOT_RIGHT_GUARD_STATE_MIDDLE && m_right_frame_count > GUARD_MOTION_FRONT_FRAME)
			{//�K�[�h�̘r���o���I�������
				m_right_guard_state = ROBOT_RIGHT_GUARD_STATE_SUCCESS;
				m_right_frame_count = 0;

				if (m_p_network_manager->GetType() == MIDDLE_PC)
				{
					ServerPackData(ROBOT_OBJECT, RIGHT_GUARD_STATE, m_right_guard_state);
					ServerPackData(ROBOT_OBJECT, RIGHT_FRAME_COUNT, m_right_frame_count);
				}
			}
		}

		if (m_left_guard_state == ROBOT_LEFT_GUARD_STATE_SUCCESS && m_right_guard_state == ROBOT_RIGHT_GUARD_STATE_SUCCESS)
		{//�ǂ���̘r���K�[�h���I������

			m_guard_state = ROBOT_GUARD_STATE_JUST_RECEPTION;
			m_frame_count = 0;

			m_robot_app_obj.ui_cue_index = CRI_ROBOTSE_ROBO_GUARD_STANCE;
			app_atomex_start(&m_robot_app_obj);

			Shake(0.5f, 20.0f);

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{
				ServerPackData(ROBOT_OBJECT, GUARD_STATE, m_guard_state);
				ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
			}
		}

		break;
	case ROBOT_GUARD_STATE_JUST_RECEPTION:
		if (m_frame_count == 1)
		{
			m_p_effect_manager->SetEffect(60, m_pos, XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(GUARD_EFFECT_SCALE, GUARD_EFFECT_SCALE), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_GUARD, LAYER_ENEMY);
		}


		if (m_frame_count > JUST_GUARD_FRAME)
		{
			m_guard_state = ROBOT_GUARD_STATE_NORMAL_RECEPTION;

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{//�T�[�o�[
				ServerPackData(ROBOT_OBJECT, GUARD_STATE, m_guard_state);
			}
		}
		break;
	case ROBOT_GUARD_STATE_NORMAL_RECEPTION:
		if (m_frame_count > GUARD_FRAME)
		{
			m_frame_count = 0;
			m_guard_state = ROBOT_GUARD_STATE_NORMAL_FINISH;

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{//�T�[�o�[
				ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
				ServerPackData(ROBOT_OBJECT, GUARD_STATE, m_guard_state);
			}
		}
		break;
	case ROBOT_GUARD_STATE_JUST_SUCCESS:
		if (m_frame_count == 1)
		{
			m_robot_app_obj.ui_cue_index = CRI_ROBOTSE_ROBO_GUARD_HIT;
			app_atomex_start(&m_robot_app_obj);

			Shake(GUARD_MOTION_SHAKE_STRENGTH, GUARD_SUCCESS_FRAME);
		}
		if (m_frame_count > GUARD_SUCCESS_FRAME)
		{//�K�[�h�������I�������
			m_frame_count = 0;
			m_guard_state = ROBOT_GUARD_STATE_SUCCESS_FINISH;

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{
				ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
				ServerPackData(ROBOT_OBJECT, GUARD_STATE, m_guard_state);
			}
		}
		break;
	case ROBOT_GUARD_STATE_NORMAL_SUCCESS:
		if (m_frame_count == 1)
		{
			Shake(GUARD_MOTION_SHAKE_STRENGTH, GUARD_SUCCESS_FRAME);
		}
		if (m_frame_count > GUARD_SUCCESS_FRAME)
		{//�K�[�h�������I�������
			m_frame_count = 0;
			m_guard_state = ROBOT_GUARD_STATE_SUCCESS_FINISH;

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{
				ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
				ServerPackData(ROBOT_OBJECT, GUARD_STATE, m_guard_state);
			}
		}
		break;
	case ROBOT_GUARD_STATE_SUCCESS_FINISH:
	case ROBOT_GUARD_STATE_NORMAL_FINISH:
		//�������Ă邽�ߗ����t���[���J�E���^�[�𑝉�
		m_left_frame_count++;
		m_right_frame_count++;
		
		if (m_frame_count > GUARD_MOTION_BACK_FRAME)
		{
			m_left_frame_count = 0;
			m_right_frame_count = 0;
			m_left_guard_state = ROBOT_LEFT_GUARD_STATE_IDLE;
			m_right_guard_state = ROBOT_RIGHT_GUARD_STATE_IDLE;
			m_frame_count = 0;
			m_guard_state = ROBOT_GUARD_STATE_IDLE;
			m_state = ROBOT_STATE_IDLE;

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{
				ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
				ServerPackData(ROBOT_OBJECT, LEFT_FRAME_COUNT, m_left_frame_count);
				ServerPackData(ROBOT_OBJECT, RIGHT_FRAME_COUNT, m_right_frame_count);
				ServerPackData(ROBOT_OBJECT, LEFT_GUARD_STATE, m_left_guard_state);
				ServerPackData(ROBOT_OBJECT, RIGHT_GUARD_STATE, m_right_guard_state);
				ServerPackData(ROBOT_OBJECT, GUARD_STATE, m_guard_state);
				ServerPackData(ROBOT_OBJECT, STATE, m_state);
			}
		}
		break;
	case ROBOT_GUARD_STATE_MISS:
		if (m_left_guard_state == ROBOT_LEFT_GUARD_STATE_MISS)
		{
			m_left_frame_count++;
			if (m_left_frame_count > GUARD_MOTION_BACK_FRAME)
			{
				m_left_frame_count = 0;
				m_frame_count = 0;
				m_guard_state = ROBOT_GUARD_STATE_IDLE;
				m_left_guard_state = ROBOT_LEFT_GUARD_STATE_IDLE;
				m_state = ROBOT_STATE_IDLE;

				ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
				ServerPackData(ROBOT_OBJECT, LEFT_FRAME_COUNT, m_left_frame_count);
				ServerPackData(ROBOT_OBJECT, GUARD_STATE, m_guard_state);
				ServerPackData(ROBOT_OBJECT, LEFT_GUARD_STATE, m_left_guard_state);
				ServerPackData(ROBOT_OBJECT, STATE, m_state);
			}
		}

		if (m_right_guard_state == ROBOT_RIGHT_GUARD_STATE_MISS)
		{
			m_right_frame_count++;
			if (m_right_frame_count > GUARD_MOTION_BACK_FRAME)
			{
				m_right_frame_count = 0;
				m_frame_count = 0;
				m_guard_state = ROBOT_GUARD_STATE_IDLE;
				m_right_guard_state = ROBOT_RIGHT_GUARD_STATE_IDLE;
				m_state = ROBOT_STATE_IDLE;

				ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
				ServerPackData(ROBOT_OBJECT, RIGHT_FRAME_COUNT, m_right_frame_count);
				ServerPackData(ROBOT_OBJECT, GUARD_STATE, m_guard_state);
				ServerPackData(ROBOT_OBJECT, RIGHT_GUARD_STATE, m_right_guard_state);
				ServerPackData(ROBOT_OBJECT, STATE, m_state);
			}
		}
		

		break;
	default:
		break;
	}
}

//-----------------------------------------------
// �ˌ�����
//-----------------------------------------------
void ROBOT::ShootRobot(void)
{
	switch (m_shoot_state)
	{
	case ROBOT_SHOOT_STATE_IDLE:
		if (m_left_shoot_state != ROBOT_LEFT_SHOOT_STATE_IDLE)
		{
			m_left_frame_count++;
			if (m_left_frame_count > SHOOT_GAP_FRAME && m_right_shoot_state == ROBOT_RIGHT_SHOOT_STATE_IDLE)
			{//���������t���[�����𒴂����玸�s�X�e�[�g��
				m_shoot_state = ROBOT_SHOOT_STATE_MISS;
				m_left_shoot_state = ROBOT_LEFT_SHOOT_STATE_MISS;

				m_frame_count = 0;
				m_left_frame_count = 0;

				if (m_p_network_manager->GetType() == MIDDLE_PC)
				{
					ServerPackData(ROBOT_OBJECT, SHOOT_STATE, m_shoot_state);
					ServerPackData(ROBOT_OBJECT, LEFT_SHOOT_STATE, m_left_shoot_state);
					ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
					ServerPackData(ROBOT_OBJECT, LEFT_FRAME_COUNT, m_left_frame_count);
				}
			}

			if (m_left_frame_count > SHOOT_MOTION_FRONT_FRAME && m_left_shoot_state == ROBOT_LEFT_SHOOT_STATE_MIDDLE)
			{
				m_left_shoot_state = ROBOT_LEFT_SHOOT_STATE_SUCCESS;
				m_left_frame_count = 0;

				if (m_p_network_manager->GetType() == MIDDLE_PC)
				{
					ServerPackData(ROBOT_OBJECT, LEFT_SHOOT_STATE, m_left_shoot_state);
					ServerPackData(ROBOT_OBJECT, LEFT_FRAME_COUNT, m_left_frame_count);
				}
			}

		}

		if (m_right_shoot_state != ROBOT_RIGHT_SHOOT_STATE_IDLE)
		{
			m_right_frame_count++;
			if (m_right_frame_count > SHOOT_GAP_FRAME && m_left_shoot_state == ROBOT_LEFT_SHOOT_STATE_IDLE)
			{//���������t���[�����𒴂����玸�s�X�e�[�g��
				m_shoot_state = ROBOT_SHOOT_STATE_MISS;
				m_right_shoot_state = ROBOT_RIGHT_SHOOT_STATE_MISS;

				m_frame_count = 0;
				m_right_frame_count = 0;

				if (m_p_network_manager->GetType() == MIDDLE_PC)
				{
					ServerPackData(ROBOT_OBJECT, SHOOT_STATE, m_shoot_state);
					ServerPackData(ROBOT_OBJECT, RIGHT_SHOOT_STATE, m_right_shoot_state);
					ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
					ServerPackData(ROBOT_OBJECT, RIGHT_FRAME_COUNT, m_right_frame_count);
				}
			}

			if (m_right_frame_count > SHOOT_MOTION_FRONT_FRAME && m_right_shoot_state == ROBOT_RIGHT_SHOOT_STATE_MIDDLE)
			{
				m_right_shoot_state = ROBOT_RIGHT_SHOOT_STATE_SUCCESS;
				m_right_frame_count = 0;

				if (m_p_network_manager->GetType() == MIDDLE_PC)
				{
					ServerPackData(ROBOT_OBJECT, RIGHT_SHOOT_STATE, m_right_shoot_state);
					ServerPackData(ROBOT_OBJECT, RIGHT_FRAME_COUNT, m_right_frame_count);
				}
			}
		}

		if (m_left_shoot_state == ROBOT_LEFT_SHOOT_STATE_SUCCESS && m_right_shoot_state == ROBOT_RIGHT_SHOOT_STATE_SUCCESS)
		{
			//�e����
			if (!m_missile_shoot && m_missile_stack > 0)
			{
				m_missile_cool_time = 0;
				m_missile_shoot = true;
				m_missile_stack--;

				if (m_p_network_manager->GetType() == MIDDLE_PC)
				{
					ServerPackData(ROBOT_OBJECT, MISSILE_COOL_TIME, m_missile_cool_time);
					ServerPackData(ROBOT_OBJECT, MISSILE_SHOOT, m_missile_shoot);
					ServerPackData(ROBOT_OBJECT, MISSILE_STACK, m_missile_stack);
				}

				//SE
				m_robot_app_obj.ui_cue_index = CRI_ROBOTSE_ROBO_MISILE_FIRE;
				app_atomex_start(&m_robot_app_obj);

				m_p_bullet_manager->SetPlayerBullet(XMFLOAT3(m_pos.x, m_pos.y + 300.0f, m_pos.z), XMFLOAT3(0.0f, 0.0f, BULLET_SPEED), XMFLOAT2(INITIAL_BULLET_SCALE, INITIAL_BULLET_SCALE));
			}
			else
			{//�s��
				m_p_effect_manager->SetEffect(30, XMFLOAT3(m_pos.x, m_pos.y + 100.0f, m_pos.z), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(800.0f, 800.0f), 0.0f, XMFLOAT4(0.3f, 0.3f, 0.3f, 1.0f), EFFECT_TYPE_DIRT, LAYER_ENEMY);
			}
			m_shoot_state = ROBOT_SHOOT_STATE_SUCCESS;
			m_frame_count = 0;

			Shake(SHOOT_SHAKE_STRENGTH, SHOOT_SHAKE_DULATION);

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{
				ServerPackData(ROBOT_OBJECT, SHOOT_STATE, m_shoot_state);
				ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
			}
		}

		break;
	case ROBOT_SHOOT_STATE_SUCCESS:
	{
		m_left_frame_count++;
		m_right_frame_count++;

		if (m_frame_count > SHOOT_MOTION_BACK_FRAME + SHOOT_MOTION_STAY_FRAME)
		{
			m_state = ROBOT_STATE_IDLE;
			m_shoot_state = ROBOT_SHOOT_STATE_IDLE;
			m_left_shoot_state = ROBOT_LEFT_SHOOT_STATE_IDLE;
			m_right_shoot_state = ROBOT_RIGHT_SHOOT_STATE_IDLE;
			
			m_frame_count = 0;
			m_left_frame_count = 0;
			m_right_frame_count = 0;

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{//�T�[�o�[
				ServerPackData(ROBOT_OBJECT, STATE, m_state);
				ServerPackData(ROBOT_OBJECT, SHOOT_STATE, m_shoot_state);
				ServerPackData(ROBOT_OBJECT, LEFT_SHOOT_STATE, m_left_shoot_state);
				ServerPackData(ROBOT_OBJECT, RIGHT_SHOOT_STATE, m_right_shoot_state);
				ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
				ServerPackData(ROBOT_OBJECT, LEFT_FRAME_COUNT, m_left_frame_count);
				ServerPackData(ROBOT_OBJECT, RIGHT_FRAME_COUNT, m_right_frame_count);
			}
		}
	}
		break;
	case ROBOT_SHOOT_STATE_MISS:
		if (m_left_shoot_state == ROBOT_LEFT_SHOOT_STATE_MISS)
		{
			m_left_frame_count++;
			if (m_left_frame_count > SHOOT_MOTION_FRONT_FRAME)
			{
				m_state = ROBOT_STATE_IDLE;
				m_shoot_state = ROBOT_SHOOT_STATE_IDLE;
				m_left_shoot_state = ROBOT_LEFT_SHOOT_STATE_IDLE;
				m_right_shoot_state = ROBOT_RIGHT_SHOOT_STATE_IDLE;
				m_frame_count = 0;
				m_left_frame_count = 0;
				m_right_frame_count = 0;

				if (m_p_network_manager->GetType() == MIDDLE_PC)
				{
					ServerPackData(ROBOT_OBJECT, STATE, m_state);
					ServerPackData(ROBOT_OBJECT, SHOOT_STATE, m_shoot_state);
					ServerPackData(ROBOT_OBJECT, LEFT_SHOOT_STATE, m_left_shoot_state);
					ServerPackData(ROBOT_OBJECT, RIGHT_SHOOT_STATE, m_right_shoot_state);
					ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
					ServerPackData(ROBOT_OBJECT, LEFT_FRAME_COUNT, m_left_frame_count);
					ServerPackData(ROBOT_OBJECT, RIGHT_FRAME_COUNT, m_right_frame_count);
				}
			}
		}

		if (m_right_shoot_state == ROBOT_RIGHT_SHOOT_STATE_MISS)
		{
			m_right_frame_count++;
			if (m_right_frame_count > SHOOT_MOTION_FRONT_FRAME)
			{
				m_state = ROBOT_STATE_IDLE;
				m_shoot_state = ROBOT_SHOOT_STATE_IDLE;
				m_left_shoot_state = ROBOT_LEFT_SHOOT_STATE_IDLE;
				m_right_shoot_state = ROBOT_RIGHT_SHOOT_STATE_IDLE;
				m_frame_count = 0;
				m_left_frame_count = 0;
				m_right_frame_count = 0;

				if (m_p_network_manager->GetType() == MIDDLE_PC)
				{
					ServerPackData(ROBOT_OBJECT, STATE, m_state);
					ServerPackData(ROBOT_OBJECT, SHOOT_STATE, m_shoot_state);
					ServerPackData(ROBOT_OBJECT, LEFT_SHOOT_STATE, m_left_shoot_state);
					ServerPackData(ROBOT_OBJECT, RIGHT_SHOOT_STATE, m_right_shoot_state);
					ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
					ServerPackData(ROBOT_OBJECT, LEFT_FRAME_COUNT, m_left_frame_count);
					ServerPackData(ROBOT_OBJECT, RIGHT_FRAME_COUNT, m_right_frame_count);
				}
			}
		}
		break;
	default:
		break;
	}
}

//-----------------------------------------------
// �K�E�Z����
//-----------------------------------------------
void ROBOT::SpecialRobot(void)
{
	if (m_special_state != ROBOT_SPECIAL_STATE_CHANCE_TEXT)
	{
		m_special_frame_count++;
	}
	if (m_special_frame_count >= SPECIAL_TIME_LIMIT && m_special_state != ROBOT_SPECIAL_STATE_MISS && m_special_state != ROBOT_SPECIAL_STATE_SUCCESS && m_special_state != ROBOT_SPECIAL_STATE_SUCCESS_IDLE)
	{
		m_special_state = ROBOT_SPECIAL_STATE_MISS;
		m_special_frame_count = 0;
		m_frame_count = 0;

		if (m_p_network_manager->GetType() == MIDDLE_PC)
		{//�T�[�o�[
			ServerPackData(ROBOT_OBJECT, SPECIAL_STATE, m_special_state);
			ServerPackData(ROBOT_OBJECT, SPECIAL_FRAME_COUNT, m_special_frame_count);
			ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
		}
	}

	switch (m_special_state)
	{
	case ROBOT_SPECIAL_STATE_CHANCE_TEXT:
		if (m_frame_count == 1)
		{
			m_cv_app_obj.ui_cue_index = CRI_CV_�K�E�Z�`�����X;
			app_atomex_start(&m_cv_app_obj);
		}
		if (m_frame_count > SPECIAL_CHANCE_TEXT_FRAME)
		{
			m_frame_count = 0;
			m_special_state = ROBOT_SPECIAL_STATE_1ST_IDLE;
			for (int i = 0; i < 4; i++)
			{
				m_left_arrow[i]->SetUse(true);
				m_right_arrow[i]->SetUse(true);
			}
			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{
				ServerPackData(ROBOT_OBJECT, SPECIAL_STATE, m_special_state);
				ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
				ServerPackData(ARROW_OBJECT, LEFT_0_ARROW_USE, true);
				ServerPackData(ARROW_OBJECT, LEFT_1_ARROW_USE, true);
				ServerPackData(ARROW_OBJECT, LEFT_2_ARROW_USE, true);
				ServerPackData(ARROW_OBJECT, LEFT_3_ARROW_USE, true);
				ServerPackData(ARROW_OBJECT, RIGHT_0_ARROW_USE, true);
				ServerPackData(ARROW_OBJECT, RIGHT_1_ARROW_USE, true);
				ServerPackData(ARROW_OBJECT, RIGHT_2_ARROW_USE, true);
				ServerPackData(ARROW_OBJECT, RIGHT_3_ARROW_USE, true);
			}
		}
		break;
	case ROBOT_SPECIAL_STATE_1ST_IDLE:
		for (int i = 0; i < 4; i++)
		{
			m_left_arrow[i]->SetUse(true);
			m_right_arrow[i]->SetUse(true);
		}
		break;
	case ROBOT_SPECIAL_STATE_1ST_LEFT:
		m_left_arrow[0]->SetUse(false);

		break;
	case ROBOT_SPECIAL_STATE_1ST_RIGHT:
		m_right_arrow[0]->SetUse(false);
		break;
	case ROBOT_SPECIAL_STATE_2ND_IDLE:
		m_left_arrow[0]->SetUse(false);
		m_right_arrow[0]->SetUse(false);
		break;
	case ROBOT_SPECIAL_STATE_2ND_LEFT:
		m_left_arrow[1]->SetUse(false);
		break;
	case ROBOT_SPECIAL_STATE_2ND_RIGHT:
		m_right_arrow[1]->SetUse(false);
		break;
	case ROBOT_SPECIAL_STATE_3RD_IDLE:
		m_left_arrow[1]->SetUse(false);
		m_right_arrow[1]->SetUse(false);
		break;
	case ROBOT_SPECIAL_STATE_3RD_LEFT:
		m_left_arrow[2]->SetUse(false);
		break;
	case ROBOT_SPECIAL_STATE_3RD_RIGHT:
		m_right_arrow[2]->SetUse(false);
		break;
	case ROBOT_SPECIAL_STATE_4TH_IDLE:
		m_left_arrow[2]->SetUse(false);
		m_right_arrow[2]->SetUse(false);
		break;
	case ROBOT_SPECIAL_STATE_4TH_LEFT:
		m_left_arrow[3]->SetUse(false);
		break;
	case ROBOT_SPECIAL_STATE_4TH_RIGHT:
		m_right_arrow[3]->SetUse(false);
		break;
	case ROBOT_SPECIAL_STATE_DECISION_IDLE:
		break;
	case ROBOT_SPECIAL_STATE_DECISION_LEFT:
		break;
	case ROBOT_SPECIAL_STATE_DECISION_RIGHT:
		break;
	case ROBOT_SPECIAL_STATE_SUCCESS_IDLE:
		//����Đ�
	{
		if (m_frame_count == 1)
		{
			m_robot_app_obj.ui_cue_index = CRI_ROBOTSE_ROBO_HISSATUWAZA_SUCCESS;
			app_atomex_start(&m_robot_app_obj);
		}

		SYSTEMTIME cur_time;
		GetSystemTime(&cur_time);
		if (m_special_active_second == (int)cur_time.wSecond)
		{
			VIDEO_PLAYER* p_video = GetVideoPlayer();
			if (p_video->m_state != PLAY)
			{
				if (m_p_network_manager->GetType() == MIDDLE_PC)
				{
					WCHAR wFileName[] = L"Asset\\HissatuCenter.avi";
					LoadVideoToWindow(wFileName, ONCE);

				}
				if (m_p_network_manager->GetType() == LEFT_PC)
				{
					WCHAR wFileName[] = L"Asset\\HissatuLeft.avi";
					LoadVideoToWindow(wFileName, ONCE);
				}
				if (m_p_network_manager->GetType() == RIGHT_PC)
				{
					WCHAR wFileName[] = L"Asset\\HissatuRight.avi";
					LoadVideoToWindow(wFileName, ONCE);
				}

				m_special_state = ROBOT_SPECIAL_STATE_SUCCESS;
				m_frame_count = 0;
			}
		}
	}
		break;
	case ROBOT_SPECIAL_STATE_SUCCESS:
		//�r�ƃr�[��
	{
		VIDEO_PLAYER* p_video = GetVideoPlayer();
		if (p_video->m_state != PLAY)
		{
			if (m_frame_count == 1)
			{
				//SE
				m_robot_app_obj.ui_cue_index = CRI_ROBOTSE_ROBO_HISSATUBEAM_SHOOT;
				app_atomex_start(&m_robot_app_obj);

				m_p_effect_manager->SetEffect(10, XMFLOAT3(m_pos.x, 300.0f, 0.0f), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(1000.0f, 1000.0f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_SPECIAL_SHOOT, LAYER_ENEMY);
			}

			if (m_frame_count == 10)
			{
				CAMERA* p_camera = GetCamera();
				
				Shake(0.5f, 290.0f);

				m_p_effect_manager->SetEffect(290, XMFLOAT3(m_pos.x, 300.0f, 0.0f), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(1500.0f, 1500.0f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_SPECIAL_HIT, LAYER_ENEMY);
				m_p_effect_manager->SetEffect(290, XMFLOAT3(m_pos.x, 300.0f, 0.0f), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(1000.0f, 1000.0f), 0.0f, XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_SPECIAL_SHOOT, LAYER_ENEMY);
			}

			if (m_frame_count >= 290.0f)
			{
				m_state = ROBOT_STATE_IDLE;
				m_frame_count = 0;
				m_special_state = ROBOT_SPECIAL_STATE_1ST_IDLE;
				m_special_frame_count = 0;
				m_special_gauge = 0;

				if (m_p_network_manager->GetType() == MIDDLE_PC)
				{//�T�[�o�[
					ServerPackData(ROBOT_OBJECT, STATE, m_state);
					ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
					ServerPackData(ROBOT_OBJECT, SPECIAL_STATE, m_special_state);
					ServerPackData(ROBOT_OBJECT, SPECIAL_FRAME_COUNT, m_special_frame_count);
					ServerPackData(ROBOT_OBJECT, SPECIAL_GAUGE, m_special_gauge);
				}
			}
		}
	}
		break;
	case ROBOT_SPECIAL_STATE_MISS:
		if (m_frame_count == 1)
		{
			m_robot_app_obj.ui_cue_index = CRI_ROBOTSE_ROBO_HISSATUWAZA_FAILED;
			app_atomex_start(&m_robot_app_obj);
		}

		if (m_frame_count >= SPECIAL_MISS_FRAME)
		{
			m_state = ROBOT_STATE_IDLE;
			m_frame_count = 0;
			m_special_state = ROBOT_SPECIAL_STATE_1ST_IDLE;
			m_special_frame_count = 0;
			m_special_gauge = 0;

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{//�T�[�o�[
				ServerPackData(ROBOT_OBJECT, STATE, m_state);
				ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
				ServerPackData(ROBOT_OBJECT, SPECIAL_STATE, m_special_state);
				ServerPackData(ROBOT_OBJECT, SPECIAL_FRAME_COUNT, m_special_frame_count);
				ServerPackData(ROBOT_OBJECT, SPECIAL_GAUGE, m_special_gauge);
			}
		}
		break;
	default:
		break;
	}
}

//-----------------------------------------------
// �~�b�V�������s
//-----------------------------------------------
void ROBOT::MissionFailed(void)
{
	if (m_frame_count == 1)
	{
		CAMERA* p_camera = GetCamera();
		p_camera->ShakeCamera(1.0f, MISSION_FAILED_FRAME);
	}

	if (m_frame_count % EXPLOSION_INTERVAL_FRAME == 0)
	{
		if (m_p_network_manager->GetType() == MIDDLE_PC)
		{
			m_explosion_pos_x = rand() % (SCREEN_WIDTH * 3) - SCREEN_WIDTH * 1.5f;
			m_explosion_pos_y = rand() % (SCREEN_HEIGHT / 2) - SCREEN_HEIGHT * 0.5f;

			ServerPackData(ROBOT_OBJECT, EXPLOSION_POS_X, m_explosion_pos_x);
			ServerPackData(ROBOT_OBJECT, EXPLOSION_POS_Y, m_explosion_pos_y);
		}

		m_robot_app_obj.ui_cue_index = CRI_ROBOTSE_ROBO_MISILE_FIRE;
		app_atomex_start(&m_robot_app_obj);

		m_p_effect_manager->SetEffect(EXPLOSION_EFFECT_FRAME, XMFLOAT3(m_explosion_pos_x, m_explosion_pos_y, 0.0f), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(EXPLOSION_EFFECT_SCALE, EXPLOSION_EFFECT_SCALE), 0.0f,
			XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f), EFFECT_TYPE_EXPLOSION, LAYER_UI);
	}
	if (m_frame_count > MISSION_FAILED_FRAME)
	{
		//�J�������Z�b�g
		CAMERA* p = GetCamera();
		p->InitCamera();
		//�V�[���J��
		m_p_fade->SetFade(FADE_TYPE_NORMAL_SLOW, NEXT_SCENE_RESULT);
	}
}

int ROBOT::GetMapZ()
{
	return m_map_z;
}

//���{�̐N���x���擾
float ROBOT::GetRoboInvasionRate()
{
	//���{�̐i�s�x�擾

	//���{�N���x(�ʒu)�擾
	float robo_invasion_pos_z = GetMap(0, m_map_z).block_pos.z;

	//�S�[���ʒu�擾
	float goal_pos_z = GetMap(0, PLAYER_GOAL_POS_Z).block_pos.z;

	//���{�N���������o��
	float robo_invasion_rate = robo_invasion_pos_z / goal_pos_z;

	return robo_invasion_rate;
}

//-----------------------------------------------
//��_���[�W����
//-----------------------------------------------
void ROBOT::TakeDamage(int damage)
{
	int old_hp = m_hp;
	m_hp -= damage;

	CAMERA* p_camera = GetCamera();
	p_camera->ShakeCamera(1.0f, 20.0f);

	//SE
	m_robot_app_obj.ui_cue_index = CRI_ROBOTSE_ROBO_DAMAGE;
	app_atomex_start(&m_robot_app_obj);

	//�G�t�F�N�g����
	m_p_effect_manager->SetEffect(15, XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT2(SCREEN_WIDTH * 3.0f, SCREEN_HEIGHT), 0.0f, XMFLOAT4(1.0f, 0.0f, 0.0f, 0.5f), EFFECT_TYPE_DAMAGE, LAYER_UI);

	if (m_p_network_manager->GetType() == MIDDLE_PC)
	{//�T�[�o�[
		ServerPackData(ROBOT_OBJECT, ROBOT_HP, m_hp);
	}
}

//-----------------------------------------------
// �K�E�Z�Q�[�W�`���[�W
//-----------------------------------------------
void ROBOT::ChargeSpecialGauge(void)
{
	if (m_frame_count <= 30)
	{
		int old_special_gauge = m_special_gauge;
		m_special_gauge += ADD_SPECIAL_GAGE;

		if (old_special_gauge < MAX_SPECIAL_GAGE && m_special_gauge >= MAX_SPECIAL_GAGE)
		{
			m_robot_app_obj.ui_cue_index = CRI_ROBOTSE_ROBO_HISSATUWAZA_FULLCHARGE;
			app_atomex_start(&m_robot_app_obj);
		}

		if (m_special_gauge >= MAX_SPECIAL_GAGE)
		{//SE
			m_special_gauge = MAX_SPECIAL_GAGE;
		}

		if (m_p_network_manager->GetType() == MIDDLE_PC)
		{//�T�[�o�[
			ServerPackData(ROBOT_OBJECT, SPECIAL_GAUGE, m_special_gauge);
		}
	}
}

//-----------------------------------------------
// �}���i�G�����M�K�C�j
//-----------------------------------------------
void ROBOT::InterceptEringi(void)
{
	//���E���ꂼ�ꂩ��o��
	if (m_intercept_left_missile)
	{
		m_left_frame_count++;
		if (m_left_frame_count >= INTERCEPT_MISSILE_COOL_TIME)
		{
			m_left_frame_count = 0;
			m_intercept_left_missile = false;
			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{
				ServerPackData(ROBOT_OBJECT, LEFT_FRAME_COUNT, m_left_frame_count);
				ServerPackData(ROBOT_OBJECT, INTERCEPT_LEFT_MISSILE, m_intercept_left_missile);
			}

			if (!m_can_shake)
			{
				Shake(INTERCEPT_MISSILE_SHAKE_STRENGTH, INTERCEPT_MISSILE_COOL_TIME);
			}

			//SE
			m_robot_app_obj.ui_cue_index = CRI_ROBOTSE_ROBO_MISILE_FIRE;
			app_atomex_start(&m_robot_app_obj);

			m_p_bullet_manager->SetPlayerBullet(XMFLOAT3(-INTERCEPT_MISSILE_POS_X, 0.0f, m_pos.z),
				XMFLOAT3(INTERCEPT_MISSILE_POS_X / INTERCEPT_MISSILE_FRAME, 0.0f, MAP_BLOCK_HEIGHT * 3.0f / INTERCEPT_MISSILE_FRAME), XMFLOAT2(100.0f, 100.0f));
		}
		
	}

	if (m_intercept_right_missile)
	{
		m_right_frame_count++;
		if (m_right_frame_count >= INTERCEPT_MISSILE_COOL_TIME)
		{
			m_right_frame_count = 0;
			m_intercept_right_missile = false;

			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{
				ServerPackData(ROBOT_OBJECT, RIGHT_FRAME_COUNT, m_right_frame_count);
				ServerPackData(ROBOT_OBJECT, INTERCEPT_RIGHT_MISSILE, m_intercept_right_missile);
			}

			if (!m_can_shake)
			{
				Shake(INTERCEPT_MISSILE_SHAKE_STRENGTH, INTERCEPT_MISSILE_COOL_TIME);
			}

			//SE
			m_robot_app_obj.ui_cue_index = CRI_ROBOTSE_ROBO_MISILE_FIRE;
			app_atomex_start(&m_robot_app_obj);

			m_p_bullet_manager->SetPlayerBullet(XMFLOAT3(INTERCEPT_MISSILE_POS_X, 0.0f, m_pos.z),
				XMFLOAT3(-INTERCEPT_MISSILE_POS_X / INTERCEPT_MISSILE_FRAME, 0.0f, MAP_BLOCK_HEIGHT * 3.0f / INTERCEPT_MISSILE_FRAME), XMFLOAT2(100.0f, 100.0f));
		}
	}

}

//-----------------------------------------------
// �}���i�m�A�h���S���u���X�j
//-----------------------------------------------
void ROBOT::InterceptNoadoragonBreath(void)
{
	//�p���`�̂�
	if (m_intercept_left_punch)
	{//���p���`
		m_left_frame_count++;
		if (m_left_frame_count >= INTERCEPT_PUNCH_RESERVE_FRAME + INTERCEPT_PUNCH_FRONT_FRAME && m_left_frame_count <= INTERCEPT_PUNCH_RESERVE_FRAME + INTERCEPT_PUNCH_FRONT_FRAME + IS_ATTACKING_TIME)
		{
			m_robot_app_obj.ui_cue_index = CRI_ROBOTSE_ROBO_PUNCH;
			app_atomex_start(&m_robot_app_obj);

			CAMERA* p_camera = GetCamera();
			p_camera->ShakeCamera(1.0f, 30);
			m_is_attacking = true;
			//�T�[�o�[�Ȃ�ݒ�
			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{
				ServerPackData(ROBOT_OBJECT, IS_ATTAKING, m_is_attacking);
			}
		}

		if (m_left_frame_count >= INTERCEPT_PUNCH_RESERVE_FRAME + INTERCEPT_PUNCH_FRONT_FRAME + INTERCEPT_PUNCH_SHAKE_FRAME + INTERCEPT_PUNCH_BACK_FRAME)
		{
			m_left_frame_count = 0;
			m_intercept_left_punch = false;

			//�T�[�o�[�Ȃ�ݒ�
			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{
				ServerPackData(ROBOT_OBJECT, LEFT_FRAME_COUNT, m_left_frame_count);
				ServerPackData(ROBOT_OBJECT, INTERCEPT_LEFT_PUNCH, m_intercept_left_punch);
			}
		}
	}

	
	if (m_intercept_right_punch)
	{//�E�p���`
		m_right_frame_count++;
		if (m_right_frame_count >= INTERCEPT_PUNCH_RESERVE_FRAME + INTERCEPT_PUNCH_FRONT_FRAME && m_right_frame_count <= INTERCEPT_PUNCH_RESERVE_FRAME + INTERCEPT_PUNCH_FRONT_FRAME + IS_ATTACKING_TIME)
		{
			m_robot_app_obj.ui_cue_index = CRI_ROBOTSE_ROBO_PUNCH;
			app_atomex_start(&m_robot_app_obj);

			CAMERA* p_camera = GetCamera();
			p_camera->ShakeCamera(1.0f, 30);
			m_is_attacking = true;
			//�T�[�o�[�Ȃ�ݒ�
			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{
				ServerPackData(ROBOT_OBJECT, IS_ATTAKING, m_is_attacking);
			}
		}

		if (m_right_frame_count >= INTERCEPT_PUNCH_RESERVE_FRAME + INTERCEPT_PUNCH_FRONT_FRAME + INTERCEPT_PUNCH_SHAKE_FRAME + INTERCEPT_PUNCH_BACK_FRAME)
		{
			m_right_frame_count = 0;
			m_intercept_right_punch = false;

			//�T�[�o�[�Ȃ�ݒ�
			if (m_p_network_manager->GetType() == MIDDLE_PC)
			{
				ServerPackData(ROBOT_OBJECT, RIGHT_FRAME_COUNT, m_right_frame_count);
				ServerPackData(ROBOT_OBJECT, INTERCEPT_RIGHT_PUNCH, m_intercept_left_punch);
			}
		}
	}

}

//-----------------------------------------------
// ���
//-----------------------------------------------
void ROBOT::MapLowerBack(void)
{
	float max_back_pos = 0;
	max_back_pos = GetMap(m_map_x, m_map_z - 2).block_pos.z;

	m_pos = XMFLOAT3(m_pos.x, -SIDE_MOVE_HEIGHT * sinf(m_frame_count * (180 / LOWER_BACK_MOTION_FRAME) * M_PI / 180), m_pos.z - MAP_BLOCK_HEIGHT / (float)MOVE_FRAME_NUM);

	if (m_pos.z <= max_back_pos)
	{
		m_pos.z = max_back_pos;
	}

	if (m_p_network_manager->GetType() == MIDDLE_PC)
	{//�T�[�o�[
		ServerPackData(ROBOT_OBJECT, ROBOT_POS_X, m_pos.x);
		ServerPackData(ROBOT_OBJECT, ROBOT_POS_Y, m_pos.y);
		ServerPackData(ROBOT_OBJECT, ROBOT_POS_Z, m_pos.z);
	}

	if (m_frame_count >= LOWER_BACK_MOTION_FRAME)
	{//��ނ��I�������
		m_state = ROBOT_STATE_IDLE;
		m_frame_count = 0;

		if (m_p_network_manager->GetType() == MIDDLE_PC)
		{
			ServerPackData(ROBOT_OBJECT, STATE, m_state);
			ServerPackData(ROBOT_OBJECT, FRAME_COUNT, m_frame_count);
		}
	}

}

//-----------------------------------------------
// �h��Ăяo��
//-----------------------------------------------
void ROBOT::Shake(float strength, float duration)
{
	m_shake_duration = duration;

	m_shake_cur_time = m_shake_duration;

	//�������O���b�v
	if (strength > 1.0f)
	{
		strength = 1.0f;
	}
	else if (strength < 0.0f)
	{
		strength = 0.0f;
	}

	m_shake_strength = strength;

	m_can_shake = true;

	m_init_pos = m_pos;

	if (m_p_network_manager->GetType() == MIDDLE_PC)
	{
		ServerPackData(ROBOT_OBJECT, ROBOT_INIT_POS_X, m_init_pos.x);
		ServerPackData(ROBOT_OBJECT, ROBOT_INIT_POS_Y, m_init_pos.y);
		ServerPackData(ROBOT_OBJECT, ROBOT_INIT_POS_Z, m_init_pos.z);
		ServerPackData(ROBOT_OBJECT, ROBOT_SHAKE_DURATION, m_shake_duration);
		ServerPackData(ROBOT_OBJECT, ROBOT_SHAKE_CUR_TIME, m_shake_cur_time);
		ServerPackData(ROBOT_OBJECT, ROBOT_SHAKE_STRENGTH, m_shake_strength);
		ServerPackData(ROBOT_OBJECT, ROBOT_CAN_SHAKE, m_can_shake);
	}
}

//-----------------------------------------------
// �K�[�h�̎��̗h��Ăяo��
//-----------------------------------------------
void ROBOT::ShakeHand(void)
{
	Shake(0.5f, GUARD_SUCCESS_FRAME);
}

//-----------------------------------------------
// �h�ꏈ��
//-----------------------------------------------
XMFLOAT3 ROBOT::ShakeProcess(void)
{
	
	float offset_x = 0.0f;
	float offset_y = 0.0f;
	float time_rate = LinearRate(m_shake_cur_time, m_shake_duration);

	//�����_���Ɉʒu��ݒ�
	if (m_rand_time > 1)
	{
		offset_x = 200 * (m_shake_strength * time_rate) * RandomMinusOneToOne();
		offset_y = 200 * (m_shake_strength * time_rate) * RandomMinusOneToOne();
		m_rand_time = 0.0f;
	}

	m_rand_time++;

	//������
	XMFLOAT3 pos = m_pos;
	XMFLOAT2 diff = XMFLOAT2(((offset_x + m_init_pos.x) - pos.x) * 0.2f, ((offset_y + m_init_pos.y) - pos.y) * 0.2f);
	pos.x += diff.x;
	pos.y += diff.y;

	if (m_p_network_manager->GetType() == MIDDLE_PC)
	{
		ServerPackData(ROBOT_OBJECT, ROBOT_POS_X, m_pos.x);
		ServerPackData(ROBOT_OBJECT, ROBOT_POS_Y, m_pos.y);
		ServerPackData(ROBOT_OBJECT, ROBOT_POS_Z, m_pos.z);
		ServerPackData(ROBOT_OBJECT, ROBOT_INIT_POS_X, m_init_pos.x);
		ServerPackData(ROBOT_OBJECT, ROBOT_INIT_POS_Y, m_init_pos.y);
		ServerPackData(ROBOT_OBJECT, ROBOT_INIT_POS_Z, m_init_pos.z);
		ServerPackData(ROBOT_OBJECT, ROBOT_RAND_TIME, m_rand_time);
	}

	return pos;
}

//-----------------------------------------------
// �`���[�g���A���p�̕K�E�Z�Ăяo��
//-----------------------------------------------
void ROBOT::TutorialSpecial(void)
{
	m_state = ROBOT_STATE_SPECIAL;
	m_special_state = ROBOT_SPECIAL_STATE_SUCCESS;
	m_frame_count = 0;

	if (m_p_network_manager->GetType() == MIDDLE_PC)
	{
		ServerPackData(ROBOT_OBJECT, STATE, m_state);
		ServerPackData(ROBOT_OBJECT, SPECIAL_STATE, m_special_state);
		ServerPackData(ROBOT_OBJECT, SPECIAL_FRAME_COUNT, m_special_frame_count);
	}
}

//-----------------------------------------------
// ���X�V
//-----------------------------------------------
void SPECIAL_ARROW::Update(void)
{
	if (m_use)
	{
		if (m_can_shake)
		{
			m_shake_cur_time--;
			if (m_shake_cur_time > 0)
			{
			}
			else
			{
				m_shake_cur_time = 0;
				m_can_shake = false;

				if (m_p_network_manager->GetType() == MIDDLE_PC)
				{
					if (m_left)
					{
						switch (m_index)
						{
						case 0:
							ServerPackData(ARROW_OBJECT, LEFT_0_ARROW_SHAKE_CUR_TIME, m_shake_cur_time);
							ServerPackData(ARROW_OBJECT, LEFT_0_ARROW_CAN_SHAKE, m_can_shake);
							break;
						case 1:
							ServerPackData(ARROW_OBJECT, LEFT_1_ARROW_SHAKE_CUR_TIME, m_shake_cur_time);
							ServerPackData(ARROW_OBJECT, LEFT_1_ARROW_CAN_SHAKE, m_can_shake);
							break;
						case 2:
							ServerPackData(ARROW_OBJECT, LEFT_2_ARROW_SHAKE_CUR_TIME, m_shake_cur_time);
							ServerPackData(ARROW_OBJECT, LEFT_2_ARROW_CAN_SHAKE, m_can_shake);
							break;
						case 3:
							ServerPackData(ARROW_OBJECT, LEFT_3_ARROW_SHAKE_CUR_TIME, m_shake_cur_time);
							ServerPackData(ARROW_OBJECT, LEFT_3_ARROW_CAN_SHAKE, m_can_shake);
							break;
						default:
							break;
						}
					}
					else
					{
						switch (m_index)
						{
						case 0:
							ServerPackData(ARROW_OBJECT, RIGHT_0_ARROW_SHAKE_CUR_TIME, m_shake_cur_time);
							ServerPackData(ARROW_OBJECT, RIGHT_0_ARROW_CAN_SHAKE, m_can_shake);
							break;
						case 1:
							ServerPackData(ARROW_OBJECT, RIGHT_1_ARROW_SHAKE_CUR_TIME, m_shake_cur_time);
							ServerPackData(ARROW_OBJECT, RIGHT_1_ARROW_CAN_SHAKE, m_can_shake);
							break;
						case 2:
							ServerPackData(ARROW_OBJECT, RIGHT_2_ARROW_SHAKE_CUR_TIME, m_shake_cur_time);
							ServerPackData(ARROW_OBJECT, RIGHT_2_ARROW_CAN_SHAKE, m_can_shake);
							break;
						case 3:
							ServerPackData(ARROW_OBJECT, RIGHT_3_ARROW_SHAKE_CUR_TIME, m_shake_cur_time);
							ServerPackData(ARROW_OBJECT, RIGHT_3_ARROW_CAN_SHAKE, m_can_shake);
							break;
						default:
							break;
						}
					}
				}
			}
		}
	}
}

//-----------------------------------------------
// ���`��
//-----------------------------------------------
void SPECIAL_ARROW::Draw(void)
{
	if (m_use)
	{
		XMFLOAT2 pos = m_pos;
		if (m_can_shake)
		{
			pos = SPECIAL_ARROW::ShakeProcess();
		}

		GetDeviceContext()->PSSetShaderResources(0, 1, &m_texture);
		DrawSpriteUI(m_p_network_manager->GetType(), pos, m_rot, m_sca, m_color, 1, 1, 0);
	}
}

//-----------------------------------------------
// �h��Ăяo��
//-----------------------------------------------
void SPECIAL_ARROW::Shake(float strength, float duration)
{
	m_shake_duration = duration;

	m_shake_cur_time = m_shake_duration;

	//�������O���b�v
	if (strength > 1.0f)
	{
		strength = 1.0f;
	}
	else if (strength < 0.0f)
	{
		strength = 0.0f;
	}

	m_shake_strength = strength;

	m_can_shake = true;

	m_init_pos = m_pos;


	if (m_p_network_manager->GetType() == MIDDLE_PC)
	{
		if (m_left)
		{
			switch (m_index)
			{
			case 0:
				ServerPackData(ARROW_OBJECT, LEFT_0_ARROW_INIT_POS_X, m_init_pos.x);
				ServerPackData(ARROW_OBJECT, LEFT_0_ARROW_INIT_POS_Y, m_init_pos.y);
				ServerPackData(ARROW_OBJECT, LEFT_0_ARROW_SHAKE_DURATION, m_shake_duration);
				ServerPackData(ARROW_OBJECT, LEFT_0_ARROW_SHAKE_CUR_TIME, m_shake_cur_time);
				ServerPackData(ARROW_OBJECT, LEFT_0_ARROW_SHAKE_STRENGTH, m_shake_strength);
				ServerPackData(ARROW_OBJECT, LEFT_0_ARROW_CAN_SHAKE, m_can_shake);
				break;
			case 1:
				ServerPackData(ARROW_OBJECT, LEFT_1_ARROW_INIT_POS_X, m_init_pos.x);
				ServerPackData(ARROW_OBJECT, LEFT_1_ARROW_INIT_POS_Y, m_init_pos.y);
				ServerPackData(ARROW_OBJECT, LEFT_1_ARROW_SHAKE_DURATION, m_shake_duration);
				ServerPackData(ARROW_OBJECT, LEFT_1_ARROW_SHAKE_CUR_TIME, m_shake_cur_time);
				ServerPackData(ARROW_OBJECT, LEFT_1_ARROW_SHAKE_STRENGTH, m_shake_strength);
				ServerPackData(ARROW_OBJECT, LEFT_1_ARROW_CAN_SHAKE, m_can_shake);
				break;
			case 2:
				ServerPackData(ARROW_OBJECT, LEFT_2_ARROW_INIT_POS_X, m_init_pos.x);
				ServerPackData(ARROW_OBJECT, LEFT_2_ARROW_INIT_POS_Y, m_init_pos.y);
				ServerPackData(ARROW_OBJECT, LEFT_2_ARROW_SHAKE_DURATION, m_shake_duration);
				ServerPackData(ARROW_OBJECT, LEFT_2_ARROW_SHAKE_CUR_TIME, m_shake_cur_time);
				ServerPackData(ARROW_OBJECT, LEFT_2_ARROW_SHAKE_STRENGTH, m_shake_strength);
				ServerPackData(ARROW_OBJECT, LEFT_2_ARROW_CAN_SHAKE, m_can_shake);
				break;
			case 3:
				ServerPackData(ARROW_OBJECT, LEFT_3_ARROW_INIT_POS_X, m_init_pos.x);
				ServerPackData(ARROW_OBJECT, LEFT_3_ARROW_INIT_POS_Y, m_init_pos.y);
				ServerPackData(ARROW_OBJECT, LEFT_3_ARROW_SHAKE_DURATION, m_shake_duration);
				ServerPackData(ARROW_OBJECT, LEFT_3_ARROW_SHAKE_CUR_TIME, m_shake_cur_time);
				ServerPackData(ARROW_OBJECT, LEFT_3_ARROW_SHAKE_STRENGTH, m_shake_strength);
				ServerPackData(ARROW_OBJECT, LEFT_3_ARROW_CAN_SHAKE, m_can_shake);
				break;
			default:
				break;
			}
		}
		else
		{
			switch (m_index)
			{
			case 0:
				ServerPackData(ARROW_OBJECT, RIGHT_0_ARROW_INIT_POS_X, m_init_pos.x);
				ServerPackData(ARROW_OBJECT, RIGHT_0_ARROW_INIT_POS_Y, m_init_pos.y);
				ServerPackData(ARROW_OBJECT, RIGHT_0_ARROW_SHAKE_DURATION, m_shake_duration);
				ServerPackData(ARROW_OBJECT, RIGHT_0_ARROW_SHAKE_CUR_TIME, m_shake_cur_time);
				ServerPackData(ARROW_OBJECT, RIGHT_0_ARROW_SHAKE_STRENGTH, m_shake_strength);
				ServerPackData(ARROW_OBJECT, RIGHT_0_ARROW_CAN_SHAKE, m_can_shake);
				break;
			case 1:
				ServerPackData(ARROW_OBJECT, RIGHT_1_ARROW_INIT_POS_X, m_init_pos.x);
				ServerPackData(ARROW_OBJECT, RIGHT_1_ARROW_INIT_POS_Y, m_init_pos.y);
				ServerPackData(ARROW_OBJECT, RIGHT_1_ARROW_SHAKE_DURATION, m_shake_duration);
				ServerPackData(ARROW_OBJECT, RIGHT_1_ARROW_SHAKE_CUR_TIME, m_shake_cur_time);
				ServerPackData(ARROW_OBJECT, RIGHT_1_ARROW_SHAKE_STRENGTH, m_shake_strength);
				ServerPackData(ARROW_OBJECT, RIGHT_1_ARROW_CAN_SHAKE, m_can_shake);
				break;
			case 2:
				ServerPackData(ARROW_OBJECT, RIGHT_2_ARROW_INIT_POS_X, m_init_pos.x);
				ServerPackData(ARROW_OBJECT, RIGHT_2_ARROW_INIT_POS_Y, m_init_pos.y);
				ServerPackData(ARROW_OBJECT, RIGHT_2_ARROW_SHAKE_DURATION, m_shake_duration);
				ServerPackData(ARROW_OBJECT, RIGHT_2_ARROW_SHAKE_CUR_TIME, m_shake_cur_time);
				ServerPackData(ARROW_OBJECT, RIGHT_2_ARROW_SHAKE_STRENGTH, m_shake_strength);
				ServerPackData(ARROW_OBJECT, RIGHT_2_ARROW_CAN_SHAKE, m_can_shake);
				break;
			case 3:
				ServerPackData(ARROW_OBJECT, RIGHT_3_ARROW_INIT_POS_X, m_init_pos.x);
				ServerPackData(ARROW_OBJECT, RIGHT_3_ARROW_INIT_POS_Y, m_init_pos.y);
				ServerPackData(ARROW_OBJECT, RIGHT_3_ARROW_SHAKE_DURATION, m_shake_duration);
				ServerPackData(ARROW_OBJECT, RIGHT_3_ARROW_SHAKE_CUR_TIME, m_shake_cur_time);
				ServerPackData(ARROW_OBJECT, RIGHT_3_ARROW_SHAKE_STRENGTH, m_shake_strength);
				ServerPackData(ARROW_OBJECT, RIGHT_3_ARROW_CAN_SHAKE, m_can_shake);
				break;
			default:
				break;
			}
		}
	}
}

//-----------------------------------------------
// �h�ꏈ��
//-----------------------------------------------
XMFLOAT2 SPECIAL_ARROW::ShakeProcess(void)
{
	m_rand_time++;
	float offset_x = 0.0f;
	float offset_y = 0.0f;
	float time_rate = LinearRate(m_shake_cur_time, m_shake_duration);

	//�����_���Ɉʒu��ݒ�
	if (m_rand_time > 1)
	{
		offset_x = 200 * (m_shake_strength * time_rate) * RandomMinusOneToOne();
		offset_y = 200 * (m_shake_strength * time_rate) * RandomMinusOneToOne();
		m_rand_time = 0.0f;
	}

	//������
	XMFLOAT2 pos = m_pos;
	XMFLOAT2 diff = XMFLOAT2(((offset_x + m_init_pos.x) - pos.x) * 0.2f, ((offset_y + m_init_pos.y) - pos.y) * 0.2f);
	pos.x += diff.x;
	pos.y += diff.y;

	if (m_p_network_manager->GetType() == MIDDLE_PC)
	{
		if (m_left)
		{
			switch (m_index)
			{
			case 0:
				ServerPackData(ARROW_OBJECT, LEFT_0_ARROW_POS_X, m_pos.x);
				ServerPackData(ARROW_OBJECT, LEFT_0_ARROW_POS_Y, m_pos.y);
				ServerPackData(ARROW_OBJECT, LEFT_0_ARROW_INIT_POS_X, m_init_pos.x);
				ServerPackData(ARROW_OBJECT, LEFT_0_ARROW_INIT_POS_Y, m_init_pos.y);
				ServerPackData(ARROW_OBJECT, LEFT_0_ARROW_RAND_TIME, m_rand_time);
				break;
			case 1:
				ServerPackData(ARROW_OBJECT, LEFT_1_ARROW_POS_X, m_pos.x);
				ServerPackData(ARROW_OBJECT, LEFT_1_ARROW_POS_Y, m_pos.y);
				ServerPackData(ARROW_OBJECT, LEFT_1_ARROW_INIT_POS_X, m_init_pos.x);
				ServerPackData(ARROW_OBJECT, LEFT_1_ARROW_INIT_POS_Y, m_init_pos.y);
				ServerPackData(ARROW_OBJECT, LEFT_1_ARROW_RAND_TIME, m_rand_time);
				break;
			case 2:
				ServerPackData(ARROW_OBJECT, LEFT_2_ARROW_POS_X, m_pos.x);
				ServerPackData(ARROW_OBJECT, LEFT_2_ARROW_POS_Y, m_pos.y);
				ServerPackData(ARROW_OBJECT, LEFT_2_ARROW_INIT_POS_X, m_init_pos.x);
				ServerPackData(ARROW_OBJECT, LEFT_2_ARROW_INIT_POS_Y, m_init_pos.y);
				ServerPackData(ARROW_OBJECT, LEFT_2_ARROW_RAND_TIME, m_rand_time);
				break;
			case 3:
				ServerPackData(ARROW_OBJECT, LEFT_3_ARROW_POS_X, m_pos.x);
				ServerPackData(ARROW_OBJECT, LEFT_3_ARROW_POS_Y, m_pos.y);
				ServerPackData(ARROW_OBJECT, LEFT_3_ARROW_INIT_POS_X, m_init_pos.x);
				ServerPackData(ARROW_OBJECT, LEFT_3_ARROW_INIT_POS_Y, m_init_pos.y);
				ServerPackData(ARROW_OBJECT, LEFT_3_ARROW_RAND_TIME, m_rand_time);
				break;
			default:
				break;
			}
		}
		else
		{
			switch (m_index)
			{
			case 0:
				ServerPackData(ARROW_OBJECT, RIGHT_0_ARROW_POS_X, m_pos.x);
				ServerPackData(ARROW_OBJECT, RIGHT_0_ARROW_POS_Y, m_pos.y);
				ServerPackData(ARROW_OBJECT, RIGHT_0_ARROW_INIT_POS_X, m_init_pos.x);
				ServerPackData(ARROW_OBJECT, RIGHT_0_ARROW_INIT_POS_Y, m_init_pos.y);
				ServerPackData(ARROW_OBJECT, RIGHT_0_ARROW_RAND_TIME, m_rand_time);
				break;
			case 1:
				ServerPackData(ARROW_OBJECT, RIGHT_1_ARROW_POS_X, m_pos.x);
				ServerPackData(ARROW_OBJECT, RIGHT_1_ARROW_POS_Y, m_pos.y);
				ServerPackData(ARROW_OBJECT, RIGHT_1_ARROW_INIT_POS_X, m_init_pos.x);
				ServerPackData(ARROW_OBJECT, RIGHT_1_ARROW_INIT_POS_Y, m_init_pos.y);
				ServerPackData(ARROW_OBJECT, RIGHT_1_ARROW_RAND_TIME, m_rand_time);
				break;
			case 2:
				ServerPackData(ARROW_OBJECT, RIGHT_2_ARROW_POS_X, m_pos.x);
				ServerPackData(ARROW_OBJECT, RIGHT_2_ARROW_POS_Y, m_pos.y);
				ServerPackData(ARROW_OBJECT, RIGHT_2_ARROW_INIT_POS_X, m_init_pos.x);
				ServerPackData(ARROW_OBJECT, RIGHT_2_ARROW_INIT_POS_Y, m_init_pos.y);
				ServerPackData(ARROW_OBJECT, RIGHT_2_ARROW_RAND_TIME, m_rand_time);
				break;
			case 3:
				ServerPackData(ARROW_OBJECT, RIGHT_3_ARROW_POS_X, m_pos.x);
				ServerPackData(ARROW_OBJECT, RIGHT_3_ARROW_POS_Y, m_pos.y);
				ServerPackData(ARROW_OBJECT, RIGHT_3_ARROW_INIT_POS_X, m_init_pos.x);
				ServerPackData(ARROW_OBJECT, RIGHT_3_ARROW_INIT_POS_Y, m_init_pos.y);
				ServerPackData(ARROW_OBJECT, RIGHT_3_ARROW_RAND_TIME, m_rand_time);
				break;
			default:
				break;
			}
		}
	}

	return pos;
}