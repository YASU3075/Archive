//-----------------------------------------------
// Server.cpp
// ������F2024/12/13
// ����ҁF���c���l
//-----------------------------------------------
//#include <stdio.h>      // ��M ���M
//#include <iostream>     // ��M
//#include <string>       // ��M ���M
#include <WinSock2.h>
//#include <Windows.h>

#include <windowsx.h>

#pragma comment(lib, "ws2_32.lib")

#include "Server.h"
#include "renderer.h"

//-----------------------------------------------
// �v���g�^�C�v�錾
//-----------------------------------------------
static int WithTimeout(int sockfd, unsigned int sec, unsigned int usec);

//-----------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------
struct CONECT_SOCKET
{
    SOCKET socket = INVALID_SOCKET;
    struct sockaddr clit_sock_addr;
    sockaddr_in addr =
    {
        /*ADDRESS_FAMILY	sin_family; */AF_INET,
        /*USHORT			sin_port;	*/{}/*htons(PORT_NUMBER_01)*/,
        /*IN_ADDR			sin_addr;	*/{},//htonl(INADDR_ANY),
        /*CHAR				sin_zero[8];*/{}
    };

    timeval tv;
};
static CONECT_SOCKET g_socket[MAX_SOCKET - 1];
static void* g_server_recvdest[MAX_CLIENT_DATA_NUM] = { NULL };	    //�󂯎��f�[�^
static void* g_server_senddest[MAX_SERVER_DATA_NUM] = { NULL };	    //����f�[�^
static char MyIPv4[9]{};

//-----------------------------------------------
// ����������
//-----------------------------------------------
int InitServer()
{
    static WSADATA WsaData;
    WSACleanup();
    int re = WSAStartup(MAKEWORD(2, 0), &WsaData);

    g_socket[0].addr.sin_port = htons(PORT_NUMBER_01);
    g_socket[1].addr.sin_port = htons(PORT_NUMBER_02);
    for (int i = 0; i < MAX_SOCKET - 1; i++)
    {
        g_socket[i].socket = socket(AF_INET, SOCK_DGRAM, 0);

        g_socket[i].clit_sock_addr = *((sockaddr*)&g_socket[i].addr);
        bind(g_socket[i].socket, (struct sockaddr*)&g_socket[i].clit_sock_addr, sizeof(g_socket[i].clit_sock_addr));
    }

    return re;
}

//-----------------------------------------------
// �f�[�^�𑗐M
//-----------------------------------------------
int ServerSendData(int num)
{
    int re = -1;        //�Ԃ�l
    int data_size = 0;  //�f�[�^�T�C�Y

    for (int i = 0; i < MAX_SERVER_DATA_NUM; i++)
    {//����f�[�^���擾
        if (g_server_senddest[i] != nullptr)
        {
            data_size++;
        }
    }

    if (g_socket[num].socket != INVALID_SOCKET)
    {
        //�f�[�^���M
        int addrsize = sizeof(g_socket[num].clit_sock_addr);
        re = sendto(g_socket[num].socket, (char*)g_server_senddest, sizeof(void*) * data_size, 0, (struct sockaddr*) & g_socket[num].clit_sock_addr, addrsize);//addr�ɕ����񑗐M
    }

    return re;
}

//-----------------------------------------------
// �f�[�^����M
//-----------------------------------------------
void ServerRecvData(int num)
{
    int re = -1;        //�Ԃ�l
    if (g_socket[num].socket != INVALID_SOCKET && WithTimeout(g_socket[num].socket, 1, 0) > 0)
    {
        //�f�[�^�擾

        int addrsize = sizeof(g_socket[num].clit_sock_addr);

        memset(g_server_recvdest, NULL, sizeof(g_server_recvdest));
        re = recvfrom(g_socket[num].socket, (char*)g_server_recvdest, sizeof(g_server_recvdest), 0, &g_socket[num].clit_sock_addr, &addrsize);
        if (re < 0)
        {
            WSAGetLastError();
        }
    }
}

//-----------------------------------------------
// �I������
//-----------------------------------------------
int UninitServer()
{
    closesocket(g_socket[0].socket);
    closesocket(g_socket[1].socket);
    WSACleanup();

    return 0;
}

//-----------------------------------------------
// �f�[�^���l�߂�
//-----------------------------------------------
void ServerPackData(int o_num, int variable_num, int data)
{
    for (int i = 0; i < MAX_SERVER_DATA_NUM; i++)
    {
        if (g_server_senddest[i] == nullptr)
        {//�󂢂Ă���Ƃ���Ƀf�[�^���i�[
            int sign = SIGN_PLUS;
            if (data < 0)
            {//���̐��̎�
                sign = SIGN_MINUS;
                data *= -1;
            }
            g_server_senddest[i] = 
                (void*)(o_num * (int)pow(10, MAX_DISTINCTION_NUM) + variable_num * (int)pow(10, VALUE_DIGIT_NUM + SIGN_DISTINCTION_NUM) + sign * (int)pow(10, VALUE_DIGIT_NUM) + data);
            return;
        }
    }
}

//-----------------------------------------------
// �f�[�^���l�߂�i���p�j
//-----------------------------------------------
void ServerPackArrowData(int a_num, int variable_num, int data)
{
    for (int i = 0; i < MAX_SERVER_DATA_NUM; i++)
    {
        if (g_server_senddest[i] == nullptr)
        {//�󂢂Ă���Ƃ���Ƀf�[�^���i�[
            g_server_senddest[i] =
                (void*)(ARROW_OBJECT * (int)pow(10, MAX_DISTINCTION_NUM) + variable_num * (int)pow(10, VALUE_DIGIT_NUM + SIGN_DISTINCTION_NUM) + a_num * (int)pow(10, VALUE_DIGIT_NUM) + data);
            return;
        }
    }
}

//-----------------------------------------------
// �f�[�^���擾����
//-----------------------------------------------
void* ServerGetData(int id)
{
    return g_server_recvdest[id];
}

//-----------------------------------------------
// �f�[�^���Z�b�g
//-----------------------------------------------
void ServerResetData(void)
{
    for (int i = 0; i < MAX_SERVER_DATA_NUM; i++)
    {
        g_server_senddest[i] = nullptr;
    }

    for (int i = 0; i < MAX_CLIENT_DATA_NUM; i++)
    {
        g_server_recvdest[i] = nullptr;
    }
}

/*
 * �^�C���A�E�g�t���f�[�^��M
 * sockfd�F�f�[�^��M���s���\�P�b�g
 * sec�F�^�C���A�E�g���ԁi�b�j
 * usec�F�^�C���A�E�g���ԁi�}�C�N���b�j
 */
int WithTimeout(int sockfd, unsigned int sec, unsigned int usec)
{
    struct timeval tv;
    fd_set readfds;
    int ret_select;

    /* �^�C���A�E�g���Ԃ�ݒ� */
    tv.tv_sec = sec;
    tv.tv_usec = usec;

    /* �ǂݍ���FD�W������ɂ��� */
    FD_ZERO(&readfds);

    /* �ǂݍ���FD�W����sockfd��ǉ� */
    FD_SET(sockfd, &readfds);

    /* select��readfds�̂ǂꂩ���ǂݍ��݉\�ɂȂ�܂�or�^�C���A�E�g�܂ő҂� */
    ret_select = select(sockfd + 1, &readfds, NULL, NULL, &tv/*nullptr*/);

    /* �߂�l���`�F�b�N */
    /* select�֐����G���[ */
    if (ret_select == -1) return -1;

    /* �ǂݍ��݉\�ɂȂ���FD�̐���0�Ȃ̂Ń^�C���A�E�g�Ɣ��f */
    if (ret_select == 0) return 0;

    /* sockfd���ǂݍ��݉\�Ȃ̂Ŏ��s */
    return 1;
}

/*=========================
* ������IPv4 16�i������
=========================*/
char* SetMyAddress()
{
    // �z�X�g�l�[���i�[
    char lpszHostName[50];
    // IP�A�h���X
    char ipv4_16[9]{ NULL };
    char ipv4_16_4[3]{ NULL };
    PHOSTENT phostent;
    IN_ADDR in;
    gethostname(lpszHostName, 50);
#pragma warning(suppress : 4996)
    phostent = gethostbyname(lpszHostName);
    memcpy(&in, phostent->h_addr, 4);


    _itoa_s(in.S_un.S_un_b.s_b1, ipv4_16_4, sizeof(ipv4_16_4), 16);
    if (ipv4_16_4[1] == 0)
#pragma warning(suppress : 4996)
        sprintf(ipv4_16_4, "0%c", ipv4_16_4[0]);
    strcat_s(ipv4_16, ipv4_16_4);

    _itoa_s(in.S_un.S_un_b.s_b2, ipv4_16_4, sizeof(ipv4_16_4), 16);
    if (ipv4_16_4[1] == 0)
#pragma warning(suppress : 4996)
        sprintf(ipv4_16_4, "0%c", ipv4_16_4[0]);
    strcat_s(ipv4_16, ipv4_16_4);

    _itoa_s(in.S_un.S_un_b.s_b3, ipv4_16_4, sizeof(ipv4_16_4), 16);
    if (ipv4_16_4[1] == 0)
#pragma warning(suppress : 4996)
        sprintf(ipv4_16_4, "0%c", ipv4_16_4[0]);
    strcat_s(ipv4_16, ipv4_16_4);

    _itoa_s(in.S_un.S_un_b.s_b4, ipv4_16_4, sizeof(ipv4_16_4), 16);
    if (ipv4_16_4[1] == 0)
#pragma warning(suppress : 4996)
        sprintf(ipv4_16_4, "0%c", ipv4_16_4[0]);
    strcat_s(ipv4_16, ipv4_16_4);

    for (int i = 0; i < 9; i++)
    {
        MyIPv4[i] = ipv4_16[i];
    }
    return MyIPv4;
}

char* GetMyAddress()
{
    return MyIPv4;
}
